import supabase from './db-client.js';
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { game_id, limit } = req.query;
      let q = supabase.from('matches').select('id,game_id,game_title,room_code,players,winner_name,scores,created_at').order('created_at', { ascending: false }).limit(Math.min(60, parseInt(limit) || 30));
      if (game_id) q = q.eq('game_id', game_id);
      const { data, error } = await q;
      if (error) throw error;
      res.setHeader('Cache-Control','public, max-age=10, stale-while-revalidate=30');
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { game_id, game_title, room_code, players, winner_name, winner_index, scores } = req.body;
      if (!game_id) return res.status(400).json({ error: 'game_id required' });
      const safePlayers = Array.isArray(players) ? players.slice(0, 3).map((p) => String(p).slice(0, 24)) : [];
      const { data, error } = await supabase.from('matches').insert({ game_id: String(game_id).slice(0,32), game_title: String(game_title || game_id).slice(0,48), room_code: String(room_code || 'solo').slice(0,12), players: safePlayers, winner_name: winner_name ? String(winner_name).slice(0,24) : null, winner_index: winner_index ?? null, scores: scores || {} }).select('id').single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) { res.status(500).json({ error: err.message }); }
}
