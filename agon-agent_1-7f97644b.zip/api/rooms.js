import supabase from './db-client.js';
function genCode(){const c='ABCDEFGHJKMNPQRSTUVWXYZ23456789';let s='';for(let i=0;i<6;i++)s+=c[Math.floor(Math.random()*c.length)];return s;}
// Simple in-memory rate limit: 60 req/min per IP per endpoint group (enough for 40-50 concurrent players)
const hits = new Map();
function limited(ip, group, max = 60, windowMs = 60000) {
  const now = Date.now();
  const k = ip + ':' + group;
  const arr = (hits.get(k) || []).filter((t) => now - t < windowMs);
  arr.push(now);
  hits.set(k, arr);
  if (hits.size > 4000) { const first = hits.keys().next().value; hits.delete(first); }
  return arr.length > max;
}
export default async function handler(req,res){
  res.setHeader('Access-Control-Allow-Origin','*');
  res.setHeader('Access-Control-Allow-Methods','GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers','Content-Type, Authorization');
  res.setHeader('Cache-Control','no-store');
  if(req.method==='OPTIONS')return res.status(204).end();
  try{
    const ip = (req.headers['x-forwarded-for'] || '').toString().split(',')[0].trim() || req.socket?.remoteAddress || 'x';
    if(req.method==='GET'){
      if (limited(ip, 'rooms-get', 120)) return res.status(429).json({ error: 'Slow down — too many requests' });
      const {code,game_id,open}=req.query;
      if(code){
        const {data,error}=await supabase.from('rooms').select('*').eq('code',String(code).toUpperCase()).limit(1);
        if(error)throw error;
        if(!data||!data.length)return res.status(404).json({error:'Room not found'});
        res.setHeader('Cache-Control','public, max-age=1, stale-while-revalidate=4');
        return res.status(200).json(data[0]);
      }
      const {data,error}=await supabase.from('rooms').select('code,game_id,game_title,host_name,players,max_players,status,created_at').order('created_at',{ascending:false}).limit(40);
      if(error)throw error;
      let rooms=data||[];
      if(game_id)rooms=rooms.filter(r=>r.game_id===game_id);
      if(open==='1')rooms=rooms.filter(r=>r.status==='waiting'&&(r.players||[]).length<(r.max_players||3));
      res.setHeader('Cache-Control','public, max-age=2, stale-while-revalidate=8');
      return res.status(200).json(rooms.slice(0,24));
    }
    if(req.method==='POST'){
      const {action}=req.body||{};
      if(action==='state'){
        if (limited(ip, 'rooms-state', 90)) return res.status(429).json({ error: 'Slow down — too many moves' });
        const {code,state,status}=req.body;
        if(!code) return res.status(400).json({error:'code required'});
        let st = state || {};
        try { if (JSON.stringify(st).length > 60000) return res.status(413).json({ error: 'State too large' }); } catch {}
        const patch={state:st,updated_at:new Date().toISOString()};
        if(status)patch.status=status;
        const {data,error}=await supabase.from('rooms').update(patch).eq('code',String(code).toUpperCase()).select('code,state,players,status,updated_at').single();
        if(error)throw error;
        return res.status(200).json(data);
      }
      if (limited(ip, 'rooms-mut', 30)) return res.status(429).json({ error: 'Slow down — too many requests' });
      if(action==='create'){
        const {game_id,game_title,host_id,host_name,max_players}=req.body;
        if(!game_id||!host_id)return res.status(400).json({error:'game_id and host_id required'});
        const name = String(host_name || 'Host').slice(0, 20);
        // retry on code collision
        for (let t = 0; t < 3; t++) {
          const code=genCode();
          const players=[{id:host_id,name,slot:0,joined_at:new Date().toISOString()}];
          const {data,error}=await supabase.from('rooms').insert({code,game_id:String(game_id).slice(0,32),game_title:String(game_title||game_id).slice(0,48),host_id,host_name:name,players,max_players:Math.min(3,Math.max(2,max_players||2)),status:'waiting',state:{}}).select().single();
          if(!error) return res.status(201).json(data);
          if(!String(error.message||'').toLowerCase().includes('duplicate')) throw error;
        }
        return res.status(500).json({error:'Could not allocate room, try again'});
      }
      if(action==='join'){
        const {code,player_id,player_name}=req.body;
        if(!code||!player_id) return res.status(400).json({error:'code and player_id required'});
        const {data:rows}=await supabase.from('rooms').select('*').eq('code',String(code).toUpperCase()).limit(1);
        if(!rows||!rows.length)return res.status(404).json({error:'Room not found'});
        const room=rows[0];let players=room.players||[];
        const cleanName = String(player_name || 'Player').slice(0, 20);
        if(!players.find(p=>p.id===player_id)){
          if(players.length>=(room.max_players||3))return res.status(400).json({error:'Room is full (3 max)'});
          players=[...players,{id:player_id,name:cleanName,slot:players.length,joined_at:new Date().toISOString()}];
        }else{players=players.map(p=>p.id===player_id?{...p,name:cleanName}:p);}
        const {data,error}=await supabase.from('rooms').update({players,updated_at:new Date().toISOString()}).eq('code',room.code).select().single();
        if(error)throw error;
        return res.status(200).json(data);
      }
      if(action==='leave'){
        const {code,player_id}=req.body;
        const {data:rows}=await supabase.from('rooms').select('*').eq('code',String(code).toUpperCase()).limit(1);
        if(!rows||!rows.length)return res.status(404).json({error:'Room not found'});
        const room=rows[0];
        const players=(room.players||[]).filter(p=>p.id!==player_id);
        if(!players.length){await supabase.from('rooms').delete().eq('code',room.code);return res.status(200).json({ok:true,deleted:true});}
        const patch={players,updated_at:new Date().toISOString()};
        if(room.host_id===player_id){patch.host_id=players[0].id;patch.host_name=players[0].name;}
        const {data,error}=await supabase.from('rooms').update(patch).eq('code',room.code).select().single();
        if(error)throw error;
        return res.status(200).json(data);
      }
      if(action==='status'){
        const {code,status}=req.body;
        const {data,error}=await supabase.from('rooms').update({status,updated_at:new Date().toISOString()}).eq('code',String(code).toUpperCase()).select().single();
        if(error)throw error;
        return res.status(200).json(data);
      }
      return res.status(400).json({error:'Unknown action'});
    }
    res.status(405).json({error:'Method not allowed'});
  }catch(err){console.error('rooms err',err);res.status(500).json({error:err.message});}
}
