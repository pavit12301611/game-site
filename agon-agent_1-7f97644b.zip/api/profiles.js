import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { user_id, search } = req.query;
      if (user_id) {
        const { data, error } = await supabase.from('profiles').select('*').eq('user_id', user_id).limit(1);
        if (error) throw error;
        return res.status(200).json(data[0] || null);
      }
      if (search) {
        const { data, error } = await supabase.from('profiles').select('*').limit(50);
        if (error) throw error;
        const q = String(search).toLowerCase();
        const filtered = (data || []).filter(p => (p.username || '').toLowerCase().includes(q) || (p.display_name || '').toLowerCase().includes(q));
        return res.status(200).json(filtered.slice(0, 20));
      }
      const { data, error } = await supabase.from('profiles').select('*').order('created_at', { ascending: false }).limit(50);
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { user_id, username, display_name, avatar_color } = req.body;
      if (!user_id || !username) return res.status(400).json({ error: 'user_id and username required' });
      const uname = String(username).trim().toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 20) || 'player';
      const existing = await supabase.from('profiles').select('*').eq('user_id', user_id).limit(1);
      if (existing.data && existing.data.length > 0) {
        const { data, error } = await supabase.from('profiles').update({ username: uname, display_name: display_name || uname, avatar_color: avatar_color || existing.data[0].avatar_color }).eq('user_id', user_id).select().single();
        if (error) throw error;
        return res.status(200).json(data);
      }
      const taken = await supabase.from('profiles').select('user_id').eq('username', uname).limit(1);
      let finalName = uname;
      if (taken.data && taken.data.length > 0) finalName = `${uname}${Math.floor(100 + Math.random() * 900)}`;
      const colors = ['#ff2e63', '#08d9d6', '#f9ed69', '#a06bff', '#4dff88', '#ff9f1c'];
      const { data, error } = await supabase.from('profiles').insert({ user_id, username: finalName, display_name: display_name || finalName, avatar_color: avatar_color || colors[Math.floor(Math.random() * colors.length)] }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('profiles API error:', err);
    res.status(500).json({ error: err.message });
  }
}
