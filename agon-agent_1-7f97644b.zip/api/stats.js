import supabase from './db-client.js';
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { game_id, username } = req.query;
      let q = supabase.from('game_stats').select('id,user_id,username,game_id,plays,wins,best_score').order('wins', { ascending: false }).limit(60);
      if (game_id) q = q.eq('game_id', game_id);
      if (username) q = q.eq('username', username);
      const { data, error } = await q;
      if (error) throw error;
      res.setHeader('Cache-Control','public, max-age=10, stale-while-revalidate=30');
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { user_id, username, game_id, won, score } = req.body;
      if (!user_id || !game_id) return res.status(400).json({ error: 'need ids' });
      const uname = String(username || 'player').slice(0, 24);
      const pts = Math.max(0, Math.min(9999999, parseInt(score) || 0));
      const gid = String(game_id).slice(0, 32);
      const { data: rows, error: e1 } = await supabase.from('game_stats').select('*').eq('user_id', user_id).eq('game_id', gid).limit(1);
      if (e1) throw e1;
      if (rows && rows.length > 0) {
        const r = rows[0];
        const { data, error } = await supabase.from('game_stats').update({ username: uname, plays: (r.plays||0)+1, wins: (r.wins||0)+(won?1:0), best_score: Math.max(r.best_score||0, pts), updated_at: new Date().toISOString() }).eq('id', r.id).select().single();
        if (error) throw error;
        return res.status(200).json(data);
      }
      const { data, error } = await supabase.from('game_stats').insert({ user_id: String(user_id).slice(0,64), username: uname, game_id: gid, plays: 1, wins: won?1:0, best_score: pts }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    res.status(405).json({ error: 'no' });
  } catch (e) { res.status(500).json({ error: e.message }); }
}
