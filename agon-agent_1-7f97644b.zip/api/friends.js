import supabase from './db-client.js';
export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  try {
    if (req.method === 'GET') {
      const { owner_id } = req.query;
      if (!owner_id) return res.status(400).json({ error: 'owner_id required' });
      const { data, error } = await supabase.from('friends').select('*').eq('owner_id', owner_id).order('created_at', { ascending: false });
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { owner_id, friend_id, friend_name } = req.body;
      if (!owner_id || !friend_id) return res.status(400).json({ error: 'need ids' });
      if (owner_id === friend_id) return res.status(400).json({ error: 'Cannot add yourself' });
      const safeName = String(friend_name || friend_id).slice(0, 24);
      const dupe = await supabase.from('friends').select('id').eq('owner_id', owner_id).eq('friend_id', friend_id).limit(1);
      if (dupe.data && dupe.data.length) return res.status(200).json(dupe.data[0]);
      const { data, error } = await supabase.from('friends').insert({ owner_id, friend_id, friend_name: safeName }).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'DELETE') {
      const id = (req.query && req.query.id) || (req.body && req.body.id);
      if (!id) return res.status(400).json({ error: 'id required' });
      const { error } = await supabase.from('friends').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    res.status(405).json({ error: 'no' });
  } catch (e) { res.status(500).json({ error: e.message }); }
}
