import {useMemo, useRef, useEffect } from 'react';
import {useSync, TurnBanner, WinnerOverlay } from './shared';
import type {GameProps } from './types';
import {slotName } from './types';

// ---------- DOTS & BOXES (2-3P) ----------
export function DotsBoxes(props: GameProps) {
 const {mySlot, players, solo } = props;
 const n = solo ? 2 : (players.length || 2);
 const names = [0,1,2].slice(0,n).map(i=>slotName(players,i,solo));
 const W = 5, H = 5;
 type S = {h: boolean[][]; v: boolean[][]; box: number[][]; turn: number; win: any };
 const init = (): S => ({h: Array.from({length:H+1},()=>Array(W).fill(false)), v: Array.from({length:H},()=>Array(W+1).fill(false)), box: Array.from({length:H},()=>Array(W).fill(-1)), turn: 0, win: null });
 const [s, setS] = useSync(props, 'dots', init);
 const done = useRef(false);
  useEffect(()=>{ try { const _w:any=(s as any)?.win; if(_w===null||_w===undefined) done.current=false; } catch{} }, [s]);
 const cols = ['#ff2e63','#08d9d6','#ffe74c'];
 const totalBoxes = W*H;
 const claimed = s.box.flat().filter(x=>x>=0).length;
 const isDone = claimed===totalBoxes;
 const finish = () => {
  if(done.current) return; done.current=true;
  const sc:any={}; const tally=names.map(()=>0);
  s.box.flat().forEach(x=>{if(x>=0)tally[x]++;});
  names.forEach((nm,i)=>sc[nm]=tally[i]);
  let wi=0; tally.forEach((t,i)=>{if(t>tally[wi])wi=i;});
  const tie = tally.filter(t=>t===tally[wi]).length>1;
  props.onFinish({winnerName:tie?null:names[wi],winnerIndex:tie?null:(solo?(wi===0?0:null):wi),scores:sc});
 };
 if(isDone) setTimeout(finish,80);
 const line=(kind:'h'|'v',r:number,c:number)=>{
  if(isDone) return;
  if(!solo&&s.turn!==mySlot) return;
  if(solo&&s.turn!==0) return;
  if(kind==='h'&&s.h[r][c]) return;
  if(kind==='v'&&s.v[r][c]) return;
  const h=s.h.map(a=>[...a]), v=s.v.map(a=>[...a]), box=s.box.map(a=>[...a]);
  if(kind==='h')h[r][c]=true; else v[r][c]=true;
  let gained=false;
  for(let br=0;br<H;br++)for(let bc=0;bc<W;bc++){
   if(box[br][bc]<0&&h[br][bc]&&h[br+1][bc]&&v[br][bc]&&v[br][bc+1]){box[br][bc]=s.turn;gained=true;}
  }
  // cpu: if solo and turn passes
  let nt = gained?s.turn:(s.turn+1)%n;
  if(solo&&!isDone&&nt===1){
   // random free line
   const opts:[string,number,number][]=[];
   for(let r=0;r<=H;r++)for(let c=0;c<W;c++)if(!h[r][c])opts.push(['h',r,c]);
   for(let r=0;r<H;r++)for(let c=0;c<=W;c++)if(!v[r][c])opts.push(['v',r,c]);
   if(opts.length){const [k,ar,ac]=opts[Math.floor(Math.random()*opts.length)]; if(k==='h')h[ar][ac]=true;else v[ar][ac]=true;
    let g2=false; for(let br=0;br<H;br++)for(let bc=0;bc<W;bc++){if(box[br][bc]<0&&h[br][bc]&&h[br+1][bc]&&v[br][bc]&&v[br][bc+1]){box[br][bc]=1;g2=true;} }
    nt = g2?1:0;
   }
  }
  setS({h,v,box,turn:nt,win:null});
 };
 const tally = names.map(()=>0); s.box.flat().forEach(x=>{if(x>=0)tally[x]++;});
 const rematch=()=>{done.current=false;setS(init());};
 const myTurnNow=solo||s.turn===mySlot;
 return (
  <div className="max-w-md mx-auto">
   <TurnBanner text={isDone?'GAME OVER':(myTurnNow?'YOUR TURN':'WAITING…')} color={cols[s.turn]} />
   <div className="flex gap-3 justify-center text-xs font-bold mb-3">{names.map((nm,i)=><span key={i} style={{color:cols[i]}}>{nm}: {tally[i]}</span>)}</div>
   <div className="p-4 rounded-xl mx-auto" style={{background:'#0d0d24',border:'2px solid #3d3d7a',width:'fit-content'}}>
    {Array.from({length:H*2+1}).map((_,r)=>{
     if(r%2===0){
      const hr=r/2;
      return (<div key={r} className="flex items-center" style={{gap:4}}>
       <Dot/>
       {Array.from({length:W}).map((_,c)=>(
        <div key={c} className="flex items-center" style={{gap:4}}>
         <button onClick={()=>line('h',hr,c)} className="game-grid-cell clickable rounded" style={{width:34,height:8,background:s.h[hr][c]?cols[0]:'#2b2b5e',cursor:myTurnNow?'pointer':'default'}}/>
         <Dot/>
        </div>
       ))}
      </div>);
     } else {
      const br=(r-1)/2;
      return (<div key={r} className="flex" style={{gap:4,marginLeft:0}}>
       {Array.from({length:W+1}).map((_,c)=>(
        <div key={c} className="flex items-center" style={{gap:4}}>
         <button onClick={()=>line('v',br,c)} className="game-grid-cell clickable rounded" style={{width:8,height:34,background:s.v[br][c]?cols[1]:'#2b2b5e',cursor:myTurnNow?'pointer':'default',marginLeft:c===0?4:0}}/>
         {c<W && <div className="flex items-center justify-center font-pixel text-[10px]" style={{width:34,height:34,background:s.box[br][c]>=0?cols[s.box[br][c]]+'33':'transparent',borderRadius:6,color:cols[s.box[br][c]]}}>{s.box[br][c]>=0?names[s.box[br][c]][0]:''}</div>}
        </div>
       ))}
      </div>);
     }
    })}
   </div>
   {isDone && (()=>{const wi=tally.indexOf(Math.max(...tally)); const tie=tally.filter(t=>t===Math.max(...tally)).length>1; const sc:any={}; names.forEach((nm,i)=>sc[nm]=tally[i]);
    return <WinnerOverlay winnerName={tie?null:names[wi]} isMe={!tie&&names[wi]===(solo?names[0]:players[mySlot]?.name)} scores={names.map(nm=>[nm,sc[nm]] as [string,number])} gameTitle="Dots & Boxes" onRematch={rematch} showRematch />; })()}
  </div>
 );
}
function Dot(){return <div className="rounded-full" style={{width:8,height:8,background:'#ffe74c',marginLeft:4,marginRight:0}}/>;}

// ---------- CHECKERS (simplified) ----------
export function Checkers(props: GameProps) {
 const {mySlot, players, solo } = props;
 const names=[slotName(players,0,solo),slotName(players,1,solo)];
 const N=8;
 type P={p:number;k:boolean}; // p 1|2
 const startBoard=(): (P|null)[][]=>{
  const g:(P|null)[][]=Array.from({length:N},()=>Array(N).fill(null));
  for(let r=0;r<3;r++)for(let c=0;c<N;c++)if((r+c)%2===1)g[r][c]={p:2,k:false};
  for(let r=5;r<8;r++)for(let c=0;c<N;c++)if((r+c)%2===1)g[r][c]={p:1,k:false};
  return g;
 };
 type S={g:(P|null)[][];turn:number;sel:[number,number]|null;win:any};
 const init=():S=>({g:startBoard(),turn:0,sel:null,win:null});
 const [s,setS]=useSync(props,'chk',init);
 const done=useRef(false);
 const inB=(r:number,c:number)=>r>=0&&r<N&&c>=0&&c<N;
 const jumps=(g:(P|null)[][],r:number,c:number,p:number)=>{
  const cell=g[r][c]; if(!cell)return [];
  const out:[number,number][]=[];
  const dirs=cell.k?[[1,1],[1,-1],[-1,1],[-1,-1]]:(p===1?[[-1,1],[-1,-1]]:[[1,1],[1,-1]]);
  for(const [dr,dc] of dirs){const mr=r+dr,mc=c+dc,lr=r+2*dr,lc=c+2*dc;
   if(inB(lr,lc)&&g[mr][mc]&&g[mr][mc]!.p!==p&&!g[lr][lc])out.push([lr,lc]);}
  return out;
 };
 const steps=(g:(P|null)[][],r:number,c:number,p:number)=>{
  const cell=g[r][c]; if(!cell)return [];
  const out:[number,number][]=[];
  const dirs=cell.k?[[1,1],[1,-1],[-1,1],[-1,-1]]:(p===1?[[-1,1],[-1,-1]]:[[1,1],[1,-1]]);
  for(const [dr,dc] of dirs){const nr=r+dr,nc=c+dc;if(inB(nr,nc)&&!g[nr][nc])out.push([nr,nc]);}
  return out;
 };
 const anyJump=(g:(P|null)[][],p:number)=>{for(let r=0;r<N;r++)for(let c=0;c<N;c++)if(g[r][c]?.p===p&&jumps(g,r,c,p).length)return true;return false;};
 const countP=(g:(P|null)[][])=>[g.flat().filter(x=>x?.p===1).length,g.flat().filter(x=>x?.p===2).length];
 const finish=(w:number)=>{if(done.current)return;done.current=true;const [a,b]=countP(s.g);props.onFinish({winnerName:names[w],winnerIndex:solo?(w===0?0:null):w,scores:{[names[0]]:a,[names[1]]:b}});};
 const click=(r:number,c:number)=>{
  if(s.win!==null&&s.win!==undefined)return;
  const me = solo?0:mySlot;
  if(s.turn!==me)return;
  const p=me+1;
  const g=s.g.map(row=>row.map(x=>x?{...x}:null));
  if(s.sel){
   const [sr,sc2]=s.sel;
   const mustJ=anyJump(g,p);
   const opts=mustJ?jumps(g,sr,sc2,p):[...jumps(g,sr,sc2,p),...steps(g,sr,sc2,p)];
   if(opts.some(([a,b])=>a===r&&b===c)){
    const wasJ=jumps(g,sr,sc2,p).some(([a,b])=>a===r&&b===c);
    g[r][c]=g[sr][sc2];g[sr][sc2]=null;
    if(wasJ)g[(sr+r)/2][(sc2+c)/2]=null;
    if((p===1&&r===0)||(p===2&&r===N-1))g[r][c]!.k=true;
    const [a,b]=countP(g);
    if(a===0||b===0){const w=a===0?1:0;setS({g,turn:s.turn,sel:null,win:w});finish(w);return;}
    // chain jumps
    if(wasJ&&jumps(g,r,c,p).length){setS({g,turn:s.turn,sel:[r,c],win:null});return;}
    let nt=(s.turn+1)%2;
    setS({g,turn:nt,sel:null,win:null});
    if(solo&&nt===1)setTimeout(()=>cpuTurn(g),450);
    return;
   }
  }
  if(g[r][c]?.p===p)setS({...s,sel:[r,c]});
  else setS({...s,sel:null});
 };
 const cpuTurn=(g0:(P|null)[][])=>{
  const g=g0.map(row=>row.map(x=>x?{...x}:null));
  const mustJ=anyJump(g,2);
  const cand:[number,number,number,number][]=[];
  for(let r=0;r<N;r++)for(let c=0;c<N;c++)if(g[r][c]?.p===2){
   const js=jumps(g,r,c,2); const ss=mustJ?[]:steps(g,r,c,2);
   [...js.map(j=>({j:j,m:true})),...ss.map(j=>({j:j,m:false}))].forEach(({j})=>cand.push([r,c,j[0],j[1]]));
  }
  if(!cand.length){setS({...s,g,turn:0,sel:null});return;}
  const [sr,sc2,dr,dc]=cand[Math.floor(Math.random()*cand.length)];
  const wasJ=jumps(g,sr,sc2,2).some(([a,b])=>a===dr&&b===dc);
  g[dr][dc]=g[sr][sc2];g[sr][sc2]=null;
  if(wasJ)g[(sr+dr)/2][(sc2+dc)/2]=null;
  if(dr===N-1)g[dr][dc]!.k=true;
  setS({g,turn:0,sel:null,win:null});
 };
 const myTurnNow=solo||s.turn===mySlot;
 const [ca,cb]=countP(s.g);
 const opts=useMemo(()=>{if(!s.sel)return new Set<string>();const [sr,sc2]=s.sel;const p=(solo?0:mySlot)+1;const m=anyJump(s.g,p)?jumps(s.g,sr,sc2,p):[...jumps(s.g,sr,sc2,p),...steps(s.g,sr,sc2,p)];return new Set(m.map(([a,b])=>a+'-'+b));},[s.sel,s.g]);
 const rematch=()=>{done.current=false;setS(init());};
 return (
  <div className="max-w-md mx-auto">
   <TurnBanner text={(s.win!==null&&s.win!==undefined)?`${names[s.win]} WINS!`:(myTurnNow?'YOUR TURN':'WAITING…')} color={s.turn===0?'#ff2e63':'#08d9d6'} />
   <div className="text-center text-xs font-bold mb-2"><span style={{color:'#ff2e63'}}>{names[0]} ×{ca}</span><span className="mx-3 text-slate-500">·</span><span style={{color:'#08d9d6'}}>{names[1]} ×{cb}</span></div>
   <div className="grid rounded-xl overflow-hidden" style={{gridTemplateColumns:'repeat(8,1fr)',border:'3px solid #6b5320'}}>
    {s.g.map((row,r)=>row.map((cell,c)=>{
     const dark=(r+c)%2===1;
     const sel=s.sel&&s.sel[0]===r&&s.sel[1]===c;
     const hl=opts.has(r+'-'+c);
     return <div key={r+'-'+c} onClick={()=>click(r,c)} className="game-grid-cell clickable aspect-square flex items-center justify-center" style={{background:sel?'#ffe74c':hl?'rgba(77,255,136,.5)':dark?'#7c5a2e':'#e8c87a'}}>
      {cell&&<div className="rounded-full flex items-center justify-center font-pixel" style={{width:'78%',height:'78%',background:cell.p===1?'#ff2e63':'#1a1a2e',border:'2px solid #000',color:'#fff',fontSize:cell.k?10:0}}>{cell.k?'K':''}</div>}
     </div>;
    }))}
   </div>
   {(s.win!==null&&s.win!==undefined)&&<WinnerOverlay winnerName={names[s.win]} isMe={names[s.win]===(solo?names[0]:players[mySlot]?.name)} scores={[[names[0],ca],[names[1],cb]]} gameTitle="Turbo Checkers" onRematch={rematch} showRematch />}
  </div>
 );
}
