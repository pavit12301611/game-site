import { useEffect, useMemo, useRef, useState } from 'react';
import { useSync, useRace, TurnBanner, WinnerOverlay } from './shared';
import type { GameProps } from './types';
import { slotName } from './types';

function RaceBarMini({ live, me, score }: { live: [string, number][]; me: string; score: number }) {
  const rows = live.map(([n, s]) => n.includes('(you)') ? [me + ' (you)', score] as [string, number] : [n, s] as [string, number]);
  if (!rows.filter(([n]) => !n.includes('(you)')).length && rows.length <= 1) return null;
  const sorted = [...rows].sort((a,b)=>b[1]-a[1]);
  const top = sorted[0]?.[1] ?? 0;
  return (<div className="score-strip">{sorted.map(([n,s],i)=>(<span key={i} className={`score-chip ${n.includes('(you)')?'score-chip-me':''} ${s===top&&s>0?'score-chip-lead':''}`}>{i===0?'👑 ':i+1+'. '}{n}: {s}</span>))}</div>);
}
function useCanvasMini(draw: (ctx:any,t:number)=>void){
  const ref=useRef<HTMLCanvasElement>(null);
  useEffect(()=>{let raf=0;const t0=performance.now();const loop=(t:number)=>{const c=ref.current;if(c){const ctx=c.getContext('2d');if(ctx)draw(ctx,(t-t0)/1000);}raf=requestAnimationFrame(loop);};raf=requestAnimationFrame(loop);return ()=>cancelAnimationFrame(raf);},[]);
  return ref;
}

// ================= FULL CHESS (8x8, all pieces, legal moves) =================
type Piece = { t: string; p: number } | null; // t: K Q R B N P
const START = [
  ['r','n','b','q','k','b','n','r'],
  ['p','p','p','p','p','p','p','p'],
  ['','','','','','','',''],
  ['','','','','','','',''],
  ['','','','','','','',''],
  ['','','','','','','',''],
  ['P','P','P','P','P','P','P','P'],
  ['R','N','B','Q','K','B','N','R'],
];
const GLYPH: Record<string,string> = { k:'♚',q:'♛',r:'♜',b:'♝',n:'♞',p:'♟' };
const inB = (r:number,c:number)=>r>=0&&r<8&&c>=0&&c<8;
function startBoard(): Piece[][] {
  return START.map(row=>row.map(ch=>!ch?null:({ t: ch.toLowerCase(), p: ch===ch.toUpperCase()?1:2 })));
}
function movesFor(g:Piece[][], r:number,c:number): [number,number][] {
  const cell=g[r][c]; if(!cell)return [];
  const {t,p}=cell; const out:[number,number][]=[];
  const add=(nr:number,nc:number,slide:boolean):boolean=>{
    if(!inB(nr,nc))return false;
    const o=g[nr][nc];
    if(!o){out.push([nr,nc]);return slide;}
    if(o.p!==p)out.push([nr,nc]);
    return false;
  };
  const ray=(dirs:[number,number][])=>{for(const [dr,dc] of dirs){let nr=r+dr,nc=c+dc;while(add(nr,nc,true)){nr+=dr;nc+=dc;}}};
  if(t==='n'){for(const [dr,dc] of [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]){if(inB(r+dr,c+dc)&&(!g[r+dr][c+dc]||g[r+dr][c+dc]!.p!==p))out.push([r+dr,c+dc]);}}
  else if(t==='k'){for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++){if(!dr&&!dc)continue;add(r+dr,c+dc,false);}}
  else if(t==='p'){
    const d=p===1?-1:1; const home=p===1?6:1;
    if(inB(r+d,c)&&!g[r+d][c]){out.push([r+d,c]);if(r===home&&!g[r+2*d][c])out.push([r+2*d,c]);}
    for(const dc of [-1,1]){if(inB(r+d,c+dc)&&g[r+d][c+dc]&&g[r+d][c+dc]!.p!==p)out.push([r+d,c+dc]);}
  }
  else if(t==='r')ray([[1,0],[-1,0],[0,1],[0,-1]]);
  else if(t==='b')ray([[1,1],[1,-1],[-1,1],[-1,-1]]);
  else if(t==='q')ray([[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]]);
  return out;
}
function hasKing(g:Piece[][],p:number){return g.flat().some(x=>x&&x.t==='k'&&x.p===p);}
function anyMoves(g:Piece[][],p:number){
  for(let r=0;r<8;r++)for(let c=0;c<8;c++)if(g[r][c]?.p===p&&movesFor(g,r,c).length)return true;
  return false;
}
export function Chess(props: GameProps){
  const {mySlot,players,solo}=props;
  const names=[slotName(players,0,solo),slotName(players,1,solo)];
  type S={g:Piece[][];turn:number;sel:[number,number]|null;win:any;promo:boolean};
  const init=():S=>({g:startBoard(),turn:0,sel:null,win:null,promo:false});
  const[s,setS]=useSync(props,'chess',init);
  const done=useRef(false);
  useEffect(()=>{ try{const w:any=(s as any)?.win;if(w===null||w===undefined)done.current=false;}catch{} },[s]);
  const finish=(w:number)=>{if(done.current)return;done.current=true;const sc:any={};sc[names[0]]=w===0?1:0;sc[names[1]]=w===1?1:0;props.onFinish({winnerName:names[w],winnerIndex:solo?(w===0?0:null):w,scores:sc});};
  const click=(r:number,c:number)=>{
    if(s.win!==null&&s.win!==undefined)return;
    const me=solo?0:mySlot; if(s.turn!==me)return;
    const p=me+1;
    const g=s.g.map(row=>row.map(x=>x?{...x}:null));
    if(s.sel){
      const [sr,sc2]=s.sel;
      if(movesFor(s.g,sr,sc2).some(([a,b])=>a===r&&b===c)){
        g[r][c]=g[sr][sc2];g[sr][sc2]=null;
        if(g[r][c]!.t==='p'&&(r===0||r===7))g[r][c]={t:'q',p};
        if(!hasKing(g,3-p)){setS({g,turn:s.turn,sel:null,win:me,promo:false});finish(me);return;}
        if(!anyMoves(g,3-p)){setS({g,turn:s.turn,sel:null,win:me,promo:false});finish(me);return;}
        const nt=(s.turn+1)%2;
        setS({g,turn:nt,sel:null,win:null,promo:false});
        if(solo&&nt===1)setTimeout(()=>cpuMove(g),500);
        return;
      }
    }
    if(g[r][c]?.p===p)setS({...s,sel:[r,c]});
    else setS({...s,sel:null});
  };
  const cpuMove=(g0:Piece[][])=>{
    const g=g0.map(row=>row.map(x=>x?{...x}:null));
    const all:[number,number,number,number,number][]=[];
    for(let r=0;r<8;r++)for(let c=0;c<8;c++)if(g[r][c]?.p===2){
      for(const [dr,dc] of movesFor(g,r,c)){
        const cap=g[dr][dc]?({p:1,q:10,n:30,b:31,r:50}[g[dr][dc]!.t]||10):0;
        all.push([r,c,dr,dc,cap+Math.random()*3]);
      }
    }
    if(!all.length){setS({...s,g,turn:0,sel:null,win:null,promo:false});return;}
    all.sort((a,b)=>b[4]-a[4]);
    const [sr,sc2,dr,dc]=all[0];
    g[dr][dc]=g[sr][sc2];g[sr][sc2]=null;
    if(g[dr][dc]!.t==='p'&&dr===7)g[dr][dc]={t:'q',p:2};
    if(!hasKing(g,1)){setS({g,turn:1,sel:null,win:1,promo:false});finish(1);return;}
    if(!anyMoves(g,1)){setS({g,turn:1,sel:null,win:1,promo:false});finish(1);return;}
    setS({g,turn:0,sel:null,win:null,promo:false});
  };
  const opts=useMemo(()=>{if(!s.sel)return new Set<string>();const [sr,sc2]=s.sel;const piece=s.g[sr][sc2];if(!piece)return new Set<string>();return new Set(movesFor(s.g,sr,sc2).map(([a,b])=>a+'-'+b));},[s.sel,s.g]);
  const myTurnNow=solo||s.turn===mySlot;
  const rematch=()=>{done.current=false;setS(init());};
  const cap0=s.g.flat().filter(x=>x?.p===2).length, cap1=s.g.flat().filter(x=>x?.p===1).length;
  return (
    <div className="max-w-md mx-auto">
      <TurnBanner text={(s.win!==null&&s.win!==undefined)?`${names[s.win]} CHECKMATES!`:(myTurnNow?'YOUR MOVE':'WAITING…')} color={s.turn===0?'#f5f5f5':'#1a1a2e'} />
      <div className="score-strip">
        {[0,1].map((i)=>(
          <span key={i} className={`score-chip ${i===mySlot||(solo&&i===0)?'score-chip-me':''}`}>
            <span>{i===0?'♔':'♚'}</span> {names[i]} · {i===0?cap1:cap0} on board
          </span>
        ))}
      </div>
      <div className="cabinet" style={{borderColor:'#6b5320'}}>
        <div className="grid" style={{gridTemplateColumns:'repeat(8,1fr)'}}>
        {s.g.map((row,r)=>row.map((cell,c)=>{
          const dark=(r+c)%2===1;const sel=s.sel&&s.sel[0]===r&&s.sel[1]===c;const hl=opts.has(r+'-'+c);
          return <div key={r+'-'+c} onClick={()=>click(r,c)} className="game-grid-cell clickable aspect-square flex items-center justify-center text-xl sm:text-2xl"
            style={{background:sel?'#ffe74c':hl?'rgba(77,255,136,.55)':dark?'#7c5a2e':'#e8c87a',color:cell?(cell.p===1?'#fff':'#111'):'#000',textShadow:cell&&cell.p===1?'0 0 3px #000, 0 2px 2px #000':'none',boxShadow:sel?'inset 0 0 0 3px #fff, 0 0 16px rgba(255,231,76,.8)':hl?'inset 0 0 0 2px rgba(77,255,136,.9)':'none'}}>
            {cell?GLYPH[cell.t]:''}
          </div>;
        }))}
        </div>
      </div>
      <div className="text-center text-[11px] text-slate-500 mt-2">capture the king · pawns promote to queen · coordinates-free tap play</div>
      {(s.win!==null&&s.win!==undefined)&&<WinnerOverlay winnerName={names[s.win]} isMe={names[s.win]===(solo?names[0]:players[mySlot]?.name)} scores={[]} gameTitle="Grandmaster Chess" onRematch={rematch} showRematch />}
    </div>
  );
}

// ================= LUDO (2-3P, 52-track + home stretch) =================
const LUDO_COLS=['#ff2e63','#08d9d6','#ffe74c'];
const LUDO_START=[0,13,26,39];
export function Ludo(props: GameProps){
  const {mySlot,players,solo}=props;
  const n=solo?2:(players.length||2);
  const names=[0,1,2].slice(0,n).map(i=>slotName(players,i,solo));
  type S={pos:number[][];turn:number;dice:number|null;rolled:boolean;win:any;extra:boolean};
  const init=():S=>({pos:names.map(()=>[-1,-1,-1,-1]),turn:0,dice:null,rolled:false,win:null,extra:false});
  const[s,setS]=useSync(props,'ludo',init);
  const done=useRef(false);
  const[anim,setAnim]=useState(false);
  useEffect(()=>{ try{const w:any=(s as any)?.win;if(w===null||w===undefined)done.current=false;}catch{} },[s]);
  const absPos=(pi:number,rel:number)=>{
    if(rel<0)return -1;
    if(rel>=51&&rel<57)return 100+pi*10+ (rel-51); // home stretch unique
    if(rel>=57)return 200; // home
    return (LUDO_START[pi]+rel)%52;
  };
  const safeAbs=new Set([0,8,13,21,26,34,39,47]);
  const finish=(w:number)=>{if(done.current)return;done.current=true;const sc:any={};names.forEach((nm,i)=>{sc[nm]=i===w?100:(s.pos[i].filter(x=>x>=57).length*25);});props.onFinish({winnerName:names[w],winnerIndex:solo?(w===0?0:null):w,scores:sc});};
  const roll=()=>{
    if(s.win!==null&&s.win!==undefined||s.rolled)return;
    const me=solo?0:mySlot; if(s.turn!==me)return;
    setAnim(true);
    setTimeout(()=>{
      setAnim(false);
      const d=1+Math.floor(Math.random()*6);
      const movable=moves(s.pos[s.turn],d);
      if(!movable.length){
        // no move: pass (extra roll on 6 wasted)
        let nt=(s.turn+1)%n;
        setS({...s,dice:d,rolled:false,turn:nt});
        if(solo&&nt===1)setTimeout(()=>cpuTurn(),600);
        return;
      }
      setS({...s,dice:d,rolled:true});
      if(solo&&s.turn===1){}
    },450);
  };
  const moves=(tokens:number[],d:number)=>{
    const out:number[]=[];
    tokens.forEach((t,i)=>{
      if(t===-1&&d===6)out.push(i);
      else if(t>=0&&t+d<=57)out.push(i);
    });
    return out;
  };
  const moveToken=(ti:number)=>{
    if(!s.rolled||s.dice==null)return;
    const me=solo?0:mySlot; if(s.turn!==me)return;
    const d=s.dice;
    const pos=s.pos.map(a=>[...a]);
    let t=pos[s.turn][ti];
    if(t===-1){if(d!==6)return;t=0;}else t=Math.min(57,t+d);
    pos[s.turn][ti]=t;
    // captures
    if(t>=0&&t<51){
      const a=absPos(s.turn,t);
      if(!safeAbs.has(a)){
        for(let pi=0;pi<n;pi++){if(pi===s.turn)continue;
          for(let k=0;k<4;k++){const ot=pos[pi][k];if(ot>=0&&ot<51&&absPos(pi,ot)===a){pos[pi][k]=-1;}}
        }
      }
    }
    if(pos[s.turn].every(x=>x>=57)){setS({...s,pos,dice:null,rolled:false,win:s.turn});finish(s.turn);return;}
    const extra=d===6;
    let nt=extra?s.turn:(s.turn+1)%n;
    setS({...s,pos,dice:null,rolled:false,turn:nt,win:null,extra});
    if(solo&&nt===1)setTimeout(()=>cpuTurn(),600);
  };
  const cpuTurn=()=>{
    setS(cur=>{
      if(cur.win!==null&&cur.win!==undefined)return cur;
      if(cur.turn!==1)return cur;
      const d=1+Math.floor(Math.random()*6);
      const mv=moves(cur.pos[1],d);
      if(!mv.length)return {...cur,dice:null,rolled:false,turn:0};
      // prefer: leave base, capture-ish, furthest
      let ti=mv[0];
      const leaveBase=mv.find(i=>cur.pos[1][i]===-1);
      if(leaveBase!==undefined)ti=leaveBase;
      else ti=mv.sort((a,b)=>cur.pos[1][b]-cur.pos[1][a])[0];
      const pos=cur.pos.map(a=>[...a]);
      let t=pos[1][ti]; if(t===-1)t=0;else t=Math.min(57,t+d);
      pos[1][ti]=t;
      if(t>=0&&t<51){const a=absPos(1,t);if(!safeAbs.has(a)){for(let k=0;k<4;k++){const ot=pos[0][k];if(ot>=0&&ot<51&&absPos(0,ot)===a)pos[0][k]=-1;}}}
      if(pos[1].every(x=>x>=57))return {...cur,pos,win:1,dice:null,rolled:false};
      return {...cur,pos,dice:null,rolled:false,turn:(d===6?1:0)};
    });
    setTimeout(()=>{setS(cur=>{if(cur.win===1){finish(1);}return cur;});},300);
  };
  const me=solo?0:mySlot;
  const myTurn=solo||s.turn===me;
  const canMove=s.rolled&&s.dice!=null&&moves(s.pos[s.turn]||[],s.dice).length>0;
  const rematch=()=>{done.current=false;setS(init());};
  const home0=s.pos.map(a=>a.filter(x=>x>=57).length);
  return (
    <div className="max-w-lg mx-auto text-center">
      <TurnBanner text={(s.win!==null&&s.win!==undefined)?`${names[s.win]} WINS LUDO!`:(myTurn?`YOUR TURN · ${s.rolled?('MOVE '+s.dice):'ROLL!'}`:`${names[s.turn]}'S TURN`)} color={LUDO_COLS[s.turn]} />
      <div className="score-strip">{names.map((nm,i)=><span key={i} className={`score-chip ${i===me?'score-chip-me':''} ${home0[i]===Math.max(...home0)&&home0[i]>0?'score-chip-lead':''}`}><span style={{color:LUDO_COLS[i]}}>●</span> {nm} · {home0[i]}/4 🏠</span>)}</div>
      <div className="cabinet p-4" style={{borderColor:LUDO_COLS[s.turn],background:'#0d0d24'}}>
        <div className={`text-6xl mb-2 ${anim?'floaty':''}`}>{anim?'🎲':s.dice?['','⚀','⚁','⚂','⚃','⚄','⚅'][s.dice]:'🎲'}</div>
        {!s.rolled&&myTurn&&!(s.win!==null&&s.win!==undefined)&&<button className="pixel-btn" onClick={roll}>{anim?'ROLLING…':'🎲 ROLL DICE'}</button>}
        {s.rolled&&myTurn&&canMove&&<div className="text-xs font-bold mb-1" style={{color:'#4dff88'}}>You rolled {s.dice} — tap a glowing token!</div>}
        {s.rolled&&myTurn&&!canMove&&<div className="text-xs text-slate-400">No moves — passing…</div>}
        {!myTurn&&<div className="text-xs text-slate-400">Waiting for {names[s.turn]}…</div>}
        <div className="grid gap-2 mt-3" style={{gridTemplateColumns:`repeat(${n},1fr)`}}>
          {names.map((nm,pi)=>{
            const mvSet=new Set(s.rolled&&s.turn===pi&&s.dice!=null?moves(s.pos[pi],s.dice):[]);
            const active = s.turn===pi;
            return <div key={pi} className="rounded-xl p-2 card-in" style={{background:'#0a0a20',border:`2px solid ${LUDO_COLS[pi]}`,boxShadow:active?`0 0 18px ${LUDO_COLS[pi]}55`:'none',animationDelay:`${pi*0.08}s`}}>
              <div className="text-[11px] font-bold mb-1" style={{color:LUDO_COLS[pi]}}>{nm}{pi===me?' (you)':''}</div>
              <div className="flex gap-1.5 justify-center">
                {s.pos[pi].map((t,ti)=>{
                  const glow=mvSet.has(ti);
                  return <button key={ti} disabled={!(s.rolled&&s.turn===me&&pi===me&&glow)} onClick={()=>moveToken(ti)}
                    className="w-9 h-9 rounded-full font-bold text-xs"
                    style={{background:t>=57?'linear-gradient(180deg,#4dff88,#14854a)':t===-1?'#2b2b5e':LUDO_COLS[pi],color:t===-1?'#888':(t>=57?'#063':'#000'),border:glow?'3px solid #fff':'2px solid #000',boxShadow:glow?`0 0 14px ${LUDO_COLS[pi]}, 0 0 4px #fff`:'none',opacity:pi===me||s.turn===pi?1:.9,transform:glow?'scale(1.12)':'none'}}>
                    {t>=57?'★':t===-1?'·':t}
                  </button>;
                })}
              </div>
              <div className="mt-1.5 h-1.5 rounded-full overflow-hidden" style={{background:'#1c1c3d'}}>
                <div className="h-full rounded-full" style={{width:`${home0[pi]/4*100}%`,background:`linear-gradient(90deg, ${LUDO_COLS[pi]}, #fff)`,transition:'width .4s ease'}} />
              </div>
              <div className="text-[10px] text-slate-500 mt-1">track 0–50 · stretch 51–56 · ★ home</div>
            </div>;
          })}
        </div>
        <div className="text-[11px] text-slate-500 mt-3">Roll 6 to leave base · land on enemies to knock them home · stars (0/8/13/…) are safe · first to bring all 4 home wins</div>
      </div>
      {(s.win!==null&&s.win!==undefined)&&(()=>{const sc:any={};names.forEach((nm,i)=>sc[nm]=i===s.win?100:home0[i]*25);
        return <WinnerOverlay winnerName={names[s.win]} isMe={names[s.win]===(solo?names[0]:players[mySlot]?.name)} scores={names.map(nm=>[nm,sc[nm]] as [string,number])} gameTitle="Ludo Royale" onRematch={rematch} showRematch />;})()}
    </div>
  );
}

// ================= SNAKES & LADDERS (2-3P race to 100) =================
const SL_SNAKES: Record<number,number> = {16:6,47:26,49:11,56:53,62:19,64:60,87:24,93:73,95:75,98:78};
const SL_LADDERS: Record<number,number> = {1:38,4:14,9:31,21:42,28:84,36:44,51:67,71:91,80:100};
export function SnakesLadders(props: GameProps){
  const {mySlot,players,solo}=props;
  const n=solo?2:(players.length||2);
  const names=[0,1,2].slice(0,n).map(i=>slotName(players,i,solo));
  type S={pos:number[];turn:number;dice:number|null;win:any;log:string[]};
  const init=():S=>({pos:names.map(()=>0),turn:0,dice:null,win:null,log:[]});
  const[s,setS]=useSync(props,'snl',init);
  const done=useRef(false);
  const[anim,setAnim]=useState(false);
  useEffect(()=>{ try{const w:any=(s as any)?.win;if(w===null||w===undefined)done.current=false;}catch{} },[s]);
  const cols=['#ff2e63','#08d9d6','#ffe74c'];
  const finish=(w:number)=>{if(done.current)return;done.current=true;const sc:any={};names.forEach((nm,i)=>sc[nm]=s.pos[i]);props.onFinish({winnerName:names[w],winnerIndex:solo?(w===0?0:null):w,scores:sc});};
  const roll=()=>{
    if(s.win!==null&&s.win!==undefined||anim)return;
    const me=solo?0:mySlot; if(s.turn!==me)return;
    setAnim(true);
    setTimeout(()=>{
      setAnim(false);
      const d=1+Math.floor(Math.random()*6);
      const pos=[...s.pos];
      let np=pos[s.turn]+d;
      let msg=`${names[s.turn]} rolled ${d}`;
      if(np>100){np=pos[s.turn];msg+=` — bounce! need exact`; }
      else{
        if(SL_LADDERS[np]){msg+=` 🪜 ${np}→${SL_LADDERS[np]}`;np=SL_LADDERS[np];}
        else if(SL_SNAKES[np]){msg+=` 🐍 ${np}→${SL_SNAKES[np]}`;np=SL_SNAKES[np];}
        pos[s.turn]=np;
      }
      const log=[...s.log,msg].slice(-3);
      if(np===100){setS({...s,pos,dice:d,log,win:s.turn});finish(s.turn);return;}
      const extra=d===6;
      let nt=extra?s.turn:(s.turn+1)%n;
      setS({...s,pos,dice:d,log,turn:nt,win:null});
      if(solo&&nt===1)setTimeout(()=>cpuRoll(),650);
    },450);
  };
  const cpuRoll=()=>{
    setAnim(true);
    setTimeout(()=>{
      setAnim(false);
      setS(cur=>{
        if(cur.win!==null&&cur.win!==undefined)return cur;
        if(cur.turn!==1)return cur;
        const d=1+Math.floor(Math.random()*6);
        const pos=[...cur.pos];
        let np=pos[1]+d;let msg=`${names[1]} rolled ${d}`;
        if(np<=100){
          if(SL_LADDERS[np]){msg+=` 🪜 ${np}→${SL_LADDERS[np]}`;np=SL_LADDERS[np];}
          else if(SL_SNAKES[np]){msg+=` 🐍 ${np}→${SL_SNAKES[np]}`;np=SL_SNAKES[np];}
          pos[1]=np;
        } else msg+=` — bounce!`;
        const log=[...cur.log,msg].slice(-3);
        if(np===100)return {...cur,pos,dice:d,log,win:1};
        return {...cur,pos,dice:d,log,turn:(d===6?1:0)};
      });
      setTimeout(()=>{setS(cur=>{if(cur.win===1)finish(1);return cur;});},250);
    },350);
  };
  const me=solo?0:mySlot;
  const myTurn=solo||s.turn===me;
  const rematch=()=>{done.current=false;setS(init());};
  const cellContent=(v:number)=>{
    const ps:number[]=[];
    s.pos.forEach((p,i)=>{if(p===v)ps.push(i);});
    return ps;
  };
  return (
    <div className="max-w-lg mx-auto text-center">
      <TurnBanner text={(s.win!==null&&s.win!==undefined)?`${names[s.win]} REACHES 100!`:(myTurn?'YOUR ROLL':'WAITING…')} color={cols[s.turn]} />
      <div className="flex gap-2 justify-center items-center mb-2">
        <div className={`text-5xl ${anim?'floaty':''}`} style={{filter:'drop-shadow(0 4px 10px rgba(0,0,0,.6))'}}>{anim?'🎲':s.dice?['','⚀','⚁','⚂','⚃','⚄','⚅'][s.dice]:'🎲'}</div>
        {myTurn&&!(s.win!==null&&s.win!==undefined)&&<button className="pixel-btn pixel-btn-green" onClick={roll}>{anim?'ROLLING…':'ROLL!'}</button>}
      </div>
      <div className="score-strip">{names.map((nm,i)=><span key={i} className={`score-chip ${i===me?'score-chip-me':''} ${s.pos[i]===Math.max(...s.pos)&&s.pos[i]>0?'score-chip-lead':''}`}>{['🔴','🔵','🟡'][i]} {nm} · {s.pos[i]}</span>)}</div>
      <div className="text-[11px] mb-2 h-4 font-bold" style={{color:'#ffe74c'}}>{s.log[s.log.length-1]||'Roll 6 for a bonus turn · exact 100 to win'}</div>
      <div className="cabinet" style={{borderColor:'#1f9d55'}}>
        <div className="grid gap-[2px] p-2" style={{gridTemplateColumns:'repeat(10,1fr)',background:'#12351f'}}>
        {Array.from({length:100}).map((_,k)=>{
          const row=9-Math.floor(k/10);
          const v=(row%2===0)?row*10+(k%10)+1:row*10+(9-(k%10))+1;
          const here=cellContent(v);
          const isS=SL_SNAKES[v], isL=SL_LADDERS[v];
          const lead = here.length>0;
          return <div key={v} className="aspect-square rounded-[2px] flex flex-col items-center justify-center" style={{background:v===100?'linear-gradient(180deg,#ffe74c,#c79400)':isS?'rgba(255,46,99,.32)':isL?'rgba(77,255,136,.28)':'#0d2b1a',fontSize:8,color:v===100?'#231a00':'#c9c9e3',border:lead?`2px solid ${cols[here[0]]}`:'1px solid rgba(31,157,85,.5)',boxShadow:lead?`0 0 10px ${cols[here[0]]}`:'none',fontWeight:lead||v===100?800:400}}>
            <span>{v}{isS?'🐍':isL?'🪜':''}</span>
            {here.length>0&&<span style={{fontSize:9}}>{here.map(i=>['🔴','🔵','🟡'][i]).join('')}</span>}
          </div>;
        })}
        </div>
      </div>
      {(s.win!==null&&s.win!==undefined)&&(()=>{const sc:any={};names.forEach((nm,i)=>sc[nm]=s.pos[i]);
        return <WinnerOverlay winnerName={names[s.win]} isMe={names[s.win]===(solo?names[0]:players[mySlot]?.name)} scores={names.map(nm=>[nm,sc[nm]] as [string,number])} gameTitle="Snakes & Ladders" onRematch={rematch} showRematch />;})()}
    </div>
  );
}

// ================= COIN RUSH (new arcade: catch coins 45s) =================
export function CoinRush(props: GameProps){
  const {solo,playerName}=props;const{report,finalize,liveList}=useRace(props);
  const[score,setScore]=useState(0);const[started,setStarted]=useState(false);const[over,setOver]=useState(false);const[left,setLeft]=useState(45);
  const S=useRef({x:200,coins:[] as any[],bombs:[] as any[],pts:0,lives:3});
  useEffect(()=>{
    const h=(e:KeyboardEvent)=>{if(e.key==='ArrowLeft'||e.key==='a')S.current.x=Math.max(20,S.current.x-30);if(e.key==='ArrowRight'||e.key==='d')S.current.x=Math.min(380,S.current.x+30);};
    window.addEventListener('keydown',h);return ()=>window.removeEventListener('keydown',h);
  },[]);
  useEffect(()=>{
    if(!started||over)return;
    const iv=setInterval(()=>{
      const s=S.current;
      setLeft(l=>{if(l<=1){setOver(true);clearInterval(iv);return 0;}return l-1;});
      if(Math.random()<0.35)s.coins.push({x:20+Math.random()*360,y:-16,vy:2+Math.random()*2});
      if(Math.random()<0.12)s.bombs.push({x:20+Math.random()*360,y:-16,vy:2.4+Math.random()*2});
      s.coins.forEach(c=>c.y+=c.vy);s.bombs.forEach(c=>c.y+=c.vy);
      s.coins=s.coins.filter(c=>c.y<320);s.bombs=s.bombs.filter(c=>c.y<320);
      for(const c of s.coins){if(Math.abs(c.x-s.x)<30&&Math.abs(c.y-262)<24){c.y=999;s.pts+=10;setScore(s.pts);report(s.pts);}}
      s.coins=s.coins.filter(c=>c.y<320);
      for(const b of s.bombs){if(Math.abs(b.x-s.x)<26&&Math.abs(b.y-262)<22){b.y=999;s.lives--;if(s.lives<=0){setOver(true);clearInterval(iv);return;}s.pts=Math.max(0,s.pts-25);setScore(s.pts);}}
      s.bombs=s.bombs.filter(c=>c.y<320);
    },30);
    return ()=>clearInterval(iv);
  },[started,over]);
  const ref=useCanvasMini((ctx)=>{
    const g=ctx.createLinearGradient(0,0,0,300);g.addColorStop(0,'#0b1e3d');g.addColorStop(1,'#070714');ctx.fillStyle=g;ctx.fillRect(0,0,400,300);
    const s=S.current;
    ctx.fillStyle='#ffe74c';s.coins.forEach((c:any)=>{ctx.beginPath();ctx.arc(c.x,c.y,9,0,7);ctx.fill();ctx.fillStyle='#c79400';ctx.fillRect(c.x-2,c.y-6,4,12);ctx.fillStyle='#ffe74c';});
    ctx.fillStyle='#ff2e63';s.bombs.forEach((c:any)=>{ctx.beginPath();ctx.arc(c.x,c.y,10,0,7);ctx.fill();ctx.fillStyle='#fff';ctx.fillRect(c.x-5,c.y-1,10,2);ctx.fillStyle='#ff2e63';});
    ctx.fillStyle='#08d9d6';ctx.fillRect(s.x-22,256,44,16);ctx.beginPath();ctx.arc(s.x,256,14,Math.PI,0);ctx.fill();
    ctx.fillStyle='#fff';ctx.font='12px monospace';ctx.fillText(`❤ ${s.lives}`,10,20);
  });
  return (<div className="max-w-md mx-auto text-center">
    <TurnBanner text={over?`TIME! ${score}`:`${score} PTS · ${left}s`} color="#ffe74c" />
    {!solo&&<RaceBarMini live={liveList} me={playerName} score={score} />}
    <div className="text-xs text-slate-400 mb-2">← → / mouse · catch 🪙 (+10), dodge 💣 (−25 & −1❤)</div>
    <div className="cabinet"><canvas ref={ref} width={400} height={300} className="cabinet-canvas"
      onMouseMove={(e)=>{const r=(e.target as any).getBoundingClientRect();S.current.x=Math.max(20,Math.min(380,(e.clientX-r.left)/r.width*400));}} /></div>
    <div className="flex gap-2 justify-center mt-3">
      {!started?<button className="pixel-btn" onClick={()=>{S.current={x:200,coins:[],bombs:[],pts:0,lives:3};setScore(0);setLeft(45);setOver(false);setStarted(true);}}>▶ Grab coins!</button>
      :over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:playerName,winnerIndex:0,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>
      :<button className="pixel-btn pixel-btn-ghost" onClick={()=>setOver(true)}>End run</button>}
    </div></div>);
}
