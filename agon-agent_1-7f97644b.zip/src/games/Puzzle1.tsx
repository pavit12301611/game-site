import { useEffect, useMemo, useRef, useState } from 'react';
import { useSync, useRace, TurnBanner, WinnerOverlay } from './shared';
import type { GameProps } from './types';
import { slotName } from './types';

function RaceBar({ live, me, score }: { live: [string, number][]; me: string; score: number }) {
  const rows = live.map(([n, s]) => n.includes('(you)') ? [me + ' (you)', score] as [string, number] : [n, s] as [string, number]);
  if (!rows.filter(([n]) => !n.includes('(you)')).length && rows.length <= 1) return null;
  const sorted = [...rows].sort((a,b)=>b[1]-a[1]);
  const top = sorted[0]?.[1] ?? 0;
  return (<div className="score-strip">{sorted.map(([n,s],i)=>(<span key={i} className={`score-chip ${n.includes('(you)')?'score-chip-me':''} ${s===top&&s>0?'score-chip-lead':''}`}>{i===0?'👑 ':i+1+'. '}{n}: {s}</span>))}</div>);
}

// ============ 2048 RACE (3 min) ============
export function G2048(props: GameProps){
  const {solo,playerName}=props;const{report,finalize,liveList}=useRace(props);
  const[grid,setGrid]=useState<number[][]>([]);const[score,setScore]=useState(0);const[over,setOver]=useState(false);const[started,setStarted]=useState(false);const[left,setLeft]=useState(180);
  const G=useRef({g:[[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]],pts:0});
  const spawn=(g:number[][])=>{const e: [number,number][]=[];for(let r=0;r<4;r++)for(let c=0;c<4;c++)if(!g[r][c])e.push([r,c]);if(e.length){const [r,c]=e[Math.floor(Math.random()*e.length)];g[r][c]=Math.random()<0.9?2:4;}};
  const slide=(row:number[])=>{const a=row.filter(v=>v);for(let i=0;i<a.length-1;i++)if(a[i]===a[i+1]){a[i]*=2;G.current.pts+=a[i];a.splice(i+1,1);}while(a.length<4)a.push(0);return a;};
  const move=(d:string)=>{
    if(!started||over)return;
    const g=G.current.g.map(r=>[...r]);let moved=false;
    const rot=(m:number[][],t:number)=>{let x=m;for(let i=0;i<t;i++)x=x[0].map((_,c)=>x.map(r=>r[c]).reverse());return x;};
    const times=d==='left'?0:d==='up'?3:d==='right'?2:1;
    let x=rot(g,times);const nx=x.map(r=>{const s=slide(r);if(s.join()!==r.join())moved=true;return s;});let back=rot(nx,(4-times)%4);
    if(!moved)return;
    spawn(back);G.current.g=back;setGrid(back.map(r=>[...r]));setScore(G.current.pts);report(G.current.pts);
    if(!back.flat().some(v=>!v)){setOver(true);}
  };
  useEffect(()=>{const h=(e:KeyboardEvent)=>{if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();move(e.key.replace('Arrow','').toLowerCase());}};window.addEventListener('keydown',h);return ()=>window.removeEventListener('keydown',h);});
  useEffect(()=>{if(!started||over)return;const iv=setInterval(()=>{setLeft(l=>{if(l<=1){setOver(true);clearInterval(iv);return 0;}return l-1;});},1000);return ()=>clearInterval(iv);},[started,over]);
  const start=()=>{G.current={g:[[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]],pts:0};spawn(G.current.g);spawn(G.current.g);setGrid(G.current.g.map(r=>[...r]));setScore(0);setLeft(180);setOver(false);setStarted(true);};
  const mm=Math.floor(left/60),ss=left%60;
  return (<div className="max-w-xs mx-auto text-center">
    <TurnBanner text={over?`TIME! ${score}`:`${score} PTS · ${mm}:${String(ss).padStart(2,'0')}`} color="#ffe74c" />
    {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
    <div className="text-xs text-slate-400 mb-2">Arrows / WASD · biggest score in 3 min wins</div>
    <div className="grid grid-cols-4 gap-2 p-2 rounded-xl" style={{background:'#3b3a1e',border:'3px solid #6b6420'}}>
      {(grid.length?grid:[[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]]).map((row,r)=>row.map((v,c)=>{
        const bg=v===0?'#1c1c3d':v===2?'#eee4da':v===4?'#ede0c8':v===8?'#f2b179':v===16?'#f59563':v===32?'#f67c5f':v===64?'#f65e3b':v===128?'#edcf72':v===256?'#edcc61':'#edc850';
        return <div key={r+'-'+c} className="aspect-square rounded-lg flex items-center justify-center font-pixel" style={{background:bg,color:v>4?'#fff':'#776e65',fontSize:v>999?11:v>99?13:16}}>{v||''}</div>; }))}
    </div>
    <div className="grid grid-cols-3 gap-1 max-w-[220px] mx-auto mt-2 sm-hidden-dpad">
      {['▲','◀','▼','▶'].map(a=><button key={a} className="pixel-btn pixel-btn-ghost !px-2" onClick={()=>move(a==='▲'?'up':a==='▼'?'down':a==='◀'?'left':'right')}>{a}</button>)}
    </div>
    <div className="flex gap-2 justify-center mt-3">
      {!started?<button className="pixel-btn" onClick={start}>▶ Start 3-min race</button>
      :over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:playerName,winnerIndex:0,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>
      :<button className="pixel-btn pixel-btn-ghost" onClick={()=>setOver(true)}>End run</button>}
    </div></div>);
}

// ============ MINESWEEPER SPRINT ============
const WORDS9 = 9;
export function MinesGame(props: GameProps){
  const {solo,playerName}=props;const{report,finalize,liveList}=useRace(props);
  const N=9,MINES=10;
  const[grid,setGrid]=useState<number[]>([]);const[open,setOpen]=useState<boolean[]>([]);const[flag,setFlag]=useState<boolean[]>([]);
  const[over,setOver]=useState(false);const[won,setWon]=useState(false);const[sec,setSec]=useState(0);const[started,setStarted]=useState(false);const[score,setScore]=useState(0);
  const start=()=>{
    const g=Array(N*N).fill(0);let placed=0;
    while(placed<MINES){const i=Math.floor(Math.random()*N*N);if(g[i]!==-1){g[i]=-1;placed++;}}
    for(let r=0;r<N;r++)for(let c=0;c<N;c++){const i=r*N+c;if(g[i]===-1)continue;let k=0;for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++){const nr=r+dr,nc=c+dc;if(nr>=0&&nr<N&&nc>=0&&nc<N&&g[nr*N+nc]===-1)k++;}g[i]=k;}
    setGrid(g);setOpen(Array(N*N).fill(false));setFlag(Array(N*N).fill(false));setOver(false);setWon(false);setSec(0);setScore(0);setStarted(true);
  };
  useEffect(()=>{if(!started||over)return;const iv=setInterval(()=>setSec(s=>s+1),1000);return ()=>clearInterval(iv);},[started,over]);
  const flood=(g:number[],o:boolean[],i:number)=>{
    const st=[i];
    while(st.length){const x=st.pop()!;if(o[x])continue;o[x]=true;if(g[x]===0){const r=Math.floor(x/N),c=x%N;for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++){const nr=r+dr,nc=c+dc;if(nr>=0&&nr<N&&nc>=0&&nc<N){const ni=nr*N+nc;if(!o[ni]&&g[ni]!==-1)st.push(ni);}}}}
  };
  const reveal=(i:number)=>{
    if(!started||over||open[i]||flag[i])return;
    if(grid[i]===-1){const o=[...open];o[i]=true;setOpen(o);setOver(true);return;}
    const o=[...open];flood(grid,o,i);setOpen(o);
    const opened=o.filter(Boolean).length;
    const sc=opened*10-Math.floor(sec/2);
    setScore(Math.max(0,sc));report(Math.max(0,sc));
    if(opened===N*N-MINES){setOver(true);setWon(true);const bonus=Math.max(0,500-sec*5);setScore(sc+bonus);report(sc+bonus);}
  };
  const toggleFlag=(i:number)=>{if(!started||over||open[i])return;const f=[...flag];f[i]=!f[i];setFlag(f);};
  return (<div className="max-w-sm mx-auto text-center">
    <TurnBanner text={over?(won?`CLEARED · ${score}`:`BOOM · ${score}`):`${score} PTS · ${sec}s`} color="#ff9f1c" />
    {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
    <div className="text-xs text-slate-400 mb-2">Click reveal · right-click flag · clear all safe cells</div>
    <div className="grid gap-[3px] p-2 rounded-xl" style={{gridTemplateColumns:`repeat(${N},1fr)`,background:'#3b2c12',border:'3px solid #6b5320'}}>
      {Array.from({length:N*N}).map((_,i)=>{
        const isO=open[i];
        return <button key={i} onClick={()=>reveal(i)} onContextMenu={(e)=>{e.preventDefault();toggleFlag(i);}}
          className="aspect-square rounded-[3px] font-bold text-sm flex items-center justify-center"
          style={{background:isO?(grid[i]===-1?'#ff2e63':(grid[i]===0?'#0d0d24':'#1c1c3d')):'#d9b06a',color:['#888','#38bdf8','#4dff88','#ff2e63','#a06bff','#ff9f1c','#08d9d6','#fff','#ffe74c'][grid[i]||0]}}>
          {isO?(grid[i]===-1?'💣':grid[i]||''):(flag[i]?'🚩':'')}</button>;})}
    </div>
    <div className="flex gap-2 justify-center mt-3">
      {!started?<button className="pixel-btn" onClick={start}>▶ Start field</button>
      :over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:won?playerName:null,winnerIndex:won?0:null,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>
      :<span className="text-xs text-slate-500">🚩 {MINES - flag.filter(Boolean).length} mines left</span>}
    </div></div>);
}

// ============ MEMORY MATCH (turn-based 2-3P) ============
const EMOJI=['👾','🚀','🍕','🎮','🐸','⚡','🍩','👻','🎲','🦄','🍉','🤖'];
export function MemoryGame(props: GameProps){
  const {mySlot,players,solo}=props;
  const n=solo?2:(players.length||2);
  const names=[0,1,2].slice(0,n).map(i=>slotName(players,i,solo));
  const seedStr=props.room?.code||'solo-mem';
  type S={deck:string[];open:number[];matched:number[];turn:number;pairs:number[];win:any};
  const init=():S=>{
    let h=2166136261;for(let i=0;i<seedStr.length;i++){h^=seedStr.charCodeAt(i);h=Math.imul(h,16777619);}let a=h>>>0;
    const rng=()=>{a|=0;a=(a+0x6D2B79F5)|0;let t=Math.imul(a^(a>>>15),1|a);t=(t+Math.imul(t^(t>>>7),61|t))^t;return((t^(t>>>14))>>>0)/4294967296;};
    const d=[...EMOJI.slice(0,9),...EMOJI.slice(0,9)];
    for(let i=d.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[d[i],d[j]]=[d[j],d[i]];}
    return {deck:d,open:[],matched:[],turn:0,pairs:names.map(()=>0),win:null};
  };
  const[s,setS]=useSync(props,'mem',init);
  const done=useRef(false);
  const busy=useRef(false);
  const cols=['#ff2e63','#08d9d6','#ffe74c'];
  const finish=()=>{if(done.current)return;done.current=true;const sc:any={};names.forEach((nm,i)=>sc[nm]=s.pairs[i]);let wi=0;s.pairs.forEach((p,i)=>{if(p>s.pairs[wi])wi=i;});const tie=s.pairs.filter(p=>p===s.pairs[wi]).length>1;props.onFinish({winnerName:tie?null:names[wi],winnerIndex:tie?null:(solo?(wi===0?0:null):wi),scores:sc});};
  if(s.matched.length===18)setTimeout(()=>{if(!done.current)finish();},120);
  const flip=(i:number)=>{
    if(s.win||busy.current||s.open.includes(i)||s.matched.includes(i))return;
    const me=solo?0:mySlot;
    if(s.turn!==me)return;
    if(solo&&s.turn!==0)return;
    const open=[...s.open,i];
    if(open.length<2){setS({...s,open});return;}
    busy.current=true;setS({...s,open});
    setTimeout(()=>{
      busy.current=false;
      const [a,b]=open;
      if(s.deck[a]===s.deck[b]){
        const matched=[...s.matched,a,b];const pairs=[...s.pairs];pairs[s.turn]++;
        let ns={...s,open:[],matched,pairs};
        if(solo){
          // cpu takes a turn after player scores? player continues on match
          setS(ns);
          if(matched.length===18)finish();
          return;
        }
        setS(ns); // scorer goes again
        if(matched.length===18)finish();
      } else {
        let nt=(s.turn+1)%n;
        setS({...s,open:[],turn:nt});
        if(solo&&nt===1){
          // cpu random move
          setTimeout(()=>{
            setS(cur=>{
              const un=cur.deck.map((_,x)=>x).filter(x=>!cur.matched.includes(x)&&!cur.open.includes(x));
              if(un.length<2)return cur;
              const x1=un[Math.floor(Math.random()*un.length)];let x2=un[Math.floor(Math.random()*un.length)];
              if(x2===x1)x2=un[(un.indexOf(x1)+1)%un.length];
              if(cur.deck[x1]===cur.deck[x2]){const pairs2=[...cur.pairs];pairs2[1]++;return {...cur,matched:[...cur.matched,x1,x2],open:[],turn:0};}
              return {...cur,open:[],turn:0};
            });
          },700);
        }
      }
    },650);
  };
  const myTurn=solo||s.turn===mySlot;
  const rematch=()=>{done.current=false;setS(init());};
  const isDone=s.matched.length===18;
  return (<div className="max-w-md mx-auto">
    <TurnBanner text={isDone?'GAME OVER':(myTurn?'YOUR TURN':'WAITING…')} color={cols[s.turn]} />
    <div className="flex gap-3 justify-center text-xs font-bold mb-3">{names.map((nm,i)=><span key={i} style={{color:cols[i]}}>{nm}: {s.pairs[i]} pairs</span>)}</div>
    <div className="grid grid-cols-6 gap-1.5">
      {s.deck.map((e,i)=>{
        const face=s.open.includes(i)||s.matched.includes(i);
        return <button key={i} onClick={()=>flip(i)} className="game-grid-cell clickable aspect-square rounded-lg text-xl flex items-center justify-center"
          style={{background:face?(s.matched.includes(i)?'rgba(77,255,136,.2)':'#1c1c3d'):'#2b2b5e',border:s.matched.includes(i)?'2px solid #4dff88':'2px solid #3d3d7a'}}>{face?e:'?'}</button>;})}
    </div>
    {isDone&&(()=>{let wi=0;s.pairs.forEach((p,i)=>{if(p>s.pairs[wi])wi=i;});const tie=s.pairs.filter(p=>p===s.pairs[wi]).length>1;const sc:any={};names.forEach((nm,i)=>sc[nm]=s.pairs[i]);
      return <WinnerOverlay winnerName={tie?null:names[wi]} isMe={!tie&&names[wi]===(solo?names[0]:players[mySlot]?.name)} scores={names.map(nm=>[nm,sc[nm]] as [string,number])} gameTitle="Memory Match" onRematch={rematch} showRematch />;})()}
  </div>);
}

// ============ SIMON ============
export function SimonGame(props: GameProps){
  const {solo,playerName}=props;const{report,finalize,liveList}=useRace(props);
  const[seq,setSeq]=useState<number[]>([]);const[show,setShow]=useState(false);const[lit,setLit]=useState(-1);
  const[idx,setIdx]=useState(0);const[round,setRound]=useState(0);const[over,setOver]=useState(false);const[started,setStarted]=useState(false);
  const cols=['#ff2e63','#ffe74c','#4dff88','#08d9d6'];
  const playSeq=(s:number[])=>{
    setShow(true);let i=0;setLit(-1);
    const iv=setInterval(()=>{if(i>=s.length){clearInterval(iv);setShow(false);setLit(-1);setIdx(0);return;}setLit(s[i]);setTimeout(()=>setLit(-1),320);i++;},520);
  };
  const start=()=>{const s=[Math.floor(Math.random()*4)];setSeq(s);setRound(1);setOver(false);setStarted(true);setTimeout(()=>playSeq(s),500);};
  const press=(c:number)=>{
    if(!started||over||show)return;
    if(c===seq[idx]){
      const ni=idx+1;
      if(ni===seq.length){
        const nr=round+1;setRound(nr);report((nr-1)*10);
        const ns=[...seq,Math.floor(Math.random()*4)];setSeq(ns);setShow(true);
        setTimeout(()=>playSeq(ns),700);
      } else setIdx(ni);
    } else setOver(true);
  };
  const score=(round-1)*10;
  return (<div className="max-w-xs mx-auto text-center">
    <TurnBanner text={over?`BUZZ · ROUND ${round}`:`ROUND ${Math.max(1,round)} · SCORE ${score}`} color="#08d9d6" />
    {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
    <div className="text-xs text-slate-400 mb-3">Watch, then repeat the sequence</div>
    <div className="grid grid-cols-2 gap-3 max-w-[280px] mx-auto">
      {cols.map((c,i)=><button key={i} onClick={()=>press(i)} className="aspect-square rounded-2xl" style={{background:c,opacity:lit===i?1:(show?0.35:0.75),boxShadow:lit===i?`0 0 30px ${c}`:'none',border:'3px solid #000'}}/>)}
    </div>
    <div className="flex gap-2 justify-center mt-4">
      {!started?<button className="pixel-btn" onClick={start}>▶ Start signals</button>
      :over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:playerName,winnerIndex:0,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>
      :show?<span className="text-xs text-slate-400 blink font-pixel">WATCH…</span>:<span className="text-xs font-pixel" style={{color:'#4dff88'}}>YOUR MOVE</span>}
    </div></div>);
}
