import { useEffect, useRef, useState } from 'react';
import { useRace, TurnBanner } from './shared';
import type { GameProps } from './types';

function RaceBar({ live, me, score }: { live: [string, number][]; me: string; score: number }) {
  const rows = live.map(([n, s]) => n.includes('(you)') ? [me + ' (you)', score] as [string, number] : [n, s] as [string, number]);
  if (!rows.filter(([n]) => !n.includes('(you)')).length && rows.length <= 1) return null;
  const sorted = [...rows].sort((a,b)=>b[1]-a[1]);
  const top = sorted[0]?.[1] ?? 0;
  return (<div className="score-strip">{sorted.map(([n,s],i)=>(<span key={i} className={`score-chip ${n.includes('(you)')?'score-chip-me':''} ${s===top&&s>0?'score-chip-lead':''}`}>{i===0?'👑 ':i+1+'. '}{n}: {s}</span>))}</div>);
}
function useCanvas(draw: (ctx:any,t:number)=>void){
  const ref=useRef<HTMLCanvasElement>(null);
  useEffect(()=>{let raf=0;const t0=performance.now();const loop=(t:number)=>{const c=ref.current;if(c){const ctx=c.getContext('2d');if(ctx)draw(ctx,(t-t0)/1000);}raf=requestAnimationFrame(loop);};raf=requestAnimationFrame(loop);return ()=>cancelAnimationFrame(raf);},[]);
  return ref;
}

// -------- MIDNIGHT RACER --------
export function RacerGame(props: GameProps){
  const {solo,playerName}=props;const{report,finalize,liveList}=useRace(props);
  const[score,setScore]=useState(0);const[started,setStarted]=useState(false);const[over,setOver]=useState(false);const[spd,setSpd]=useState(1);
  const S=useRef({x:200,cars:[] as any[],pts:0,dist:0,sp:1});
  useEffect(()=>{
    const h=(e:KeyboardEvent)=>{if(e.key==='ArrowLeft'||e.key==='a')S.current.x=Math.max(60,S.current.x-26);if(e.key==='ArrowRight'||e.key==='d')S.current.x=Math.min(340,S.current.x+26);if(e.key==='ArrowUp'||e.key==='w')S.current.sp=Math.min(3,S.current.sp+0.25);if(e.key==='ArrowDown'||e.key==='s')S.current.sp=Math.max(0.6,S.current.sp-0.25);};
    window.addEventListener('keydown',h);return ()=>window.removeEventListener('keydown',h);
  },[]);
  useEffect(()=>{
    if(!started||over)return;
    const iv=setInterval(()=>{
      const s=S.current;
      s.dist+=s.sp;const pts=Math.floor(s.dist/10);if(pts!==s.pts){s.pts=pts;setScore(pts);report(pts);setSpd(s.sp);}
      if(Math.random()<0.05+s.sp*0.02)s.cars.push({x:60+Math.random()*280,y:-40,sp:2+s.sp*2,col:['#ff2e63','#08d9d6','#ffe74c'][Math.floor(Math.random()*3)]});
      s.cars.forEach(c=>c.y+=c.sp);s.cars=s.cars.filter(c=>c.y<340);
      if(s.cars.some(c=>Math.abs(c.x-s.x)<34&&Math.abs(c.y-240)<46)){setOver(true);clearInterval(iv);}
    },20);
    return ()=>clearInterval(iv);
  },[started,over]);
  const ref=useCanvas((ctx,t)=>{
    ctx.fillStyle='#0c0c1e';ctx.fillRect(0,0,400,300);
    ctx.fillStyle='#1c1c3d';ctx.fillRect(40,0,320,300);
    ctx.strokeStyle='#ffe74c';ctx.setLineDash([18,18]);ctx.lineDashOffset=-t*160;ctx.beginPath();ctx.moveTo(133,0);ctx.lineTo(133,300);ctx.stroke();ctx.beginPath();ctx.moveTo(200,0);ctx.lineTo(200,300);ctx.stroke();ctx.beginPath();ctx.moveTo(266,0);ctx.lineTo(266,300);ctx.stroke();ctx.setLineDash([]);
    const s=S.current;
    s.cars.forEach(c=>{ctx.fillStyle=c.col;ctx.fillRect(c.x-16,c.y-22,32,44);ctx.fillStyle='#0a0a20';ctx.fillRect(c.x-16,c.y-12,32,24);});
    ctx.fillStyle='#4dff88';ctx.fillRect(s.x-16,218,32,44);ctx.fillStyle='#0a0a20';ctx.fillRect(s.x-12,230,24,20);
  });
  return (<div className="max-w-md mx-auto text-center">
    <TurnBanner text={over?`CRASH · ${score}m`:`${score}m · x${spd.toFixed(1)}`} color="#ff2e63" />
    {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
    <div className="text-xs text-slate-400 mb-2">← → steer · ↑ ↓ speed · dodge & go far</div>
    <div className="cabinet"><canvas ref={ref} width={400} height={300} className="cabinet-canvas" onMouseMove={(e)=>{const r=(e.target as any).getBoundingClientRect();S.current.x=Math.max(60,Math.min(340,(e.clientX-r.left)/r.width*400));}} /></div>
    <div className="flex gap-2 justify-center mt-3">
      {!started?<button className="pixel-btn" onClick={()=>{S.current={x:200,cars:[],pts:0,dist:0,sp:1};setScore(0);setOver(false);setStarted(true);}}>▶ Start engine</button>
      :over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:playerName,winnerIndex:0,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>
      :<button className="pixel-btn pixel-btn-ghost" onClick={()=>setOver(true)}>End run</button>}
    </div></div>);
}

// -------- TANK BATTLE (you vs 2 CPUs in maze) --------
export function TanksGame(props: GameProps){
  const {solo,playerName,players,mySlot}=props;const{report,finalize,liveList}=useRace(props);
  const[score,setScore]=useState(0);const[started,setStarted]=useState(false);const[over,setOver]=useState(false);const[msg,setMsg]=useState('');
  const S=useRef({me:{x:40,y:260,a:-1.57,cd:0},foes:[{x:360,y:40,a:1.57,cd:40,alive:true,c:'#ff2e63'},{x:360,y:260,a:2.5,cd:80,alive:true,c:'#ffe74c'}],bullets:[] as any[],eb:[] as any[],pts:0,keys:{} as any,t:0});
  useEffect(()=>{
    const d=(e:KeyboardEvent)=>{S.current.keys[e.key.toLowerCase()]=true;if(['arrowup','arrowdown','arrowleft','arrowright',' '].includes(e.key))e.preventDefault();};
    const u=(e:KeyboardEvent)=>{S.current.keys[e.key.toLowerCase()]=false;};
    window.addEventListener('keydown',d);window.addEventListener('keyup',u);
    return ()=>{window.removeEventListener('keydown',d);window.removeEventListener('keyup',u);};
  },[]);
  useEffect(()=>{
    if(!started||over)return;
    const iv=setInterval(()=>{
      const s=S.current;const k=s.keys;s.t++;
      if(k['arrowleft']||k['a'])s.me.a-=0.09;if(k['arrowright']||k['d'])s.me.a+=0.09;
      if(k['arrowup']||k['w']){s.me.x=Math.max(14,Math.min(386,s.me.x+Math.cos(s.me.a)*3));s.me.y=Math.max(14,Math.min(286,s.me.y+Math.sin(s.me.a)*3));}
      if(k['arrowdown']||k['s']){s.me.x=Math.max(14,Math.min(386,s.me.x-Math.cos(s.me.a)*2));s.me.y=Math.max(14,Math.min(286,s.me.y-Math.sin(s.me.a)*2));}
      s.me.cd=Math.max(0,s.me.cd-1);
      if((k[' ']||k['enter'])&&s.me.cd<=0){s.bullets.push({x:s.me.x+Math.cos(s.me.a)*18,y:s.me.y+Math.sin(s.me.a)*18,vx:Math.cos(s.me.a)*5.5,vy:Math.sin(s.me.a)*5.5,l:120});s.me.cd=22;}
      s.foes.forEach((f,i)=>{
        if(!f.alive)return;f.cd--;
        const dx=s.me.x-f.x,dy=s.me.y-f.y;const want=Math.atan2(dy,dx);
        let d=want-f.a;while(d>Math.PI)d-=2*Math.PI;while(d<-Math.PI)d+=2*Math.PI;
        f.a+=Math.sign(d)*0.05;
        if(Math.abs(d)<0.4){f.x=Math.max(14,Math.min(386,f.x+Math.cos(f.a)*1.6));f.y=Math.max(14,Math.min(286,f.y+Math.sin(f.a)*1.6));}
        if(f.cd<=0&&Math.abs(d)<0.25){s.eb.push({x:f.x+Math.cos(f.a)*18,y:f.y+Math.sin(f.a)*18,vx:Math.cos(f.a)*4,vy:Math.sin(f.a)*4,l:120});f.cd=90+Math.random()*60;}
      });
      s.bullets.forEach(b=>{b.x+=b.vx;b.y+=b.vy;b.l--;});s.bullets=s.bullets.filter(b=>b.l>0&&b.x>0&&b.x<400&&b.y>0&&b.y<300);
      s.eb.forEach(b=>{b.x+=b.vx;b.y+=b.vy;b.l--;});s.eb=s.eb.filter(b=>b.l>0&&b.x>0&&b.x<400&&b.y>0&&b.y<300);
      for(const b of s.bullets)for(const f of s.foes){if(f.alive&&Math.hypot(b.x-f.x,b.y-f.y)<15){f.alive=false;b.l=0;s.pts+=100;setScore(s.pts);report(s.pts);}}
      if(s.eb.some(b=>Math.hypot(b.x-s.me.x,b.y-s.me.y)<14)){setOver(true);setMsg('YOUR TANK WAS HIT!');clearInterval(iv);return;}
      if(s.foes.every(f=>!f.alive)){setOver(true);setMsg('BASE CLEARED! +time bonus');s.pts+=Math.max(0,300-Math.floor(s.t/3));setScore(s.pts);clearInterval(iv);}
    },20);
    const to=setTimeout(()=>{setOver(true);setMsg('TIME UP');},60000);
    return ()=>{clearInterval(iv);clearTimeout(to);};
  },[started,over]);
  const ref=useCanvas((ctx)=>{
    ctx.fillStyle='#0d1a0d';ctx.fillRect(0,0,400,300);
    ctx.strokeStyle='#1f9d55';ctx.strokeRect(4,4,392,292);
    ctx.fillStyle='#14301a';[[120,80,60,20],[260,180,60,20],[80,200,50,16],[270,90,40,60]].forEach(([x,y,w,h])=>ctx.fillRect(x,y,w,h));
    const s=S.current;
    const draw=(x:number,y:number,a:number,c:string)=>{ctx.save();ctx.translate(x,y);ctx.rotate(a);ctx.fillStyle=c;ctx.fillRect(-11,-8,22,16);ctx.fillStyle='#0a0a20';ctx.fillRect(2,-3,12,6);ctx.restore();};
    draw(s.me.x,s.me.y,s.me.a,'#4dff88');
    s.foes.forEach(f=>{if(f.alive)draw(f.x,f.y,f.a,f.c);});
    ctx.fillStyle='#ffe74c';s.bullets.forEach(b=>{ctx.beginPath();ctx.arc(b.x,b.y,3,0,7);ctx.fill();});
    ctx.fillStyle='#ff2e63';s.eb.forEach(b=>{ctx.beginPath();ctx.arc(b.x,b.y,3,0,7);ctx.fill();});
  });
  return (<div className="max-w-md mx-auto text-center">
    <TurnBanner text={over?`${msg} · ${score}`:`${score} PTS`} color="#4dff88" />
    {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
    <div className="text-xs text-slate-400 mb-2">WASD/arrows drive · SPACE fire · destroy both CPU tanks</div>
    <div className="cabinet"><canvas ref={ref} width={400} height={300} className="cabinet-canvas" /></div>
    <div className="flex gap-2 justify-center mt-3">
      {!started?<button className="pixel-btn" onClick={()=>{S.current={me:{x:40,y:260,a:-1.57,cd:0},foes:[{x:360,y:40,a:1.57,cd:40,alive:true,c:'#ff2e63'},{x:360,y:260,a:2.5,cd:80,alive:true,c:'#ffe74c'}],bullets:[],eb:[],pts:0,keys:{},t:0};setScore(0);setOver(false);setMsg('');setStarted(true);}}>▶ Deploy</button>
      :over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{const cleared=S.current.foes.every(f=>!f.alive);if(solo)props.onFinish({winnerName:cleared?playerName:null,winnerIndex:cleared?0:null,scores:{[playerName]:score}});else finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>
      :<button className="pixel-btn pixel-btn-ghost" onClick={()=>{setOver(true);setMsg('RETREAT');}}>Retreat</button>}
    </div></div>);
}

// -------- BOMBER GRID (Bomberman-lite vs CPUs, 11x9) --------
export function BomberGame(props: GameProps){
  const{solo,playerName}=props;const{report,finalize,liveList}=useRace(props);
  const[score,setScore]=useState(0);const[started,setStarted]=useState(false);const[over,setOver]=useState(false);
  const W=11,H=9;
  const S=useRef({me:{x:1,y:1,alive:true},cpus:[{x:W-2,y:H-2,alive:true,c:'#ff2e63',t:0},{x:W-2,y:1,alive:true,c:'#08d9d6',t:0}],bombs:[] as any[],fires:[] as any[],pts:0,t:0});
  useEffect(()=>{
    const h=(e:KeyboardEvent)=>{const s=S.current;if(!s.me.alive)return;
      if(e.key==='ArrowUp'||e.key==='w')tryMove(0,-1);if(e.key==='ArrowDown'||e.key==='s')tryMove(0,1);
      if(e.key==='ArrowLeft'||e.key==='a')tryMove(-1,0);if(e.key==='ArrowRight'||e.key==='d')tryMove(1,0);
      if(e.key===' '){e.preventDefault();drop(s.me.x,s.me.y);}
    };
    const tryMove=(dx:number,dy:number)=>{const s=S.current;const nx=s.me.x+dx,ny=s.me.y+dy;if(nx<0||ny<0||nx>=W||ny>=H)return;if(nx%2===1&&ny%2===1)return;if(s.bombs.some(b=>b.x===nx&&b.y===ny))return;s.me.x=nx;s.me.y=ny;};
    const drop=(x:number,y:number)=>{const s=S.current;if(s.bombs.some(b=>b.x===x&&b.y===y))return;s.bombs.push({x,y,t:26});};
    (window as any).__bomberDrop=drop;
    window.addEventListener('keydown',h);return ()=>window.removeEventListener('keydown',h);
  },[]);
  useEffect(()=>{
    if(!started||over)return;
    const iv=setInterval(()=>{
      const s=S.current;s.t++;
      s.bombs.forEach(b=>b.t--);
      const boom=s.bombs.filter(b=>b.t<=0);s.bombs=s.bombs.filter(b=>b.t>0);
      boom.forEach(b=>{
        const cells=[{x:b.x,y:b.y},{x:b.x+1,y:b.y},{x:b.x-1,y:b.y},{x:b.x,y:b.y+1},{x:b.x,y:b.y-1}].filter(c=>c.x>=0&&c.y>=0&&c.x<W&&c.y<H&&!(c.x%2===1&&c.y%2===1));
        cells.forEach(c=>s.fires.push({...c,t:9}));
        if(s.me.alive&&cells.some(c=>c.x===s.me.x&&c.y===s.me.y))s.me.alive=false;
        s.cpus.forEach(cp=>{if(cp.alive&&cells.some(c=>c.x===cp.x&&c.y===cp.y)){cp.alive=false;s.pts+=150;setScore(s.pts);report(s.pts);}});
      });
      s.fires.forEach(f=>f.t--);s.fires=s.fires.filter(f=>f.t>0);
      s.cpus.forEach(cp=>{
        if(!cp.alive)return;cp.t++;
        const danger=s.bombs.some(b=>Math.abs(b.x-cp.x)+Math.abs(b.y-cp.y)<3);
        const opts=[[1,0],[-1,0],[0,1],[0,-1]].filter(([dx,dy])=>{const nx=cp.x+dx,ny=cp.y+dy;return nx>=0&&ny>=0&&nx<W&&ny<H&&!(nx%2===1&&ny%2===1)&&!s.bombs.some(b=>b.x===nx&&b.y===ny)&&!s.fires.some(f=>f.x===nx&&f.y===ny);});
        if(danger&&opts.length){const [dx,dy]=opts[Math.floor(Math.random()*opts.length)];cp.x+=dx;cp.y+=dy;}
        else if(cp.t%14===0&&opts.length){const [dx,dy]=opts[Math.floor(Math.random()*opts.length)];cp.x+=dx;cp.y+=dy;}
        if(Math.random()<0.03&&!s.bombs.some(b=>b.x===cp.x&&b.y===cp.y))s.bombs.push({x:cp.x,y:cp.y,t:26});
      });
      if(!s.me.alive){setOver(true);clearInterval(iv);return;}
      if(s.cpus.every(c=>!c.alive)){s.pts+=200;setScore(s.pts);setOver(true);clearInterval(iv);return;}
      if(s.t>3600){setOver(true);clearInterval(iv);}
    },60);
    return ()=>clearInterval(iv);
  },[started,over]);
  const ref=useCanvas((ctx)=>{
    const s=S.current;const cw=360/W,ch=324/H;
    ctx.fillStyle='#0d3b1e';ctx.fillRect(0,0,360,324);
    for(let x=0;x<W;x++)for(let y=0;y<H;y++){if(x%2===1&&y%2===1){ctx.fillStyle='#5b5b7a';ctx.fillRect(x*cw,y*ch,cw,ch);}}
    s.bombs.forEach(b=>{ctx.fillStyle='#1a1a1a';ctx.beginPath();ctx.arc(b.x*cw+cw/2,b.y*ch+ch/2,Math.min(cw,ch)/2.6,0,7);ctx.fill();ctx.fillStyle=b.t<8?'#ff2e63':'#ffe74c';ctx.fillRect(b.x*cw+cw/2-2,b.y*ch+3,4,6);});
    s.fires.forEach(f=>{ctx.fillStyle='rgba(255,120,20,.85)';ctx.fillRect(f.x*cw+1,f.y*ch+1,cw-2,ch-2);});
    if(s.me.alive){ctx.fillStyle='#4dff88';ctx.beginPath();ctx.arc(s.me.x*cw+cw/2,s.me.y*ch+ch/2,Math.min(cw,ch)/2.6,0,7);ctx.fill();}
    s.cpus.forEach(cp=>{if(!cp.alive)return;ctx.fillStyle=cp.c;ctx.beginPath();ctx.arc(cp.x*cw+cw/2,cp.y*ch+ch/2,Math.min(cw,ch)/2.6,0,7);ctx.fill();});
  });
  return (<div className="max-w-md mx-auto text-center">
    <TurnBanner text={over?(S.current.cpus.every(c=>!c.alive)?`VICTORY · ${score}`:`BOOM · ${score}`):`${score} PTS`} color="#ff9f1c" />
    {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
    <div className="text-xs text-slate-400 mb-2">Arrows/WASD move · SPACE bomb · trap both CPUs</div>
    <div className="cabinet"><canvas ref={ref} width={360} height={324} className="cabinet-canvas" style={{maxWidth:360,width:'100%'}} /></div>
    <div className="flex gap-2 justify-center mt-3">
      {!started?<button className="pixel-btn" onClick={()=>{S.current={me:{x:1,y:1,alive:true},cpus:[{x:W-2,y:H-2,alive:true,c:'#ff2e63',t:0},{x:W-2,y:1,alive:true,c:'#08d9d6',t:0}],bombs:[],fires:[],pts:0,t:0};setScore(0);setOver(false);setStarted(true);}}>▶ Plant bombs</button>
      :over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{const w=S.current.cpus.every(c=>!c.alive);if(solo)props.onFinish({winnerName:w?playerName:null,winnerIndex:w?0:null,scores:{[playerName]:score}});else finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>
      :<button className="pixel-btn pixel-btn-ghost" onClick={()=>(window as any).__bomberDrop(S.current.me.x,S.current.me.y)}>💣 Bomb</button>}
    </div>
    <div className="grid grid-cols-3 gap-1 max-w-[220px] mx-auto mt-2 sm-hidden-dpad">
      {['▲','◀','💣','▶','▼'].map(a=><button key={a} className="pixel-btn pixel-btn-ghost !px-2" onClick={()=>{const s=S.current;const mv=(dx:number,dy:number)=>{const nx=s.me.x+dx,ny=s.me.y+dy;if(nx<0||ny<0||nx>=W||ny>=H)return;if(nx%2===1&&ny%2===1)return;s.me.x=nx;s.me.y=ny;};if(a==='▲')mv(0,-1);if(a==='▼')mv(0,1);if(a==='◀')mv(-1,0);if(a==='▶')mv(1,0);if(a==='💣')(window as any).__bomberDrop(s.me.x,s.me.y);}}>{a}</button>)}
    </div></div>);
}
