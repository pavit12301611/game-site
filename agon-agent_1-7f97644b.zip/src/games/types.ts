export type Player = { id: string; name: string; slot: number };
export type Room = {
  code: string; game_id: string; game_title: string;
  host_id: string; host_name: string;
  players: Player[]; max_players: number; status: string;
  state: any; created_at?: string; updated_at?: string;
};
export type GameProps = {
  room: Room | null;
  mySlot: number;
  isHost: boolean;
  playerId: string;
  playerName: string;
  players: Player[];
  solo: boolean;
  pushState: (patch: any) => void;
  onFinish: (info: { winnerName?: string | null; winnerIndex?: number | null; scores?: Record<string, number> }) => void;
};
export const slotName = (players: Player[], i: number, solo: boolean) =>
  solo ? (i === 0 ? 'YOU' : `CPU ${i}`) : (players[i]?.name || `P${i + 1}`);
export const myTurn = (turn: number, mySlot: number, solo: boolean) => solo ? true : turn === mySlot;
