import { useEffect, useRef, useState } from 'react';
import { useRace, TurnBanner } from './shared';
import type { GameProps } from './types';

function RaceBar({ live, me, score }: { live: [string, number][]; me: string; score: number }) {
  const rows = live.map(([n, s]) => n.includes('(you)') ? [me + ' (you)', score] as [string, number] : [n, s] as [string, number]);
  if (!rows.filter(([n]) => !n.includes('(you)')).length && rows.length <= 1) return null;
  const sorted = [...rows].sort((a,b)=>b[1]-a[1]);
  const top = sorted[0]?.[1] ?? 0;
  return (<div className="score-strip">{sorted.map(([n,s],i)=>(<span key={i} className={`score-chip ${n.includes('(you)')?'score-chip-me':''} ${s===top&&s>0?'score-chip-lead':''}`}>{i===0?'👑 ':i+1+'. '}{n}: {s}</span>))}</div>);
}
function useCanvas(draw: (ctx:any,t:number)=>void){
  const ref=useRef<HTMLCanvasElement>(null);
  useEffect(()=>{let raf=0;const t0=performance.now();const loop=(t:number)=>{const c=ref.current;if(c){const ctx=c.getContext('2d');if(ctx)draw(ctx,(t-t0)/1000);}raf=requestAnimationFrame(loop);};raf=requestAnimationFrame(loop);return ()=>cancelAnimationFrame(raf);},[]);
  return ref;
}

// -------- PIXEL INVADERS --------
export function InvadersGame(props: GameProps){
  const {solo,playerName}=props;const{report,finalize,liveList}=useRace(props);
  const[score,setScore]=useState(0);const[lives,setLives]=useState(3);const[started,setStarted]=useState(false);const[over,setOver]=useState(false);
  const S=useRef({px:185,bullets:[] as any[],eb:[] as any[],foes:[] as any[],t:0,dir:1,pts:0,lv:3,cd:0});
  useEffect(()=>{
    const h=(e:KeyboardEvent)=>{if(e.key==='ArrowLeft'||e.key==='a')S.current.px=Math.max(5,S.current.px-16);if(e.key==='ArrowRight'||e.key==='d')S.current.px=Math.min(365,S.current.px+16);if(e.key===' '){e.preventDefault();if(S.current.cd<=0){S.current.bullets.push({x:S.current.px+12,y:258});S.current.cd=14;}}};
    window.addEventListener('keydown',h);return ()=>window.removeEventListener('keydown',h);
  },[]);
  useEffect(()=>{
    if(!started||over)return;
    if(!S.current.foes.length){const f=[];for(let r=0;r<3;r++)for(let c=0;c<7;c++)f.push({x:50+c*42,y:40+r*32,on:true});S.current.foes=f;}
    const iv=setInterval(()=>{
      const s=S.current;s.t++;s.cd=Math.max(0,s.cd-1);
      const alive=s.foes.filter(f=>f.on);
      if(!alive.length){const f=[];for(let r=0;r<3;r++)for(let c=0;c<7;c++)f.push({x:50+c*42,y:40+r*32,on:true});s.foes=f;}
      let minX=999,maxX=-999;alive.forEach(f=>{minX=Math.min(minX,f.x);maxX=Math.max(maxX,f.x);});
      if(maxX>350||minX<20)s.dir*=-1;
      alive.forEach(f=>{f.x+=s.dir*1.4;f.y+=0.06;});
      s.bullets.forEach(b=>b.y-=7);s.bullets=s.bullets.filter(b=>b.y>0);
      s.eb.forEach(b=>b.y+=3.4);s.eb=s.eb.filter(b=>b.y<300);
      if(s.t%46===0&&alive.length){const f=alive[Math.floor(Math.random()*alive.length)];s.eb.push({x:f.x+10,y:f.y+14});}
      // collisions
      for(const b of s.bullets){for(const f of s.foes){if(f.on&&Math.abs(b.x-(f.x+10))<14&&Math.abs(b.y-(f.y+7))<12){f.on=false;b.y=-99;s.pts+=10;setScore(s.pts);report(s.pts);break;}}}
      for(const b of s.eb){if(Math.abs(b.x-(s.px+12))<14&&Math.abs(b.y-268)<12){b.y=999;s.lv--;setLives(s.lv);if(s.lv<=0){setOver(true);clearInterval(iv);return;}}}
      if(alive.some(f=>f.y>240)){setOver(true);clearInterval(iv);}
    },20);
    return ()=>clearInterval(iv);
  },[started,over]);
  const ref=useCanvas((ctx)=>{
    ctx.fillStyle='#070714';ctx.fillRect(0,0,400,300);
    const s=S.current;
    s.foes.forEach(f=>{if(!f.on)return;ctx.fillStyle='#ff2e63';ctx.fillRect(f.x,f.y,20,14);ctx.fillStyle='#ff2e63';ctx.fillRect(f.x+5,f.y-5,10,5);});
    ctx.fillStyle='#4dff88';ctx.fillRect(s.px,260,24,14);ctx.fillRect(s.px+9,252,6,10);
    ctx.fillStyle='#ffe74c';s.bullets.forEach(b=>ctx.fillRect(b.x-1,b.y,3,9));
    ctx.fillStyle='#ff9f1c';s.eb.forEach(b=>ctx.fillRect(b.x-1,b.y,3,8));
  });
  return (<div className="max-w-md mx-auto text-center">
    <TurnBanner text={over?`OVER · ${score}`:`${score} PTS · ❤ ${lives}`} color="#ff2e63" />
    {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
    <div className="text-xs text-slate-400 mb-2">← → move · SPACE fire · highest score wins</div>
    <div className="cabinet"><canvas ref={ref} width={400} height={300} className="cabinet-canvas" onMouseMove={(e)=>{const r=(e.target as any).getBoundingClientRect();S.current.px=Math.max(5,Math.min(365,(e.clientX-r.left)/r.width*400-12));}} onClick={()=>{if(S.current.cd<=0){S.current.bullets.push({x:S.current.px+12,y:258});S.current.cd=14;}}} /></div>
    <div className="flex gap-2 justify-center mt-3">
      {!started?<button className="pixel-btn" onClick={()=>{S.current={px:185,bullets:[],eb:[],foes:[],t:0,dir:1,pts:0,lv:3,cd:0};setScore(0);setLives(3);setOver(false);setStarted(true);}}>▶ Defend!</button>
      :over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:playerName,winnerIndex:0,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>
      :<button className="pixel-btn pixel-btn-ghost" onClick={()=>setOver(true)}>End run</button>}
    </div></div>);
}

// -------- ASTEROIDS --------
export function AsteroidsGame(props: GameProps){
  const {solo,playerName}=props;const{report,finalize,liveList}=useRace(props);
  const[score,setScore]=useState(0);const[started,setStarted]=useState(false);const[over,setOver]=useState(false);
  const S=useRef({x:200,y:150,a:-1.57,vx:0,vy:0,b:[] as any[],rocks:[] as any[],pts:0,keys:{} as any});
  useEffect(()=>{
    const d=(e:KeyboardEvent)=>{S.current.keys[e.key.toLowerCase()]=true;if(e.key===' '){e.preventDefault();const s=S.current;s.b.push({x:s.x+Math.cos(s.a)*14,y:s.y+Math.sin(s.a)*14,vx:Math.cos(s.a)*6,vy:Math.sin(s.a)*6,l:60});}};
    const u=(e:KeyboardEvent)=>{S.current.keys[e.key.toLowerCase()]=false;};
    window.addEventListener('keydown',d);window.addEventListener('keyup',u);
    return ()=>{window.removeEventListener('keydown',d);window.removeEventListener('keyup',u);};
  },[]);
  useEffect(()=>{
    if(!started||over)return;
    if(!S.current.rocks.length)for(let i=0;i<6;i++)S.current.rocks.push({x:Math.random()*400,y:Math.random()*300,vx:(Math.random()-.5)*2.4,vy:(Math.random()-.5)*2.4,r:22+Math.random()*14});
    const iv=setInterval(()=>{
      const s=S.current;const k=s.keys;
      if(k['arrowleft']||k['a'])s.a-=0.12;if(k['arrowright']||k['d'])s.a+=0.12;
      if(k['arrowup']||k['w']){s.vx+=Math.cos(s.a)*0.25;s.vy+=Math.sin(s.a)*0.25;}
      s.vx*=0.99;s.vy*=0.99;s.x=(s.x+s.vx+400)%400;s.y=(s.y+s.vy+300)%300;
      s.b.forEach(b=>{b.x=(b.x+b.vx+400)%400;b.y=(b.y+b.vy+300)%300;b.l--;});s.b=s.b.filter(b=>b.l>0);
      s.rocks.forEach(r=>{r.x=(r.x+r.vx+400)%400;r.y=(r.y+r.vy+300)%300;});
      for(const b of s.b)for(const r of s.rocks){const dx=b.x-r.x,dy=b.y-r.y;if(Math.sqrt(dx*dx+dy*dy)<r.r){b.l=0;r.r-=9;s.pts+=20;setScore(s.pts);report(s.pts);
        if(r.r<10){r.x=Math.random()*400;r.y=Math.random()<.5?0:300;r.r=20+Math.random()*14;r.vx=(Math.random()-.5)*2.6;r.vy=(Math.random()-.5)*2.6;}break;}}
      for(const r of s.rocks){const dx=s.x-r.x,dy=s.y-r.y;if(Math.sqrt(dx*dx+dy*dy)<r.r+8){setOver(true);clearInterval(iv);return;}}
    },20);
    const to=setTimeout(()=>{setOver(true);},75000);
    return ()=>{clearInterval(iv);clearTimeout(to);};
  },[started,over]);
  const ref=useCanvas((ctx)=>{
    ctx.fillStyle='#070714';ctx.fillRect(0,0,400,300);
    const s=S.current;
    ctx.strokeStyle='#94a3b8';s.rocks.forEach(r=>{ctx.beginPath();for(let i=0;i<8;i++){const a=i/8*Math.PI*2;const rr=r.r*(0.8+((i*37)%10)/40);const px=r.x+Math.cos(a)*rr,py=r.y+Math.sin(a)*rr;i?ctx.lineTo(px,py):ctx.moveTo(px,py);}ctx.closePath();ctx.stroke();});
    ctx.save();ctx.translate(s.x,s.y);ctx.rotate(s.a);ctx.fillStyle='#08d9d6';ctx.beginPath();ctx.moveTo(12,0);ctx.lineTo(-8,-8);ctx.lineTo(-8,8);ctx.closePath();ctx.fill();ctx.restore();
    ctx.fillStyle='#ffe74c';s.b.forEach(b=>{ctx.beginPath();ctx.arc(b.x,b.y,2.5,0,7);ctx.fill();});
  });
  return (<div className="max-w-md mx-auto text-center">
    <TurnBanner text={over?`WRECKED · ${score}`:`${score} PTS · 75s`} color="#94a3b8" />
    {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
    <div className="text-xs text-slate-400 mb-2">↑ thrust · ← → steer · SPACE blast · survive 75s</div>
    <div className="cabinet"><canvas ref={ref} width={400} height={300} className="cabinet-canvas" /></div>
    <div className="flex gap-2 justify-center mt-3">
      {!started?<button className="pixel-btn" onClick={()=>{S.current={x:200,y:150,a:-1.57,vx:0,vy:0,b:[],rocks:[],pts:0,keys:{}};setScore(0);setOver(false);setStarted(true);}}>▶ Launch</button>
      :over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:playerName,winnerIndex:0,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>
      :<button className="pixel-btn pixel-btn-ghost" onClick={()=>setOver(true)}>End run</button>}
    </div></div>);
}

// -------- FROGGER --------
export function FroggerGame(props: GameProps){
  const {solo,playerName}=props;const{report,finalize,liveList}=useRace(props);
  const[score,setScore]=useState(0);const[lives,setLives]=useState(3);const[started,setStarted]=useState(false);const[over,setOver]=useState(false);
  const S=useRef({fx:6,fy:12,pts:0,lv:3,t:0,cars:[] as any[],logs:[] as any[]});
  const ROWS=13,COLS=13;
  useEffect(()=>{
    const h=(e:KeyboardEvent)=>{const s=S.current;
      if(e.key==='ArrowUp'||e.key==='w')s.fy=Math.max(0,s.fy-1);
      if(e.key==='ArrowDown'||e.key==='s')s.fy=Math.min(ROWS-1,s.fy+1);
      if(e.key==='ArrowLeft'||e.key==='a')s.fx=Math.max(0,s.fx-1);
      if(e.key==='ArrowRight'||e.key==='d')s.fx=Math.min(COLS-1,s.fx+1);
      if(s.fy===0){s.pts+=100;setScore(s.pts);report(s.pts);s.fy=ROWS-1;s.fx=6;}
    };
    window.addEventListener('keydown',h);return ()=>window.removeEventListener('keydown',h);
  },[]);
  useEffect(()=>{
    if(!started||over)return;
    const s=S.current;s.cars=[];s.logs=[];
    for(let r=8;r<=11;r++)for(let i=0;i<3;i++)s.cars.push({r,x:Math.random()*COLS,sp:(r%2?1:-1)*(0.06+r*0.012)});
    for(let r=2;r<=5;r++)for(let i=0;i<2;i++)s.logs.push({r,x:Math.random()*COLS,sp:(r%2?1:-1)*0.05});
    const iv=setInterval(()=>{
      s.t++;
      s.cars.forEach(c=>{c.x=(c.x+c.sp+COLS)%COLS;});
      s.logs.forEach(l=>{l.x=(l.x+l.sp+COLS)%COLS;});
      // river ride
      if(s.fy>=2&&s.fy<=5){const l=s.logs.find(l=>l.r===s.fy&&Math.abs(l.x-s.fx)<1.2);if(l){s.fx+=l.sp;if(s.fx<0||s.fx>=COLS){die();return;}}else{die();return;}}
      // cars
      if(s.fy>=8&&s.fy<=11){if(s.cars.some(c=>c.r===s.fy&&Math.abs(c.x-s.fx)<0.9)){die();return;}}
      function die(){s.lv--;setLives(s.lv);s.fx=6;s.fy=ROWS-1;if(s.lv<=0){setOver(true);clearInterval(iv);}}
    },90);
    const to=setTimeout(()=>setOver(true),90000);
    return ()=>{clearInterval(iv);clearTimeout(to);};
  },[started,over]);
  const ref=useCanvas((ctx)=>{
    const W=390,cell=W/COLS;
    const s=S.current;
    for(let r=0;r<ROWS;r++){ctx.fillStyle=r===0?'#4dff88':(r>=2&&r<=5)?'#0e4a6e':(r>=8&&r<=11)?'#1c1c2e':(r===12||r===6||r===7)?'#2b2b5e':'#101024';ctx.fillRect(0,r*cell,W,cell+1);}
    ctx.fillStyle='#7c5a2e';s.logs.forEach(l=>{ctx.fillRect(((l.x-1+COLS)%COLS)*cell,l.r*cell,cell*2.6,cell-2);});
    ctx.fillStyle='#ff2e63';s.cars.forEach(c=>{ctx.fillRect(c.x*cell,c.r*cell+3,cell*1.4,cell-6);});
    ctx.fillStyle='#4dff88';ctx.fillRect(s.fx*cell+3,s.fy*cell+3,cell-6,cell-6);
    ctx.fillStyle='#063';ctx.fillRect(s.fx*cell+6,s.fy*cell+8,cell-12,cell-14);
  });
  return (<div className="max-w-md mx-auto text-center">
    <TurnBanner text={over?`CROAKED · ${score}`:`${score} PTS · ❤ ${lives}`} color="#4dff88" />
    {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
    <div className="text-xs text-slate-400 mb-2">Arrows / WASD · reach the top × as many times as you can</div>
    <div className="cabinet"><canvas ref={ref} width={390} height={390} className="cabinet-canvas" style={{maxWidth:390,width:'100%'}} /></div>
    <div className="grid grid-cols-3 gap-1 max-w-[200px] mx-auto mt-3 sm-hidden-dpad">
      {['▲','◀','▼','▶'].map(a=><button key={a} className="pixel-btn pixel-btn-ghost !px-3" onClick={()=>{const s=S.current;if(a==='▲')s.fy=Math.max(0,s.fy-1);if(a==='▼')s.fy=Math.min(ROWS-1,s.fy+1);if(a==='◀')s.fx=Math.max(0,s.fx-1);if(a==='▶')s.fx=Math.min(COLS-1,s.fx+1);if(s.fy===0){s.pts+=100;setScore(s.pts);report(s.pts);s.fy=ROWS-1;s.fx=6;}}}>{a}</button>)}
    </div>
    <div className="flex gap-2 justify-center mt-3">
      {!started?<button className="pixel-btn" onClick={()=>{S.current={fx:6,fy:12,pts:0,lv:3,t:0,cars:[],logs:[]};setScore(0);setLives(3);setOver(false);setStarted(true);}}>▶ Hop!</button>
      :over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:playerName,winnerIndex:0,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>
      :<button className="pixel-btn pixel-btn-ghost" onClick={()=>setOver(true)}>End run</button>}
    </div></div>);
}

// -------- FLAPPY --------
export function FlappyGame(props: GameProps){
  const {solo,playerName}=props;const{report,finalize,liveList}=useRace(props);
  const[score,setScore]=useState(0);const[started,setStarted]=useState(false);const[over,setOver]=useState(false);
  const S=useRef({y:150,vy:0,pipes:[{x:420,gap:150,gapH:110,scored:false}] as {x:number;gap:number;gapH:number;scored?:boolean}[],pts:0});
  const flap=()=>{if(!started||over)return;S.current.vy=-5.2;};
  useEffect(()=>{
    const h=(e:KeyboardEvent)=>{if(e.key===' '||e.key==='ArrowUp'){e.preventDefault();flap();}};
    window.addEventListener('keydown',h);return ()=>window.removeEventListener('keydown',h);
  });
  useEffect(()=>{
    if(!started||over)return;
    const iv=setInterval(()=>{
      const s=S.current;s.vy+=0.42;s.vy=Math.min(9,s.vy);s.y+=s.vy;
      s.pipes.forEach(p=>p.x-=2.6);
      if(s.pipes[0].x<60-40){/* pass */}
      const last=s.pipes[s.pipes.length-1];
      if(last.x<230)s.pipes.push({x:420,gap:60+Math.random()*170,gapH:112,scored:false});
      s.pipes=s.pipes.filter(p=>p.x>-60);
      for(const p of s.pipes){if(!p.scored&&p.x<60-30){p.scored=true;s.pts++;setScore(s.pts);report(s.pts);}}
      const hit=s.y<0||s.y>284;
      const hitPipe=s.pipes.some(p=>60+14>p.x&&60-14<p.x+44&&(s.y-10<p.gap||s.y+10>p.gap+p.gapH));
      if(hit||hitPipe){setOver(true);clearInterval(iv);}
    },16);
    return ()=>clearInterval(iv);
  },[started,over]);
  const ref=useCanvas((ctx)=>{
    const g=ctx.createLinearGradient(0,0,0,300);g.addColorStop(0,'#0b3d5c');g.addColorStop(1,'#070714');ctx.fillStyle=g;ctx.fillRect(0,0,400,300);
    const s=S.current;
    ctx.fillStyle='#4dff88';s.pipes.forEach(p=>{ctx.fillRect(p.x,0,44,p.gap);ctx.fillRect(p.x,p.gap+p.gapH,44,300-p.gap-p.gapH);});
    ctx.fillStyle='#ffe74c';ctx.beginPath();ctx.arc(60,s.y,13,0,7);ctx.fill();
    ctx.fillStyle='#ff9f1c';ctx.beginPath();ctx.moveTo(72,s.y);ctx.lineTo(84,s.y-6);ctx.lineTo(84,s.y+6);ctx.fill();
    ctx.fillStyle='#000';ctx.fillRect(56,s.y-6,5,5);
  });
  return (<div className="max-w-md mx-auto text-center">
    <TurnBanner text={over?`SPLAT · ${score} PIPES`:`PIPES ${score}`} color="#ffe74c" />
    {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
    <div className="text-xs text-slate-400 mb-2">SPACE / click / tap to flap</div>
    <div className="cabinet"><canvas ref={ref} width={400} height={300} className="cabinet-canvas" onClick={()=>{if(!started){S.current={y:150,vy:0,pipes:[{x:420,gap:150,gapH:110}],pts:0};setScore(0);setOver(false);setStarted(true);}else flap();}} /></div>
    <div className="flex gap-2 justify-center mt-3">
      {!started?<button className="pixel-btn" onClick={()=>{S.current={y:150,vy:0,pipes:[{x:420,gap:150,gapH:110}],pts:0};setScore(0);setOver(false);setStarted(true);}}>▶ Flap!</button>
      :over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:playerName,winnerIndex:0,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>
      :<button className="pixel-btn pixel-btn-ghost" onClick={flap}>Flap!</button>}
    </div></div>);
}
