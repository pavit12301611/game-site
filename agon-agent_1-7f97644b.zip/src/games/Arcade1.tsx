import { useEffect, useRef, useState } from 'react';
import { useRace, WinnerOverlay, TurnBanner } from './shared';
import type { GameProps } from './types';

function useCanvas(draw: (ctx: any, t: number) => void, running: boolean) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (!running) return;
    let raf = 0; const t0 = performance.now();
    const loop = (t: number) => {
      const c = ref.current; if (c) { const ctx = c.getContext('2d'); if (ctx) draw(ctx, (t - t0) / 1000); }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [running]);
  return ref;
}
function RaceBar({ live, me, score }: { live: [string, number][]; me: string; score: number }) {
  const rows = live.map(([n, s]) => n.includes('(you)') ? [me + ' (you)', score] as [string, number] : [n, s] as [string, number]);
  if (!rows.filter(([n]) => !n.includes('(you)')).length && rows.length <= 1) return null;
  const sorted = [...rows].sort((a,b)=>b[1]-a[1]);
  const top = sorted[0]?.[1] ?? 0;
  return (<div className="score-strip">{sorted.map(([n,s],i)=>(<span key={i} className={`score-chip ${n.includes('(you)')?'score-chip-me':''} ${s===top&&s>0?'score-chip-lead':''}`}>{i===0?'👑 ':i+1+'. '}{n}: {s}</span>))}</div>);
}

// ---------------- SNAKE DUEL ----------------
export function SnakeGame(props: GameProps) {
  const { solo, playerName, players, mySlot } = props;
  const { report, finalize, liveList } = useRace(props);
  const N = 20;
  const [score, setScore] = useState(0);
  const [over, setOver] = useState(false);
  const [started, setStarted] = useState(false);
  const [win, setWin] = useState<any>(null);
  const st = useRef({ snake: [{x:10,y:10},{x:9,y:10},{x:8,y:10}], dir: {x:1,y:0}, food: {x:14,y:10}, cpus: [] as any[], tick: 0, pts: 0 });
  const names = players.length ? players.map(p=>p.name) : [playerName];
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const d = st.current.dir;
      if (e.key==='ArrowUp'||e.key==='w') if(d.y!==1) st.current.dir={x:0,y:-1};
      if (e.key==='ArrowDown'||e.key==='s') if(d.y!==-1) st.current.dir={x:0,y:1};
      if (e.key==='ArrowLeft'||e.key==='a') if(d.x!==1) st.current.dir={x:-1,y:0};
      if (e.key==='ArrowRight'||e.key==='d') if(d.x!==-1) st.current.dir={x:1,y:0};
      if (['ArrowUp','ArrowDown','ArrowLeft','ArrowRight',' '].includes(e.key)) e.preventDefault();
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, []);
  useEffect(() => {
    if (!started || over) return;
    if (solo && st.current.cpus.length===0) {
      st.current.cpus = [{ s:[{x:4,y:4},{x:3,y:4}], d:{x:1,y:0}, alive:true, c:'#08d9d6' }];
    }
    const iv = setInterval(() => {
      const S = st.current;
      // player move
      const head = { x: S.snake[0].x + S.dir.x, y: S.snake[0].y + S.dir.y };
      const hitWall = head.x<0||head.y<0||head.x>=N||head.y>=N;
      const hitSelf = S.snake.some(p=>p.x===head.x&&p.y===head.y);
      if (hitWall||hitSelf) { setOver(true); clearInterval(iv); return; }
      S.snake.unshift(head);
      if (head.x===S.food.x&&head.y===S.food.y) {
        S.pts+=10; setScore(S.pts); report(S.pts);
        S.food={x:Math.floor(Math.random()*N),y:Math.floor(Math.random()*N)};
      } else S.snake.pop();
      // cpu
      if (solo) for (const cpu of S.cpus) {
        if (!cpu.alive) continue;
        const h0=cpu.s[0];
        const dx=Math.sign(S.food.x-h0.x), dy=Math.sign(S.food.y-h0.y);
        const opts=[{x:dx,y:0},{x:0,y:dy},{x:cpu.d.x,y:cpu.d.y}].filter(o=>(o.x||o.y)&&!(o.x===-cpu.d.x&&o.y===-cpu.d.y));
        cpu.d=opts[Math.floor(Math.random()*opts.length)]||cpu.d;
        const nh={x:h0.x+cpu.d.x,y:h0.y+cpu.d.y};
        if(nh.x<0||nh.y<0||nh.x>=N||nh.y>=N||cpu.s.some((p:any)=>p.x===nh.x&&p.y===nh.y)){cpu.alive=false;continue;}
        cpu.s.unshift(nh);
        if(nh.x===S.food.x&&nh.y===S.food.y){S.food={x:Math.floor(Math.random()*N),y:Math.floor(Math.random()*N)};}else cpu.s.pop();
      }
    }, 110);
    return () => clearInterval(iv);
  }, [started, over]);
  const ref = useCanvas((ctx, t) => {
    const W = 400, cell = W/N;
    ctx.fillStyle='#070714'; ctx.fillRect(0,0,W,W);
    ctx.strokeStyle='#1c1c3d'; for(let i=0;i<=N;i++){ctx.beginPath();ctx.moveTo(i*cell,0);ctx.lineTo(i*cell,W);ctx.stroke();ctx.beginPath();ctx.moveTo(0,i*cell);ctx.lineTo(W,i*cell);ctx.stroke();}
    const S=st.current;
    ctx.fillStyle='#ff2e63'; ctx.fillRect(S.food.x*cell+2,S.food.y*cell+2,cell-4,cell-4);
    S.snake.forEach((p,i)=>{ctx.fillStyle=i===0?'#4dff88':'#1f9d55';ctx.fillRect(p.x*cell+1,p.y*cell+1,cell-2,cell-2);});
    if(solo) for(const cpu of S.cpus){ if(!cpu.alive)continue; cpu.s.forEach((p:any,i:number)=>{ctx.fillStyle=i===0?'#08d9d6':'#0e6e6d';ctx.fillRect(p.x*cell+1,p.y*cell+1,cell-2,cell-2);}); }
  }, true);
  const finishRun = () => {
    if (solo) {
      const cpuAlive = st.current.cpus.some(c=>c.alive);
      const iWon = !over || cpuAlive!==false ? score>=0 : true;
      setWin({ name: playerName });
      props.onFinish({ winnerName: playerName, winnerIndex: 0, scores: { [playerName]: score } });
    } else finalize(score);
  };
  useEffect(()=>{ if(over && !solo){ const t=setTimeout(()=>{},0); return ()=>clearTimeout(t);} },[over]);
  return (
    <div className="max-w-md mx-auto text-center">
      <TurnBanner text={over?'GAME OVER':`SCORE ${score}`} color="#4dff88" />
      {!solo && <RaceBar live={liveList} me={playerName} score={score} />}
      {solo && <div className="text-xs text-slate-400 mb-2">You (green) vs CPU serpent (cyan) · arrows / WASD</div>}
      {!solo && <div className="text-xs text-slate-400 mb-2">Room race — everyone plays at once, top score wins · arrows / WASD</div>}
      <div className="cabinet"><canvas ref={ref} width={400} height={400} className="cabinet-canvas" /></div>
      <div className="flex gap-2 justify-center mt-3">
        {!started ? <button className="pixel-btn" onClick={()=>{st.current={snake:[{x:10,y:10},{x:9,y:10},{x:8,y:10}],dir:{x:1,y:0},food:{x:14,y:10},cpus:[],tick:0,pts:0};setScore(0);setOver(false);setStarted(true);}}>▶ Start</button>
        : over ? <button className="pixel-btn pixel-btn-cyan" onClick={finishRun}>🏁 Finish run ({score})</button>
        : <button className="pixel-btn pixel-btn-ghost" onClick={()=>{setOver(true);}}>End run</button>}
        <div className="grid grid-cols-3 gap-1 sm-hidden-dpad">
          {[['▲',0,-1],['◀',-1,0],['▼',0,1],['▶',1,0]].map(([l,dx,dy]:any)=><button key={l} className="pixel-btn pixel-btn-ghost !px-3 !py-2" onClick={()=>{const d=st.current.dir;if(dx===-d.x&&dy===-d.y)return;if(dx||dy)st.current.dir={x:dx,y:dy};}}>{l}</button>)}
        </div>
      </div>
      {win && <WinnerOverlay winnerName={win.name} isMe gameTitle="Snake Duel" scores={[[playerName,score]]} showRematch={false} />}
      {over && !solo && <div className="mt-3"><button className="pixel-btn pixel-btn-cyan" onClick={finishRun}>🏁 Submit {score} pts & reveal winner</button></div>}
    </div>
  );
}

// ---------------- NEON PONG (60s score race vs CPU) ----------------
export function PongGame(props: GameProps) {
  const { solo, playerName } = props;
  const { report, finalize, liveList } = useRace(props);
  const [score, setScore] = useState(0);
  const [time, setTime] = useState(60);
  const [started, setStarted] = useState(false);
  const [over, setOver] = useState(false);
  const S = useRef({ py: 130, cy: 130, bx: 200, by: 150, vx: 3.2, vy: 2.2, pts: 0, t: 60 });
  useEffect(()=>{
    const h=(e:KeyboardEvent)=>{ if(e.key==='ArrowUp'||e.key==='w')S.current.py=Math.max(0,S.current.py-22); if(e.key==='ArrowDown'||e.key==='s')S.current.py=Math.min(260,S.current.py+22); };
    window.addEventListener('keydown',h); return ()=>window.removeEventListener('keydown',h);
  },[]);
  useEffect(()=>{
    if(!started||over)return;
    const iv=setInterval(()=>{
      const s=S.current;
      s.t-=0.1; setTime(Math.max(0,s.t));
      s.bx+=s.vx; s.by+=s.vy;
      if(s.by<6||s.by>294)s.vy*=-1;
      if(s.bx<16&&s.by>s.py-6&&s.by<s.py+66){s.vx=Math.abs(s.vx)*1.04;s.bx=16;s.pts++;setScore(s.pts);report(s.pts);}
      if(s.bx>378){s.vx=-Math.abs(s.vx);}
      // cpu tracks with error
      s.cy+=Math.sign(s.by-(s.cy+30))*2.4;
      s.cy=Math.max(0,Math.min(260,s.cy));
      if(s.bx<0){s.bx=200;s.by=150;s.vx=3.2;}
      if(s.t<=0){setOver(true);clearInterval(iv);}
    },16);
    return ()=>clearInterval(iv);
  },[started,over]);
  const ref=useCanvas((ctx)=>{
    ctx.fillStyle='#070714';ctx.fillRect(0,0,400,300);
    ctx.strokeStyle='#2b2b5e';ctx.setLineDash([6,6]);ctx.beginPath();ctx.moveTo(200,0);ctx.lineTo(200,300);ctx.stroke();ctx.setLineDash([]);
    const s=S.current;
    ctx.fillStyle='#ff2e63';ctx.fillRect(8,s.py,8,60);
    ctx.fillStyle='#08d9d6';ctx.fillRect(384,s.cy,8,60);
    ctx.fillStyle='#ffe74c';ctx.fillRect(s.bx-5,s.by-5,10,10);
  },true);
  return (
    <div className="max-w-md mx-auto text-center">
      <TurnBanner text={over?`TIME! ${score} RALLIES`:`${score} PTS · ${Math.ceil(time)}s`} color="#08d9d6" />
      {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
      <div className="text-xs text-slate-400 mb-2">You (pink, left) vs CPU · ↑ ↓ / W S · 60 seconds, most rallies wins</div>
      <div className="cabinet"><canvas ref={ref} width={400} height={300} className="cabinet-canvas"
        onMouseMove={(e)=>{const r=(e.target as any).getBoundingClientRect();S.current.py=Math.max(0,Math.min(260,(e.clientY-r.top)/r.height*300-30));}} /></div>
      <div className="flex gap-2 justify-center mt-3">
        {!started?<button className="pixel-btn" onClick={()=>{S.current={py:130,cy:130,bx:200,by:150,vx:3.2,vy:2.2,pts:0,t:60};setScore(0);setTime(60);setOver(false);setStarted(true);}}>▶ Start rally</button>
        :over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:playerName,winnerIndex:0,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>
        :<span className="text-xs text-slate-500">Keep the rally alive…</span>}
      </div>
    </div>
  );
}

// ---------------- BLOCK BREAKER ----------------
export function BreakoutGame(props: GameProps) {
  const { solo, playerName } = props;
  const { report, finalize, liveList } = useRace(props);
  const [score,setScore]=useState(0);
  const [lives,setLives]=useState(3);
  const [started,setStarted]=useState(false);
  const [over,setOver]=useState(false);
  const S=useRef({px:170,bx:200,by:240,vx:3,vy:-3.4,bricks:[] as any[],pts:0,lv:3});
  const newBricks=()=>{const a=[];for(let r=0;r<5;r++)for(let c=0;c<8;c++)a.push({r,c,on:true,col:['#ff2e63','#ff9f1c','#ffe74c','#4dff88','#08d9d6'][r]});return a;};
  useEffect(()=>{
    const h=(e:KeyboardEvent)=>{if(e.key==='ArrowLeft'||e.key==='a')S.current.px=Math.max(0,S.current.px-26);if(e.key==='ArrowRight'||e.key==='d')S.current.px=Math.min(320,S.current.px+26);};
    window.addEventListener('keydown',h);return ()=>window.removeEventListener('keydown',h);
  },[]);
  useEffect(()=>{
    if(!started||over)return;
    if(!S.current.bricks.length)S.current.bricks=newBricks();
    const iv=setInterval(()=>{
      const s=S.current;
      s.bx+=s.vx;s.by+=s.vy;
      if(s.bx<6||s.bx>394)s.vx*=-1;
      if(s.by<6)s.vy*=-1;
      if(s.by>258&&s.by<272&&s.bx>s.px-6&&s.bx<s.px+86){s.vy=-Math.abs(s.vy);s.by=258;}
      if(s.by>292){
        s.lv--;setLives(s.lv);
        if(s.lv<=0){setOver(true);clearInterval(iv);return;}
        s.bx=200;s.by=240;s.vx=3;s.vy=-3.4;
      }
      // bricks
      const bw=400/8;
      for(const b of s.bricks){
        if(!b.on)continue;
        const x=b.c*bw+3,y=b.r*22+30,w=bw-6,h=16;
        if(s.bx>x-5&&s.bx<x+w+5&&s.by>y-5&&s.by<y+h+5){b.on=false;s.vy*=-1;s.pts+=10;setScore(s.pts);report(s.pts);break;}
      }
      if(s.bricks.every(b=>!b.on)){s.bricks=newBricks();s.vx*=1.1;s.vy*=1.1;}
    },16);
    return ()=>clearInterval(iv);
  },[started,over]);
  const ref=useCanvas((ctx)=>{
    ctx.fillStyle='#070714';ctx.fillRect(0,0,400,300);
    const s=S.current;const bw=400/8;
    for(const b of s.bricks){if(!b.on)continue;ctx.fillStyle=b.col;ctx.fillRect(b.c*bw+3,b.r*22+30,bw-6,16);}
    ctx.fillStyle='#a06bff';ctx.fillRect(s.px,264,80,10);
    ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(s.bx,s.by,6,0,7);ctx.fill();
  },true);
  return (
    <div className="max-w-md mx-auto text-center">
      <TurnBanner text={over?`GAME OVER · ${score}`:`${score} PTS · ❤ ${lives}`} color="#ff9f1c" />
      {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
      <div className="text-xs text-slate-400 mb-2">← → / A D or move mouse over the game</div>
      <div className="cabinet"><canvas ref={ref} width={400} height={300} className="cabinet-canvas"
        onMouseMove={(e)=>{const r=(e.target as any).getBoundingClientRect();S.current.px=Math.max(0,Math.min(320,(e.clientX-r.left)/r.width*400-40));}} /></div>
      <div className="flex gap-2 justify-center mt-3">
        {!started?<button className="pixel-btn" onClick={()=>{S.current={px:170,bx:200,by:240,vx:3,vy:-3.4,bricks:[],pts:0,lv:3};setScore(0);setLives(3);setOver(false);setStarted(true);}}>▶ Start</button>
        :over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:playerName,winnerIndex:0,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>
        :<button className="pixel-btn pixel-btn-ghost" onClick={()=>setOver(true)}>End run</button>}
      </div>
    </div>
  );
}

// ---------------- TOWER STACKER ----------------
export function StackerGame(props: GameProps) {
  const { solo, playerName } = props;
  const { report, finalize, liveList } = useRace(props);
  const [score,setScore]=useState(0);
  const [over,setOver]=useState(false);
  const [started,setStarted]=useState(false);
  const S=useRef({tower:[{x:2,w:6}],moving:{x:0,w:6,dir:1},h:0});
  const W=8;
  useEffect(()=>{
    if(!started||over)return;
    const iv=setInterval(()=>{const s=S.current;let nx=s.moving.x+s.moving.dir;if(nx<0||nx+s.moving.w>W){s.moving.dir*=-1;nx=s.moving.x+s.moving.dir;}s.moving.x=nx;},110);
    return ()=>clearInterval(iv);
  },[started,over]);
  const ref=useCanvas((ctx)=>{
    ctx.fillStyle='#070714';ctx.fillRect(0,0,320,360);
    const s=S.current;const bh=18;
    const baseY=360;
    s.tower.forEach((b,i)=>{const y=baseY-(i+1)*bh;if(y<-20||y>380)return;ctx.fillStyle=['#ff2e63','#ff9f1c','#ffe74c','#4dff88','#08d9d6','#a06bff'][i%6];ctx.fillRect(b.x*40,y,b.w*40-3,bh-3);});
    const my=baseY-(s.tower.length+1)*bh;
    ctx.fillStyle='#fff';ctx.fillRect(s.moving.x*40,my,s.moving.w*40-3,bh-3);
  },true);
  const drop=()=>{
    const s=S.current;
    const prev=s.tower[s.tower.length-1];
    const L=Math.max(prev.x,s.moving.x),R=Math.min(prev.x+prev.w,s.moving.x+s.moving.w);
    const w=R-L;
    if(w<=0){setOver(true);return;}
    s.tower.push({x:L,w});
    const pts=s.tower.length-1;setScore(pts);report(pts);
    if(w===1){/* perfect */}
    s.moving={x:0,w,dir:1};
  };
  useEffect(()=>{const h=(e:KeyboardEvent)=>{if(e.key===' '){e.preventDefault();if(started&&!over)drop();}};window.addEventListener('keydown',h);return ()=>window.removeEventListener('keydown',h);});
  return (
    <div className="max-w-sm mx-auto text-center">
      <TurnBanner text={over?`TOWER FELL · ${score}`:`HEIGHT ${score}`} color="#a06bff" />
      {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
      <div className="text-xs text-slate-400 mb-2">SPACE or tap DROP to stack the sliding block</div>
      <div className="cabinet"><canvas ref={ref} width={320} height={360} className="cabinet-canvas" onClick={()=>{if(started&&!over)drop();}} /></div>
      <div className="flex gap-2 justify-center mt-3">
        {!started?<button className="pixel-btn" onClick={()=>{S.current={tower:[{x:2,w:6}],moving:{x:0,w:6,dir:1},h:0};setScore(0);setOver(false);setStarted(true);}}>▶ Start</button>
        :over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:playerName,winnerIndex:0,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>
        :<button className="pixel-btn" onClick={drop}>⬇ Drop</button>}
      </div>
    </div>
  );
}
