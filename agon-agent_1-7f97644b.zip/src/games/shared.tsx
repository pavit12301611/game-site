import { useEffect, useRef, useState, useCallback } from 'react';
import { Trophy, RotateCcw, Home } from 'lucide-react';
import { Link } from 'react-router-dom';
import type { GameProps } from './types';

// Synced state hook: solo = local only; room = broadcast via room.state
export function useSync<T>(props: GameProps, key: string, initial: () => T): [T, (u: T | ((p: T) => T)) => void] {
  const { room, pushState, solo } = props;
  const [local, setLocal] = useState<T>(() => {
    if (!solo && room?.state && (room.state as any)[key] !== undefined) return (room.state as any)[key] as T;
    return initial();
  });
  const revRef = useRef<number>(0);
  const seen = useRef(false);
  useEffect(() => {
    if (solo) return;
    const st: any = room?.state || {};
    const r = st.rev || 0;
    if (!seen.current) { seen.current = true; revRef.current = r; if (st[key] !== undefined) setLocal(st[key] as T); return; }
    if (st[key] !== undefined && r !== revRef.current) { revRef.current = r; setLocal(st[key] as T); }
  }, [room?.state]);
  const set = useCallback((u: T | ((p: T) => T)) => {
    setLocal(prev => {
      const next = typeof u === 'function' ? (u as (p: T) => T)(prev) : u;
      if (!solo) {
        revRef.current += 1;
        const patch: any = { rev: revRef.current };
        patch[key] = next;
        pushState(patch);
      }
      return next;
    });
  }, [solo, pushState, key]);
  return [local, set];
}

export function resetMatch(props: GameProps, key: string, value: any) {
  if (props.solo) return value;
  props.pushState({ rev: Date.now() % 1000000, [key]: value });
  return value;
}

export const rnd = (n: number) => Math.floor(Math.random() * n);
export const pick = <T,>(a: T[]): T => a[Math.floor(Math.random() * a.length)];
export const delay = (ms: number) => new Promise(r => setTimeout(r, ms));

export function TurnBanner({ text, color }: { text: string; color?: string }) {
  const c = color || '#08d9d6';
  return (
    <div className="text-center mb-4 turn-wrap">
      <span className="turn-pill font-pixel" style={{ ['--tc' as any]: c }}>
        <span className="turn-dot" />
        <span className="turn-text">{text}</span>
        <span className="turn-sheen" />
      </span>
    </div>
  );
}

const CONFETTI_COLORS = ['#ff2e63', '#08d9d6', '#ffe74c', '#4dff88', '#a06bff', '#ff9f1c'];

export function WinnerOverlay({ winnerName, isMe, scores, gameTitle, onRematch, showRematch }: { winnerName: string | null | undefined; isMe: boolean; scores?: [string, number][]; gameTitle: string; onRematch?: () => void; showRematch?: boolean }) {
  const hasWinner = !!winnerName;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 winner-backdrop">
      <div className="winner-confetti" aria-hidden>
        {Array.from({ length: 28 }).map((_, i) => (
          <span
            key={i}
            className="winner-confetti-piece"
            style={{
              left: `${(i * 37 + 11) % 100}%`,
              background: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
              animationDelay: `${((i * 0.17) % 1.8).toFixed(2)}s`,
              animationDuration: `${(2.2 + ((i * 13) % 14) / 10).toFixed(2)}s`,
              transform: `rotate(${((i * 47) % 360)}deg)`,
            }}
          />
        ))}
      </div>
      <div className="pixel-panel winner-card p-8 max-w-sm w-full text-center">
        <div className="winner-ring">
          <Trophy size={44} className="mx-auto floaty" color={hasWinner ? '#ffe74c' : '#8b8ba7'} />
        </div>
        <div className={`font-pixel text-sm mb-2 ${hasWinner ? (isMe ? 'neon-text-yellow' : 'neon-text-pink') : ''}`} style={hasWinner ? undefined : { color: '#8b8ba7' }}>
          {hasWinner ? (isMe ? 'YOU WIN!' : `${(winnerName || '').toUpperCase()} WINS!`) : 'DRAW!'}
        </div>
        <div className="winner-sub">{gameTitle} · result saved to leaderboard</div>
        {scores && scores.length > 0 && (
          <div className="winner-scores">
            {scores.map(([n, s], i) => (
              <div key={i} className={`flex justify-between items-center px-3 py-1.5 rounded winner-row ${i === 0 ? 'winner-row-first' : ''}`}>
                <span className="truncate">{i === 0 ? '👑 ' : `${i + 1}. `}{n}</span><span className="font-bold winner-pts">{s}</span>
              </div>
            ))}
          </div>
        )}
        <div className="flex gap-2 justify-center winner-actions">
          {showRematch && onRematch && <button className="pixel-btn pixel-btn-cyan flex items-center gap-2" onClick={onRematch}><RotateCcw size={14} /> Rematch</button>}
          <Link to="/" className="pixel-btn pixel-btn-ghost flex items-center gap-2 no-underline"><Home size={14} /> Arcade</Link>
        </div>
      </div>
    </div>
  );
}

export function OppChips({ names, scores, me }: { names: string[]; scores: Record<string, number>; me: string }) {
  const entries = Object.entries(scores || {});
  if (!entries.length) return null;
  return (
    <div className="score-strip">
      {entries.map(([id, s]) => (
        <span key={id} className={`score-chip ${id === me ? 'score-chip-me' : ''}`}>
          {s as number} pts
        </span>
      ))}
      <span className="score-chip" style={{ borderStyle: 'dashed' }}>⚡ {names.join(' · ')}</span>
    </div>
  );
}

export function LiveScores({ live, me, score }: { live: [string, number][]; me: string; score: number }) {
  const rows = live.map(([n, s]) => n.includes('(you)') ? [me + ' (you)', score] as [string, number] : [n, s] as [string, number]);
  if (!rows.filter(([n]) => !n.includes('(you)')).length && rows.length <= 1) return null;
  const sorted = [...rows].sort((a, b) => b[1] - a[1]);
  const top = sorted[0]?.[1] ?? 0;
  return (
    <div className="score-strip">
      {sorted.map(([n, s], i) => (
        <span key={i} className={`score-chip ${n.includes('(you)') ? 'score-chip-me' : ''} ${s === top && s > 0 ? 'score-chip-lead' : ''}`}>
          {i === 0 ? '👑 ' : `${i + 1}. `}{n}: {s}
        </span>
      ))}
    </div>
  );
}

// Score-race hook for arcade/puzzle/reflex games in rooms
export function useRace(props: GameProps) {
  const { room, pushState, solo, playerId, playerName, players } = props;
  const [oppScores, setOppScores] = useState<Record<string, { name: string; score: number }>>({});
  const lastPush = useRef(0);
  const lastSig = useRef('');
  const bestSent = useRef(0);
  const queuedBest = useRef(0);
  useEffect(() => {
    if (solo || !room?.state?.scores) return;
    try {
      const sig = JSON.stringify(room.state.scores);
      if (sig === lastSig.current) return;
      lastSig.current = sig;
      setOppScores(room.state.scores);
    } catch { setOppScores(room.state.scores); }
  }, [room?.state, solo]);
  const report = useCallback((score: number) => {
    if (solo) return;
    const now = Date.now();
    // monotonic + throttled — keeps 40-50 player lobbies smooth, never hides a new best
    if (score <= bestSent.current) return;
    if (now - lastPush.current < 2500) { queuedBest.current = Math.max(queuedBest.current, score); return; }
    bestSent.current = score;
    lastPush.current = now;
    pushState({ scores: { [playerId]: { name: playerName, score } } });
  }, [solo, pushState, playerId, playerName]);
  // flush any queued best when the throttle window opens
  useEffect(() => {
    if (solo) return;
    const t = setInterval(() => {
      if (queuedBest.current > bestSent.current && Date.now() - lastPush.current >= 2500) {
        bestSent.current = queuedBest.current;
        lastPush.current = Date.now();
        pushState({ scores: { [playerId]: { name: playerName, score: queuedBest.current } } });
      }
    }, 2600);
    return () => clearInterval(t);
  }, [solo, pushState, playerId, playerName]);
  const finalize = useCallback((myScore: number) => {
    const scores: Record<string, number> = {};
    Object.entries({ ...oppScores, [playerId]: { name: playerName, score: myScore } }).forEach(([id, v]: any) => { scores[v.name || id] = v.score; });
    const names = players.length ? players.map(p => p.name) : [playerName];
    let winName: string | null = null; let best = -Infinity;
    Object.entries(scores).forEach(([n, s]) => { if (s > best) { best = s; winName = n; } });
    const idx = names.indexOf(winName || '');
    props.onFinish({ winnerName: winName, winnerIndex: idx >= 0 ? idx : null, scores });
  }, [oppScores, playerId, playerName, players, props]);
  const liveList: [string, number][] = Object.entries({ ...oppScores, [playerId]: { name: playerName + ' (you)', score: 0 } })
    .map(([id, v]: any) => [v.name, v.score] as [string, number])
    .sort((a, b) => b[1] - a[1]);
  return { oppScores, report, finalize, liveList };
}
