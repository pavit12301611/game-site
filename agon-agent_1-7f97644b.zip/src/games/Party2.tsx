import { useEffect, useRef, useState } from 'react';
import { useSync, useRace, TurnBanner, WinnerOverlay } from './shared';
import type { GameProps } from './types';
import { slotName } from './types';
import { hashStr, mulberry32 } from '../lib/rand';

function RaceBar({ live, me, score }: { live: [string, number][]; me: string; score: number }) {
  const rows = live.map(([n, s]) => n.includes('(you)') ? [me + ' (you)', score] as [string, number] : [n, s] as [string, number]);
  if (!rows.filter(([n]) => !n.includes('(you)')).length && rows.length <= 1) return null;
  const sorted = [...rows].sort((a,b)=>b[1]-a[1]);
  const top = sorted[0]?.[1] ?? 0;
  return (<div className="score-strip">{sorted.map(([n,s],i)=>(<span key={i} className={`score-chip ${n.includes('(you)')?'score-chip-me':''} ${s===top&&s>0?'score-chip-lead':''}`}>{i===0?'👑 ':i+1+'. '}{n}: {s}</span>))}</div>);
}

// ============ MATH DUEL (60s race, shared questions) ============
export function MathDuel(props: GameProps){
  const {solo,playerName}=props;const{report,finalize,liveList}=useRace(props);
  const seed=props.room?.code||'solo-math';
  const qs=useRef<{q:string;a:number}[]>([]);
  if(!qs.current.length){
    let h=2166136261;for(let i=0;i<seed.length;i++){h^=seed.charCodeAt(i);h=Math.imul(h,16777619);}let a=h>>>0;
    const rng=()=>{a|=0;a=(a+0x6D2B79F5)|0;let t=Math.imul(a^(a>>>15),1|a);t=(t+Math.imul(t^(t>>>7),61|t))^t;return((t^(t>>>14))>>>0)/4294967296;};
    const ops=['+','−','×'];
    for(let i=0;i<40;i++){const op=ops[Math.floor(rng()*3)];let x=2+Math.floor(rng()*19),y=2+Math.floor(rng()*19);
      if(op==='+')qs.current.push({q:`${x} + ${y}`,a:x+y});
      else if(op==='−')qs.current.push({q:`${Math.max(x,y)} − ${Math.min(x,y)}`,a:Math.abs(x-y)});
      else qs.current.push({q:`${2+Math.floor(rng()*10)} × ${2+Math.floor(rng()*9)}`,a:0});
    }
    // fix mult
    qs.current=qs.current.map(o=>{if(o.a!==0)return o;const m=o.q.match(/^(\d+)\s*×\s*(\d+)$/);return m?{...o,a:parseInt(m[1])*parseInt(m[2])}:o;});
  }
  const[qi,setQi]=useState(0);const[input,setInput]=useState('');const[score,setScore]=useState(0);const[left,setLeft]=useState(60);const[started,setStarted]=useState(false);const[over,setOver]=useState(false);
  useEffect(()=>{if(!started||over)return;const iv=setInterval(()=>setLeft(l=>{if(l<=1){setOver(true);clearInterval(iv);return 0;}return l-1;}),1000);return ()=>clearInterval(iv);},[started,over]);
  const submit=()=>{
    if(!started||over)return;
    if(parseInt(input)===qs.current[qi].a){const ns=score+10;setScore(ns);report(ns);setQi(qi+1);setInput('');}
    else{setScore(s=>Math.max(0,s-2));}
  };
  return (<div className="max-w-xs mx-auto text-center">
    <TurnBanner text={over?`TIME! ${score}`:`${score} PTS · ${left}s`} color="#4dff88" />
    {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
    {!started?<button className="pixel-btn" onClick={()=>setStarted(true)}>▶ 60-second sprint</button>:over?
      <button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:playerName,winnerIndex:0,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>:(
      <>
        <div className="pixel-panel p-6 mb-3"><div className="text-xs text-slate-400 mb-1">Q{qi+1} · streak pays</div><div className="font-pixel text-3xl" style={{color:'#4dff88'}}>{qs.current[qi].q} = ?</div></div>
        <div className="flex gap-2"><input className="pixel-input font-pixel text-center" type="number" value={input} autoFocus onChange={e=>setInput(e.target.value)} onKeyDown={e=>{if(e.key==='Enter')submit();}} placeholder="?" /><button className="pixel-btn" onClick={submit}>Go</button></div>
      </>)}
  </div>);
}

// ============ ROCK PAPER ZAP (best of 5, synced) ============
export function RPS(props: GameProps){
  const {mySlot,players,solo}=props;
  const n=solo?2:(players.length||2);
  const names=[0,1,2].slice(0,n).map(i=>slotName(players,i,solo));
  type S={round:number;picks:(string|null)[];scores:number[];log:string[];win:any;reveal:boolean};
  const init=():S=>({round:1,picks:names.map(()=>null),scores:names.map(()=>0),log:[],win:null,reveal:false});
  const[s,setS]=useSync(props,'rps',init);
  const done=useRef(false);
  const beats:Record<string,string>={rock:'scissors',paper:'rock',scissors:'paper'};
  const em:Record<string,string>={rock:'✊',paper:'✋',scissors:'✌️'};
  const choose=(c:string)=>{
    if(s.win||s.reveal)return;
    const me=solo?0:mySlot;
    if(s.picks[me])return;
    const picks=[...s.picks];picks[me]=c;
    if(solo){
      // cpu picks instantly, resolve
      const cpu=['rock','paper','scissors'][Math.floor(Math.random()*3)];
      picks[1]=cpu;
      resolve(picks);
      return;
    }
    setS({...s,picks});
    if(picks.every(Boolean))resolve(picks);
    else {
      // auto-fill missing after timeout? no — wait, but if 3P and someone idles, resolve with random after 12s
    }
  };
  const resolve=(picks:(string|null)[])=>{
    const scores=[...s.scores];let msg='';
    if(n===2){
      const [a,b]=picks as string[];
      if(a===b)msg=`Round ${s.round}: tie (${em[a]})`;
      else if(beats[a]===b){scores[0]++;msg=`Round ${s.round}: ${names[0]} ${em[a]} beats ${em[b]}`;}
      else{scores[1]++;msg=`Round ${s.round}: ${names[1]} ${em[b]} beats ${em[a]}`;}
    } else {
      // 3P: majority weapon wins; ties split
      const [a,b,c]=picks as string[];
      const all=[a,b,c];
      const uniq=[...new Set(all)];
      if(uniq.length===1||uniq.length===3)msg=`Round ${s.round}: three-way tie!`;
      else{
        // two weapons: which beats which
        const [x,y]=uniq;
        const winnerWeapon=beats[x]===y?x:(beats[y]===x?y:null);
        if(!winnerWeapon)msg=`Round ${s.round}: tie!`;
        else{all.forEach((p,i)=>{if(p===winnerWeapon)scores[i]++;});msg=`Round ${s.round}: ${em[winnerWeapon!]} wins the clash!`;}
      }
    }
    const log=[...s.log,msg].slice(-4);
    const target=3;
    const wi=scores.findIndex(sc=>sc>=target);
    if(wi>=0||s.round>=5){
      let winner=wi;
      if(winner<0){const mx=Math.max(...scores);const tops=scores.map((v,i)=>v===mx?i:-1).filter(i=>i>=0);winner=tops.length===1?tops[0]:-1;}
      const win=winner;
      setS({round:s.round+1,picks:names.map(()=>null),scores,log,win:win<0?'draw':win,reveal:true});
      setTimeout(()=>finish(win,scores),900);
    } else {
      setS({round:s.round+1,picks:names.map(()=>null),scores,log,win:null,reveal:true});
      setTimeout(()=>setS({round:s.round+1,picks:names.map(()=>null),scores,log,win:null,reveal:false}),1100);
    }
  };
  const finish=(w:number,scores:number[])=>{
    if(done.current)return;done.current=true;
    const sc:any={};names.forEach((nm,i)=>sc[nm]=scores[i]);
    props.onFinish({winnerName:w<0?null:names[w],winnerIndex:w<0?null:(solo?(w===0?0:null):w),scores:sc});
  };
  const rematch=()=>{done.current=false;setS(init());};
  const me=solo?0:mySlot;
  return (<div className="max-w-md mx-auto text-center">
    <TurnBanner text={s.win!==null&&s.win!==undefined?('GAME OVER'):('ROUND '+s.round+' · FIRST TO 3')} color="#ff9f1c" />
    <div className="flex gap-3 justify-center text-xs font-bold mb-3">{names.map((nm,i)=><span key={i} style={{color:['#ff2e63','#08d9d6','#ffe74c'][i]}}>{nm}: {s.scores[i]} {s.picks[i]?'✓':''}</span>)}</div>
    {s.reveal&&s.picks.some(Boolean)&&<div className="text-4xl mb-2">{s.picks.map(p=>p?em[p]:'❔').join('  vs  ')}</div>}
    <div className="grid grid-cols-3 gap-2 max-w-sm mx-auto">
      {(['rock','paper','scissors'] as string[]).map(c=>(
        <button key={c} onClick={()=>choose(c)} disabled={!!s.picks[me]||s.reveal} className="pixel-panel p-4 text-center hover:scale-105 transition"
          style={{opacity:s.picks[me]&&s.picks[me]!==c?0.4:1,borderColor:s.picks[me]===c?'#4dff88':undefined}}>
          <div className="text-4xl">{em[c]}</div><div className="font-pixel text-[10px] mt-2">{c.toUpperCase()}</div>
        </button>))}
    </div>
    <div className="text-xs text-slate-400 mt-3 space-y-1">{s.log.map((l,i)=><div key={i}>{l}</div>)}</div>
    {!solo&&s.picks[me]&&!s.picks.every(Boolean)&&<div className="text-xs blink mt-2" style={{color:'#ffe74c'}}>Locked in… waiting for rivals</div>}
    {(s.win!==null&&s.win!==undefined)&&<WinnerOverlay winnerName={s.win==='draw'?null:names[s.win]} isMe={s.win!=='draw'&&names[s.win]===(solo?names[0]:players[mySlot]?.name)} scores={names.map(nm=>[nm,0] as [string,number])} gameTitle="Rock Paper Zap" onRematch={rematch} showRematch />}
  </div>);
}

// ============ DICE DUEL ============
export function DiceDuel(props: GameProps){
  const {mySlot,players,solo}=props;
  const n=solo?2:(players.length||2);
  const names=[0,1,2].slice(0,n).map(i=>slotName(players,i,solo));
  type S={round:number;rolls:(number|null)[];totals:number[];win:any};
  const init=():S=>({round:1,rolls:names.map(()=>null),totals:names.map(()=>0),win:null});
  const[s,setS]=useSync(props,'dice',init);
  const done=useRef(false);
  const[rolling,setRolling]=useState(false);
  const roll=()=>{
    if(s.win||rolling)return;
    const me=solo?0:mySlot;
    if(s.rolls[me]!==null)return;
    setRolling(true);
    setTimeout(()=>{
      setRolling(false);
      const v=1+Math.floor(Math.random()*6);
      const rolls=[...s.rolls];rolls[me]=v;
      if(solo){
        const cpu=1+Math.floor(Math.random()*6);rolls[1]=cpu;
        settle(rolls);
        return;
      }
      setS({...s,rolls});
      if(rolls.every(x=>x!==null))settle(rolls);
    },700);
  };
  const settle=(rolls:(number|null)[])=>{
    const totals=[...s.totals];(rolls as number[]).forEach((v,i)=>totals[i]+=v);
    const mx=Math.max(...(rolls as number[]));
    const roundBonus=(rolls as number[]).map(v=>v===mx?1:0);
    roundBonus.forEach((b,i)=>{if(b)totals[i]+=0;});
    if(s.round>=5){
      const best=Math.max(...totals);const tops=totals.map((t,i)=>t===best?i:-1).filter(i=>i>=0);
      const w=tops.length===1?tops[0]:-1;
      setS({round:s.round+1,rolls:names.map(()=>null),totals,win:w});
      setTimeout(()=>finish(w,totals),800);
    } else setS({round:s.round+1,rolls:names.map(()=>null),totals,win:null});
  };
  const finish=(w:number,totals:number[])=>{if(done.current)return;done.current=true;const sc:any={};names.forEach((nm,i)=>sc[nm]=totals[i]);props.onFinish({winnerName:w<0?null:names[w],winnerIndex:w<0?null:(solo?(w===0?0:null):w),scores:sc});};
  const rematch=()=>{done.current=false;setS(init());};
  const me=solo?0:mySlot;
  const faces=['','⚀','⚁','⚂','⚃','⚄','⚅'];
  return (<div className="max-w-md mx-auto text-center">
    <TurnBanner text={s.win!==null&&s.win!==undefined?'FINAL TOTALS':`ROUND ${Math.min(s.round,5)}/5`} color="#38bdf8" />
    <div className="grid gap-2 mb-4" style={{gridTemplateColumns:`repeat(${n},1fr)`}}>
      {names.map((nm,i)=>(<div key={i} className="pixel-panel p-4">
        <div className="text-xs font-bold mb-1" style={{color:['#ff2e63','#08d9d6','#ffe74c'][i]}}>{nm}{i===me?' (you)':''}</div>
        <div className="text-5xl">{rolling&&i===me?'🎲':faces[s.rolls[i]||0]||'·'}</div>
        <div className="font-pixel text-xs mt-2" style={{color:'#ffe74c'}}>{s.totals[i]} PTS</div>
      </div>))}
    </div>
    {(s.win===null||s.win===undefined)?(
      s.rolls[me]===null?<button className="pixel-btn" onClick={roll}>{rolling?'ROLLING…':'🎲 ROLL!'}</button>
      :<div className="text-xs blink" style={{color:'#ffe74c'}}>You rolled {faces[s.rolls[me]!]} — waiting for rivals…</div>
    ):null}
    {(s.win!==null&&s.win!==undefined)&&(()=>{const sc:any={};names.forEach((nm,i)=>sc[nm]=s.totals[i]);
      return <WinnerOverlay winnerName={s.win<0?null:names[s.win]} isMe={s.win>=0&&names[s.win]===(solo?names[0]:players[mySlot]?.name)} scores={names.map(nm=>[nm,sc[nm]] as [string,number])} gameTitle="Dice Duel" onRematch={rematch} showRematch />;})()}
  </div>);
}

// ============ CARD WAR ============
const SUITS=['♠','♥','♦','♣'];
export function CardWar(props: GameProps){
  const {mySlot,players,solo}=props;
  const n=solo?2:(players.length||2);
  const names=[0,1,2].slice(0,n).map(i=>slotName(players,i,solo));
  const seed=props.room?.code||'solo-war';
  type S={round:number;hands:number[][];table:(number|null)[];wins:number[];win:any};
  const init=():S=>{
    let h=2166136261;for(let i=0;i<seed.length;i++){h^=seed.charCodeAt(i);h=Math.imul(h,16777619);}let a=h>>>0;
    const rng=()=>{a|=0;a=(a+0x6D2B79F5)|0;let t=Math.imul(a^(a>>>15),1|a);t=(t+Math.imul(t^(t>>>7),61|t))^t;return((t^(t>>>14))>>>0)/4294967296;};
    const deck=[...Array(52).keys()];for(let i=51;i>0;i--){const j=Math.floor(rng()*(i+1));[deck[i],deck[j]]=[deck[j],deck[i]];}
    const hands:number[][]=[[],[],[]].slice(0,n);
    deck.forEach((c,i)=>hands[i%n].push(c));
    return {round:1,hands,table:names.map(()=>null),wins:names.map(()=>0),win:null};
  };
  const[s,setS]=useSync(props,'war',init);
  const done=useRef(false);
  const card=(v:number)=>({r:(v%13)+2,s:SUITS[Math.floor(v/13)]});
  const flip=()=>{
    if(s.win)return;
    const me=solo?0:mySlot;
    if(s.table[me]!==null&&s.table[me]!==undefined)return;
    const hands=s.hands.map(h=>[...h]);
    if(!hands[me].length)return;
    const table=[...s.table];table[me]=hands[me].shift()!;
    if(solo){
      if(hands[1].length)table[1]=hands[1].shift()!;
      settle(hands,table);
      return;
    }
    setS({...s,hands,table});
    if(table.every(x=>x!==null))settle(hands,table);
  };
  const settle=(hands:number[][],table:(number|null)[])=>{
    const vals=(table as number[]).map(v=>v%13);
    const mx=Math.max(...vals);
    const winners=vals.map((v,i)=>v===mx?i:-1).filter(i=>i>=0);
    const wins=[...s.wins];
    if(winners.length===1)wins[winners[0]]++;
    const total=hands.flat().length+(table as number[]).length;
    const left=hands.map(h=>h.length);
    if(s.round>=10||left.every(l=>l===0)||Math.max(...left)===total){
      let w=0;wins.forEach((x,i)=>{if(x>wins[w])w=i;});
      const tie=wins.filter(x=>x===wins[w]).length>1;
      const ww=tie?-1:w;
      setS({round:s.round+1,hands,table:winners.length===1?names.map(()=>null):table,wins,win:ww});
      setTimeout(()=>finish(ww,wins),900);
    } else {
      // winner collects? keep simple: cards vanish, fixed 10 rounds
      setS({round:s.round+1,hands,table:names.map(()=>null),wins,win:null});
    }
  };
  const finish=(w:number,wins:number[])=>{if(done.current)return;done.current=true;const sc:any={};names.forEach((nm,i)=>sc[nm]=wins[i]);props.onFinish({winnerName:w<0?null:names[w],winnerIndex:w<0?null:(solo?(w===0?0:null):w),scores:sc});};
  const rematch=()=>{done.current=false;setS(init());};
  const me=solo?0:mySlot;
  const red=(c:number)=>Math.floor(c/13)===1||Math.floor(c/13)===2;
  return (<div className="max-w-md mx-auto text-center">
    <TurnBanner text={s.win!==null&&s.win!==undefined?'WAR OVER':`BATTLE ${Math.min(s.round,10)}/10`} color="#f472b6" />
    <div className="grid gap-2 mb-4" style={{gridTemplateColumns:`repeat(${n},1fr)`}}>
      {names.map((nm,i)=>{
        const t=s.table[i];
        return <div key={i} className="pixel-panel p-3">
          <div className="text-[11px] font-bold" style={{color:['#ff2e63','#08d9d6','#ffe74c'][i]}}>{nm} · {s.wins[i]}👑</div>
          <div className="mx-auto mt-2 rounded-lg flex items-center justify-center font-bold text-xl" style={{width:64,height:88,background:t===null?'#0a0a20':'#f5f5f5',border:'2px solid #000',color:t!==null&&red(t)?'#e11d48':'#111'}}>
            {t!==null?`${card(t).r===14?'A':card(t).r===13?'K':card(t).r===12?'Q':card(t).r===11?'J':card(t).r}${card(t).s}`:'?'}
          </div>
          <div className="text-[10px] text-slate-500 mt-1">{s.hands[i]?.length||0} cards left</div>
        </div>;})}
    </div>
    {(s.win===null||s.win===undefined)?(
      (s.table[me]===null||s.table[me]===undefined)?<button className="pixel-btn" onClick={flip}>🂡 FLIP CARD</button>
      :<div className="text-xs blink" style={{color:'#ffe74c'}}>Card down — waiting for rivals…</div>
    ):null}
    {(s.win!==null&&s.win!==undefined)&&(()=>{const sc:any={};names.forEach((nm,i)=>sc[nm]=s.wins[i]);
      return <WinnerOverlay winnerName={s.win<0?null:names[s.win]} isMe={s.win>=0&&names[s.win]===(solo?names[0]:players[mySlot]?.name)} scores={names.map(nm=>[nm,sc[nm]] as [string,number])} gameTitle="Card War" onRematch={rematch} showRematch />;})()}
  </div>);
}

// ============ ODD OR EVEN (call + roll, 10 rounds, 2-3P) ============
export function OddEven(props: GameProps){
  const {mySlot,players,solo}=props;
  const n=solo?2:(players.length||2);
  const names=[0,1,2].slice(0,n).map(i=>slotName(players,i,solo));
  type S={round:number;calls:(string|null)[];rolls:(number|null)[];scores:number[];win:any;reveal:boolean};
  const init=():S=>({round:1,calls:names.map(()=>null),rolls:names.map(()=>null),scores:names.map(()=>0),win:null,reveal:false});
  const[s,setS]=useSync(props,'oddeven',init);
  const done=useRef(false);
  useEffect(()=>{ try{const w:any=(s as any)?.win;if(w===null||w===undefined)done.current=false;}catch{} },[s]);
  const me=solo?0:mySlot;
  const call=(c:string)=>{
    if(s.win||s.reveal)return;
    if(s.calls[me])return;
    const calls=[...s.calls];calls[me]=c;
    if(solo){
      const cpu=c==='odd'?'even':'odd';
      calls[1]=Math.random()<0.5?c:cpu;
      resolveCalls(calls);
      return;
    }
    setS({...s,calls});
    if(calls.every(Boolean)){
      // everyone called: roll the dice centrally once all locked
      setTimeout(()=>resolveCalls(calls),400);
    }
  };
  const resolveCalls=(calls:(string|null)[])=>{
    const roll=1+Math.floor(Math.random()*6);
    const parity=roll%2===1?'odd':'even';
    const rolls:(number|null)[]=[...s.rolls];
    const scores=[...s.scores];
    // winner(s) who called parity split point
    const winners:number[]=[];
    (calls as string[]).forEach((c,i)=>{if(c===parity)winners.push(i);});
    rolls.fill(roll as any);
    if(winners.length===1)scores[winners[0]]+=100;
    else if(winners.length>1)winners.forEach(i=>scores[i]+=50);
    else{
      // nobody right: closest consolation — nobody scores
    }
    const log=`🎲 ${roll} (${parity})`;
    if(s.round>=10){
      const best=Math.max(...scores);const tops=scores.map((v,i)=>v===best?i:-1).filter(i=>i>=0);
      const w=tops.length===1?tops[0]:-1;
      setS({round:s.round+1,calls:names.map(()=>null),rolls:rolls as any,scores,win:w,reveal:true});
      setTimeout(()=>finish(w,scores),900);
    } else {
      setS({round:s.round+1,calls:names.map(()=>null),rolls:rolls as any,scores,win:null,reveal:true});
      setTimeout(()=>setS({round:s.round+1,calls:names.map(()=>null),rolls:names.map(()=>null),scores,win:null,reveal:false}),1300);
    }
  };
  const finish=(w:number,scores:number[])=>{if(done.current)return;done.current=true;const sc:any={};names.forEach((nm,i)=>sc[nm]=scores[i]);props.onFinish({winnerName:w<0?null:names[w],winnerIndex:w<0?null:(solo?(w===0?0:null):w),scores:sc});};
  const rematch=()=>{done.current=false;setS(init());};
  const faces=['','⚀','⚁','⚂','⚃','⚄','⚅'];
  return (<div className="max-w-md mx-auto text-center">
    <TurnBanner text={s.win!==null&&s.win!==undefined?'FINAL CALLS':`ROUND ${Math.min(s.round,10)}/10 · CALL IT!`} color="#38bdf8" />
    <div className="flex gap-2 justify-center text-xs font-bold mb-3">{names.map((nm,i)=><span key={i} style={{color:['#ff2e63','#08d9d6','#ffe74c'][i]}}>{nm}: {s.scores[i]} {s.calls[i]?`(${s.calls[i]})`:''}</span>)}</div>
    {s.reveal&&<div className="text-5xl mb-1">{faces[(s.rolls[0] as any)||0]||'🎲'}</div>}
    {s.reveal&&<div className="text-xs text-slate-400 mb-2">{(s.rolls[0] as any)?`rolled ${(s.rolls[0] as any)} — ${((s.rolls[0] as any)%2===1?'ODD':'EVEN')} takes it`:''}</div>}
    <div className="grid grid-cols-2 gap-2 max-w-xs mx-auto">
      {(['odd','even'] as string[]).map(c=>(
        <button key={c} onClick={()=>call(c)} disabled={!!s.calls[me]||s.reveal} className="pixel-panel p-5 text-center hover:scale-105 transition"
          style={{opacity:s.calls[me]&&s.calls[me]!==c?0.4:1,borderColor:s.calls[me]===c?'#4dff88':undefined}}>
          <div className="text-3xl">{c==='odd'?'🔢':'🔟'}</div><div className="font-pixel text-[11px] mt-2">{c.toUpperCase()}</div>
        </button>))}
    </div>
    {!solo&&s.calls[me]&&!s.calls.every(Boolean)&&<div className="text-xs blink mt-2" style={{color:'#ffe74c'}}>Locked “{s.calls[me]}” — waiting for rivals…</div>}
    {(s.win!==null&&s.win!==undefined)&&(()=>{const sc:any={};names.forEach((nm,i)=>sc[nm]=s.scores[i]);
      return <WinnerOverlay winnerName={s.win<0?null:names[s.win]} isMe={s.win>=0&&names[s.win]===(solo?names[0]:players[mySlot]?.name)} scores={names.map(nm=>[nm,sc[nm]] as [string,number])} gameTitle="Odd or Even" onRematch={rematch} showRematch />;})()}
  </div>);
}

// ============ TRIPLE TIC-TAC (4x4, 4-in-a-row) ============
export function TripleTic(props: GameProps){
  const {mySlot,players,solo}=props;
  const names=[slotName(players,0,solo),slotName(players,1,solo)];
  type S={b:(string|null)[];turn:number;win:string|null|'draw'};
  const init=():S=>({b:Array(16).fill(null),turn:0,win:null});
  const[s,setS]=useSync(props,'ttt4',init);
  const done=useRef(false);
  useEffect(()=>{ try{const w:any=(s as any)?.win;if(w===null||w===undefined)done.current=false;}catch{} },[s]);
  const marks=['X','O'];
  const check=(b:(string|null)[])=>{
    const L:number[][]=[];
    for(let r=0;r<4;r++)L.push([r*4,r*4+1,r*4+2,r*4+3]);
    for(let c=0;c<4;c++)L.push([c,c+4,c+8,c+12]);
    L.push([0,5,10,15]);L.push([3,6,9,12]);
    for(const line of L){const [a,b1,c,d]=line;if(b[a]&&b[a]===b[b1]&&b[a]===b[c]&&b[a]===b[d])return b[a];}
    return b.every(Boolean)?'draw':null;
  };
  const finish=(w:string|null|'draw',board:(string|null)[])=>{
    if(done.current||!w)return;done.current=true;
    if(w==='draw')props.onFinish({winnerName:null,winnerIndex:null,scores:{[names[0]]:1,[names[1]]:1}});
    else{const wi=marks.indexOf(w);props.onFinish({winnerName:names[wi],winnerIndex:solo?(wi===0?0:null):wi,scores:{[names[0]]:wi===0?1:0,[names[1]]:wi===1?1:0}});}
  };
  if(s.win)setTimeout(()=>finish(s.win,s.b),60);
  const cpuMove=(b:(string|null)[])=>{
    const empt=b.map((v,i)=>v?null:i).filter(v=>v!==null) as number[];
    for(const i of empt){const t=[...b];t[i]='O';if(check(t)==='O')return i;}
    for(const i of empt){const t=[...b];t[i]='X';if(check(t)==='X')return i;}
    const center=[5,6,9,10].filter(i=>b[i]===null);
    if(center.length)return center[Math.floor(Math.random()*center.length)];
    return empt[Math.floor(Math.random()*empt.length)];
  };
  const click=(i:number)=>{
    if(s.win||s.b[i])return;
    if(!solo&&s.turn!==mySlot)return;
    if(solo&&s.turn!==0)return;
    const nb=[...s.b];nb[i]=marks[s.turn];
    let w=check(nb);let nt=(s.turn+1)%2;
    if(solo&&!w&&nt===1){const ci=cpuMove(nb);nb[ci]='O';w=check(nb);nt=0;}
    setS({b:nb,turn:nt,win:w});
    if(w)finish(w,nb);
  };
  const rematch=()=>{done.current=false;setS(init());};
  const myTurnNow=solo||s.turn===mySlot;
  return (<div className="max-w-xs mx-auto">
    <TurnBanner text={s.win?(s.win==='draw'?'DRAW!':`WINNER: ${s.win==='X'?names[0]:names[1]}`):(myTurnNow?`YOUR TURN (${marks[solo?0:s.turn]})`:`${names[s.turn]}'S TURN`)} color={myTurnNow?'#4dff88':'#ffe74c'} />
    <div className="text-xs text-center text-slate-400 mb-2">4×4 grid · link 4 to win</div>
    <div className="grid grid-cols-4 gap-2">
      {s.b.map((v,i)=>(
        <button key={i} onClick={()=>click(i)} className="game-grid-cell clickable aspect-square rounded-xl font-pixel text-2xl flex items-center justify-center"
          style={{background:v?(v==='X'?'rgba(255,46,99,.18)':'rgba(8,217,214,.18)'):'#0d0d24',border:'2px solid #3d3d7a',color:v==='X'?'#ff2e63':'#08d9d6',cursor:myTurnNow&&!v?'pointer':'default'}}>{v}</button>
      ))}
    </div>
    <div className="flex justify-center gap-3 mt-4 text-xs">
      <span style={{color:'#ff2e63'}}>✕ {names[0]}</span><span className="text-slate-500">vs</span><span style={{color:'#08d9d6'}}>◯ {names[1]}</span>
    </div>
    {s.win&&<WinnerOverlay winnerName={s.win==='draw'?null:(s.win==='X'?names[0]:names[1])} isMe={s.win!=='draw'&&((s.win==='X'?names[0]:names[1])===(solo?names[0]:players[mySlot]?.name))} scores={[]} gameTitle="Triple Tic-Tac" onRematch={rematch} showRematch />}
  </div>);
}
