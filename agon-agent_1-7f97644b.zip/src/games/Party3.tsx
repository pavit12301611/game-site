import { useEffect, useRef, useState } from 'react';
import { useSync, useRace, TurnBanner, WinnerOverlay } from './shared';
import type { GameProps } from './types';
import { slotName } from './types';
import { hashStr, mulberry32 } from '../lib/rand';

function RaceBar({ live, me, score }: { live: [string, number][]; me: string; score: number }) {
  const rows = live.map(([n, s]) => n.includes('(you)') ? [me + ' (you)', score] as [string, number] : [n, s] as [string, number]);
  if (!rows.filter(([n]) => !n.includes('(you)')).length && rows.length <= 1) return null;
  const sorted = [...rows].sort((a,b)=>b[1]-a[1]);
  const top = sorted[0]?.[1] ?? 0;
  return (<div className="score-strip">{sorted.map(([n,s],i)=>(<span key={i} className={`score-chip ${n.includes('(you)')?'score-chip-me':''} ${s===top&&s>0?'score-chip-lead':''}`}>{i===0?'👑 ':i+1+'. '}{n}: {s}</span>))}</div>);
}

// ============ BLACKJACK (shared deck, dealer CPU) ============
function bjVal(hand:number[]){let t=0,aces=0;hand.forEach(c=>{const r=(c%13)+2;if(r>=11&&r<=13)t+=10;else if(r===14){aces++;t+=11;}else t+=r;});while(t>21&&aces>0){t-=10;aces--;}return t;}
export function Blackjack(props: GameProps){
  const {mySlot,players,solo}=props;
  const n=solo?1:(players.length||2);
  const names=[0,1,2].slice(0,Math.max(1,n)).map(i=>slotName(players,i,solo));
  const seedRef=useRef(props.room?.code||('solo-bj-'+Date.now()));
  type S={deck:number[];hands:number[][];dealer:number[];turn:number;done:boolean[];win:any;round:number;bank:number[]};
  const freshDeck=(seed:string)=>{let h=2166136261;for(let i=0;i<seed.length;i++){h^=seed.charCodeAt(i);h=Math.imul(h,16777619);}let a=h>>>0;const rng=()=>{a|=0;a=(a+0x6D2B79F5)|0;let t=Math.imul(a^(a>>>15),1|a);t=(t+Math.imul(t^(t>>>7),61|t))^t;return((t^(t>>>14))>>>0)/4294967296;};const d=[...Array(52).keys()];for(let i=51;i>0;i--){const j=Math.floor(rng()*(i+1));[d[i],d[j]]=[d[j],d[i]];}return d;};
  const deal=(round:number):S=>{
    const deck=freshDeck(seedRef.current+':'+round);
    const hands:number[][]=names.map(()=>[]);const dealer:number[]=[];
    for(let k=0;k<2;k++){hands.forEach(h=>h.push(deck.pop()!));dealer.push(deck.pop()!);}
    return {deck,hands,dealer,turn:0,done:names.map(()=>false),win:null,round,bank:([] as number[])};
  };
  const[s,setS]=useSync(props,'bj',()=>deal(1));
  const finished = useRef(false);
  useEffect(()=>{ try { const _w:any=(s as any)?.win; if(_w===null||_w===undefined) finished.current=false; } catch{} }, [s]);
  const scores=useRef<number[]>(names.map(()=>0));
  const card=(v:number)=>({r:['','','2','3','4','5','6','7','8','9','10','J','Q','K','A'][(v%13)+2]||'',s:['♠','♥','♦','♣'][Math.floor(v/13)]});
  const red=(v:number)=>Math.floor(v/13)===1||Math.floor(v/13)===2;
  const me=solo?0:mySlot;
  const myDone=s.done[me];
  const myVal=bjVal(s.hands[me]||[]);
  const hit=()=>{
    if(s.win||myDone)return;
    if(!solo&&s.turn!==me)return;
    const deck=[...s.deck];const hands=s.hands.map(h=>[...h]);
    hands[me].push(deck.pop()!);
    const v=bjVal(hands[me]);
    const done=[...s.done];
    if(v>21)done[me]=true;
    advance(hands,deck,done);
  };
  const stand=()=>{
    if(s.win||myDone)return;
    if(!solo&&s.turn!==me)return;
    const done=[...s.done];done[me]=true;
    advance(s.hands.map(h=>[...h]),[...s.deck],done);
  };
  const advance=(hands:number[][],deck:number[],done:boolean[])=>{
    if(solo){
      // dealer plays, settle immediately
      const dealer=[...s.dealer];
      while(bjVal(dealer)<17&&deck.length)dealer.push(deck.pop()!);
      const dv=bjVal(dealer);const pv=bjVal(hands[0]);
      const w=pv>21?2:(dv>21||pv>dv?0:(pv===dv?3:2));
      setS({deck,hands,dealer,turn:0,done,win:w,round:s.round,bank:[]});
      setTimeout(()=>finishSolo(w),900);
      return;
    }
    // next unfinished player
    let nt=(s.turn+1)%names.length;let guard=0;
    while(done[nt]&&guard<5){nt=(nt+1)%names.length;guard++;}
    if(done.every(Boolean)){
      const dealer=[...s.dealer];const d2=[...deck];
      while(bjVal(dealer)<17&&d2.length)dealer.push(d2.pop()!);
      const dv=bjVal(dealer);
      const results=hands.map(h=>{const pv=bjVal(h);return pv>21?-1:(dv>21||pv>dv?1:(pv===dv?0:-1));});
      const best=Math.max(...results);
      const tops=results.map((r,i)=>r===best?i:-1).filter(i=>i>=0);
      const w=tops.length===1&&best>=0?tops[0]:-1;
      setS({deck:d2,hands,dealer,turn:nt,done,win:{w,results,dv},round:s.round,bank:[]});
      setTimeout(()=>finishRoom(w,results),1000);
    } else setS({deck,hands,dealer:[...s.dealer],turn:nt,done,win:null,round:s.round,bank:[]});
  };
  const finishSolo=(w:number)=>{
    if(finished.current)return;finished.current=true;
    const pv=bjVal(s.hands[0]);
    const label=w===0?props.playerName:(w===2?'Dealer':'Push');
    props.onFinish({winnerName:w===3?null:label,winnerIndex:w===0?0:null,scores:{[props.playerName]:w===0?100:(w===3?50:0)}});
  };
  const finishRoom=(w:number,results:number[])=>{
    if(finished.current)return;finished.current=true;
    const sc:any={};names.forEach((nm,i)=>sc[nm]=results[i]===1?100:(results[i]===0?50:0));
    props.onFinish({winnerName:w<0?null:names[w],winnerIndex:w<0?null:w,scores:sc});
  };
  const nextRound=()=>{finished.current=false;setS(deal(s.round+1));};
  const cols=['#ff2e63','#08d9d6','#ffe74c'];
  const isOver=s.win!==null&&s.win!==undefined;
  return (<div className="max-w-lg mx-auto text-center">
    <TurnBanner text={isOver?'SHOWDOWN':(solo?'YOUR MOVE · HIT OR STAND':(s.turn===me?'YOUR MOVE':'WAITING…'))} color="#4dff88" />
    <div className="pixel-panel p-4 mb-3">
      <div className="text-xs font-bold text-slate-400 mb-2">DEALER {isOver?`· ${bjVal(s.dealer)}`:'· ?'}</div>
      <div className="flex gap-2 justify-center">
        {s.dealer.map((c,i)=>(<MiniCard key={i} v={c} hide={!isOver&&i===1} />))}
      </div>
    </div>
    <div className="grid gap-2" style={{gridTemplateColumns:`repeat(${names.length},1fr)`}}>
      {names.map((nm,i)=>(<div key={i} className="pixel-panel p-3" style={{borderColor:s.turn===i&&!isOver?'#4dff88':undefined}}>
        <div className="text-[11px] font-bold" style={{color:cols[i]}}>{nm}{i===me?' (you)':''} · {bjVal(s.hands[i]||[])}</div>
        <div className="flex gap-1 justify-center mt-2 flex-wrap">{(s.hands[i]||[]).map((c,j)=><MiniCard key={j} v={c} small />)}</div>
        {s.done[i]&&<div className="text-[10px] text-slate-500 mt-1">STAND/BUST</div>}
      </div>))}
    </div>
    {!isOver&&!myDone&&(solo||s.turn===me)&&<div className="flex gap-2 justify-center mt-3">
      <button className="pixel-btn" onClick={hit}>+ HIT {myVal}</button>
      <button className="pixel-btn pixel-btn-yellow" onClick={stand}>STAND</button>
    </div>}
    {!isOver&&myDone&&<div className="text-xs text-slate-400 mt-3">Locked — waiting for table…</div>}
    {isOver&&<div className="mt-4">
      <div className="font-pixel text-xs mb-3" style={{color:'#ffe74c'}}>{solo?(s.win===0?'YOU BEAT THE DEALER!':s.win===3?'PUSH!':'DEALER WINS'):(typeof s.win==='object'?(s.win.w<0?'DRAW!':`${names[s.win.w]} TAKES IT!`):'')}</div>
      <button className="pixel-btn pixel-btn-cyan" onClick={nextRound}>🔁 Next hand</button>
    </div>}
  </div>);
}
function MiniCard({v,hide,small}:{v:number;hide?:boolean;small?:boolean}){
  if(hide)return <div className="rounded-lg flex items-center justify-center font-bold" style={{width:small?40:56,height:small?56:76,background:'#a06bff',border:'2px solid #000'}}>?</div>;
  const r=['','','2','3','4','5','6','7','8','9','10','J','Q','K','A'][(v%13)+2];
  const su=['♠','♥','♦','♣'][Math.floor(v/13)];
  const isRed=Math.floor(v/13)===1||Math.floor(v/13)===2;
  return <div className="rounded-lg flex flex-col items-center justify-center font-bold" style={{width:small?40:56,height:small?56:76,background:'#f5f5f5',border:'2px solid #000',color:isRed?'#e11d48':'#111',fontSize:small?13:17}}><span>{r}</span><span>{su}</span></div>;
}

// ============ REACTION ZAP ============
export function Reaction(props: GameProps){
  const {mySlot,players,solo}=props;
  const n=solo?2:(players.length||2);
  const names=[0,1,2].slice(0,n).map(i=>slotName(players,i,solo));
  type S={round:number;phase:string;goAt:number;clicks:{slot:number;t:number}[];scores:number[];win:any};
  const init=():S=>({round:1,phase:'wait',goAt:0,clicks:[],scores:names.map(()=>0),win:null});
  const[s,setS]=useSync(props,'rx',init);
  const done=useRef(false);
  const timer=useRef<any>(null);
  const me=solo?0:mySlot;
  useEffect(()=>()=>clearTimeout(timer.current),[]);
  const startRound=()=>{
    if(s.phase==='run'||s.phase==='go')return;
    const wait=1500+Math.random()*2500;
    setS({...s,phase:'run',clicks:[]});
    timer.current=setTimeout(()=>{setS(cur=>({...cur,phase:'go',goAt:Date.now()}));},wait);
  };
  const tap=()=>{
    if(s.phase==='run'){
      // false start: penalize
      const scores=[...s.scores];scores[me]=Math.max(0,scores[me]-50);
      setS({...s,scores});
      if(solo){/* cpu unaffected */}
      return;
    }
    if(s.phase!=='go')return;
    const t=Date.now()-s.goAt;
    if(solo){
      const cpuT=220+Math.random()*380;
      const scores=[...s.scores];
      if(t<cpuT)scores[0]+=Math.max(10,500-Math.round(t/2));else scores[1]+=300;
      const msg=t<cpuT?'win':'lose';
      if(s.round>=5){setS({round:s.round+1,phase:'done',goAt:0,clicks:[],scores,win:scores[0]>=scores[1]?0:1});setTimeout(()=>finish(scores[0]>=scores[1]?0:1,scores),900);}
      else setS({round:s.round+1,phase:'wait',goAt:0,clicks:[],scores,win:null});
      return;
    }
    if(s.clicks.some(c=>c.slot===me))return;
    const clicks=[...s.clicks,{slot:me,t}];
    setS({...s,clicks});
    if(clicks.length>=n){
      const sorted=[...clicks].sort((a,b)=>a.t-b.t);
      const scores=[...s.scores];
      sorted.forEach((c,i)=>{scores[c.slot]+=i===0?100:(i===1?40:10);});
      if(s.round>=5){const best=Math.max(...scores);const tops=scores.map((v,i)=>v===best?i:-1).filter(i=>i>=0);const w=tops.length===1?tops[0]:-1;
        setS({round:s.round+1,phase:'done',goAt:0,clicks,scores,win:w});setTimeout(()=>finish(w,scores),900);}
      else setS({round:s.round,phase:'result',goAt:0,clicks,scores,win:null});
    }
  };
  const finish=(w:number,scores:number[])=>{if(done.current)return;done.current=true;const sc:any={};names.forEach((nm,i)=>sc[nm]=scores[i]);props.onFinish({winnerName:w<0?null:names[w],winnerIndex:w<0?null:(solo?(w===0?0:null):w),scores:sc});};
  const rematch=()=>{done.current=false;setS(init());};
  const next=()=>setS({...s,round:s.round+1,phase:'wait',clicks:[]});
  const bg=s.phase==='go'?'#1f9d55':s.phase==='run'?'#7f1d1d':s.phase==='result'?'#1c1c3d':'#2b2b5e';
  return (<div className="max-w-md mx-auto text-center">
    <TurnBanner text={s.win!==null&&s.win!==undefined?'FINAL':`ROUND ${Math.min(s.round,5)}/5`} color="#ff2e63" />
    <div className="flex gap-2 justify-center text-xs font-bold mb-3">{names.map((nm,i)=><span key={i} style={{color:['#ff2e63','#08d9d6','#ffe74c'][i]}}>{nm}: {s.scores[i]}</span>)}</div>
    <button onClick={tap} disabled={s.phase==='wait'||s.phase==='done'||s.phase==='result'}
      className="w-full rounded-2xl font-pixel text-sm py-16 transition-all" style={{background:bg,border:'3px solid #000'}}>
      {s.phase==='wait'?'TAP START, THEN WAIT…':s.phase==='run'?'WAIT FOR GREEN…':s.phase==='go'?'TAP NOW!! ⚡':s.phase==='result'?'ROUND LOCKED':'DONE!'}
    </button>
    {s.clicks.length>0&&<div className="text-xs mt-2 space-y-1">{[...s.clicks].sort((a,b)=>a.t-b.t).map((c,i)=><div key={i} style={{color:['#ff2e63','#08d9d6','#ffe74c'][c.slot]}}>{i+1}. {names[c.slot]} — {c.t}ms</div>)}</div>}
    <div className="flex gap-2 justify-center mt-3">
      {(s.phase==='wait')&&<button className="pixel-btn" onClick={startRound}>▶ Start round {Math.min(s.round,5)}</button>}
      {s.phase==='result'&&<button className="pixel-btn pixel-btn-cyan" onClick={next}>Next →</button>}
      {s.phase==='run'&&<span className="text-xs text-slate-500">Don't tap early! (−50)</span>}
    </div>
    {(s.win!==null&&s.win!==undefined)&&(()=>{const sc:any={};names.forEach((nm,i)=>sc[nm]=s.scores[i]);
      return <WinnerOverlay winnerName={s.win<0?null:names[s.win]} isMe={s.win>=0&&names[s.win]===(solo?names[0]:players[mySlot]?.name)} scores={names.map(nm=>[nm,sc[nm]] as [string,number])} gameTitle="Reaction Zap" onRematch={rematch} showRematch />;})()}
  </div>);
}

// ============ NUMBER HEIST ============
export function GuessNum(props: GameProps){
  const {solo,playerName}=props;const{report,finalize,liveList}=useRace(props);
  const seed=props.room?.code||'solo-num';
  const target=useRef(0);
  if(!target.current){const r=mulberry32(hashStr('gn'+seed));target.current=1+Math.floor(r()*100);}
  const[guess,setGuess]=useState('');const[tries,setTries]=useState<number[]>([]);const[over,setOver]=useState(false);const[hint,setHint]=useState('Pick 1-100');
  const score=over?Math.max(50,1000-(tries.length-1)*90):0;
  const submit=()=>{
    const v=parseInt(guess);
    if(!v||v<1||v>100||over)return;
    const nt=[...tries,v];setTries(nt);setGuess('');
    if(v===target.current){setOver(true);setHint(`CRACKED in ${nt.length}!`);report(Math.max(50,1000-(nt.length-1)*90));}
    else{setHint(v<target.current?`⬆ Higher than ${v}`:`⬇ Lower than ${v}`);report(Math.max(0,300-nt.length*10));}
  };
  return (<div className="max-w-xs mx-auto text-center">
    <TurnBanner text={over?`${score} PTS`:`${tries.length} TRIES`} color="#08d9d6" />
    {!solo&&<RaceBar live={liveList} me={playerName} score={over?score:Math.max(0,300-tries.length*10)} />}
    <div className="text-xs text-slate-400 mb-2">Same code for the room · fewest tries wins</div>
    <div className="pixel-panel p-5 mb-3"><div className="font-pixel text-sm" style={{color:'#08d9d6'}}>{hint}</div>
      <div className="flex gap-1 justify-center mt-3 flex-wrap">{tries.map((t,i)=><span key={i} className="text-[11px] px-2 py-1 rounded font-bold" style={{background:t===target.current?'#1f9d55':'#0a0a20',border:'1px solid #3d3d7a'}}>{t}</span>)}</div>
    </div>
    {!over?<div className="flex gap-2"><input className="pixel-input font-pixel text-center" type="number" min={1} max={100} value={guess} onChange={e=>setGuess(e.target.value)} onKeyDown={e=>{if(e.key==='Enter')submit();}} placeholder="?" /><button className="pixel-btn" onClick={submit}>Go</button></div>
    :<button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:playerName,winnerIndex:0,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>}
  </div>);
}

// ============ BINGO BLITZ ============
export function Bingo(props: GameProps){
  const {mySlot,players,solo}=props;
  const n=solo?2:(players.length||2);
  const names=[0,1,2].slice(0,n).map(i=>slotName(players,i,solo));
  const seed=props.room?.code||'solo-bingo';
  type S={cards:number[][];called:number[];turn:number;win:any;pool:number[]};
  const init=():S=>{
    const mk=(salt:string)=>{const r=mulberry32(hashStr(seed+salt));const nums=[...Array(25).keys()].map(i=>i+1);for(let i=24;i>0;i--){const j=Math.floor(r()*(i+1));[nums[i],nums[j]]=[nums[j],nums[i]];}return nums;};
    const pool=[...Array(25).keys()].map(i=>i+1);
    const r0=mulberry32(hashStr(seed+'pool'));for(let i=24;i>0;i--){const j=Math.floor(r0()*(i+1));[pool[i],pool[j]]=[pool[j],pool[i]];}
    return {cards:names.map((_,i)=>mk(':card'+i)),called:[],turn:0,win:null,pool};
  };
  const[s,setS]=useSync(props,'bingo',init);
  const done=useRef(false);
  const lines=(card:number[],called:number[])=>{
    const hit=(v:number)=>called.includes(v);
    let L=0;
    for(let r=0;r<5;r++)if([0,1,2,3,4].every(c=>hit(card[r*5+c])))L++;
    for(let c=0;c<5;c++)if([0,1,2,3,4].every(r=>hit(card[r*5+c])))L++;
    if([0,6,12,18,24].every(i=>hit(card[i])))L++;
    if([4,8,12,16,20].every(i=>hit(card[i])))L++;
    return L;
  };
  const call=()=>{
    if(s.win)return;
    const me=solo?0:mySlot;
    if(s.turn!==me)return;
    if(s.called.length>=25)return;
    const next=s.pool[s.called.length];
    const called=[...s.called,next];
    // solo: cpu shares same calls — check both
    const counts=s.cards.map(c=>lines(c,called));
    const w=counts.findIndex(c=>c>=2);
    // need 2 lines for bingo blitz
    if(w>=0){
      setS({...s,called,win:w});
      setTimeout(()=>finish(w,counts),800);
      return;
    }
    let nt=(s.turn+1)%n;
    if(solo)nt=0;
    setS({...s,called,turn:nt,win:null});
  };
  const finish=(w:number,counts:number[])=>{if(done.current)return;done.current=true;const sc:any={};names.forEach((nm,i)=>sc[nm]=counts[i]*100+(25-s.called.length)*5);props.onFinish({winnerName:names[w],winnerIndex:solo?(w===0?0:null):w,scores:sc});};
  const rematch=()=>{done.current=false;setS(init());};
  const me=solo?0:mySlot;
  const myTurn=solo||s.turn===me;
  const last=s.called[s.called.length-1];
  return (<div className="max-w-lg mx-auto text-center">
    <TurnBanner text={s.win!==null&&s.win!==undefined?'BINGO!':(myTurn?`YOUR CALL ${last?`· last ${last}`:''}`:`${names[s.turn]} CALLS…`)} color="#ffe74c" />
    <div className="text-xs text-slate-400 mb-2">Shared number pool · first to 2 lines shouts BINGO</div>
    <div className="flex gap-1 justify-center flex-wrap mb-3 max-w-md mx-auto">
      {s.called.slice(-8).map((v,i)=><span key={i} className="font-pixel text-[10px] px-2 py-1 rounded" style={{background:i===s.called.slice(-8).length-1?'#ffe74c':'#0a0a20',color:i===s.called.slice(-8).length-1?'#000':'#ffe74c',border:'1px solid #6b5f20'}}>{v}</span>)}
      {!s.called.length&&<span className="text-xs text-slate-500">no calls yet</span>}
    </div>
    <div className="grid gap-3" style={{gridTemplateColumns:`repeat(${Math.min(n,2)},1fr)`}}>
      {names.map((nm,pi)=>{
        const L=lines(s.cards[pi]||[],s.called);
        const mine=pi===me;
        return <div key={pi} className="pixel-panel p-2" style={{borderColor:mine?'#4dff88':undefined,opacity:!mine&&n>2?0.85:1}}>
          <div className="text-[11px] font-bold mb-1" style={{color:['#ff2e63','#08d9d6','#ffe74c'][pi]}}>{nm}{mine?' (you)':''} · {L}/2 lines</div>
          <div className="grid grid-cols-5 gap-1">
            {(s.cards[pi]||[]).map((v,i)=><div key={i} className="aspect-square rounded text-[11px] font-bold flex items-center justify-center" style={{background:s.called.includes(v)?'#4dff88':'#0a0a20',color:s.called.includes(v)?'#063':'#c9c9e3',border:'1px solid #3d3d7a'}}>{v}</div>)}
          </div>
        </div>;})}
    </div>
    {(s.win===null||s.win===undefined)?(
      myTurn?<button className="pixel-btn mt-3" onClick={call}>🔔 CALL NUMBER ({s.called.length+1}/25)</button>
      :<div className="text-xs text-slate-500 mt-3">Waiting for {names[s.turn]} to call…</div>
    ):null}
    {(s.win!==null&&s.win!==undefined)&&(()=>{const sc:any={};names.forEach((nm,i)=>sc[nm]=lines(s.cards[i],s.called)*100);
      return <WinnerOverlay winnerName={names[s.win]} isMe={names[s.win]===(solo?names[0]:players[mySlot]?.name)} scores={names.map(nm=>[nm,sc[nm]] as [string,number])} gameTitle="Bingo Blitz" onRematch={rematch} showRematch />;})()}
  </div>);
}
