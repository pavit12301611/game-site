import { useEffect, useRef, useState } from 'react';
import { useSync, useRace, TurnBanner, WinnerOverlay } from './shared';
import type { GameProps } from './types';

function RaceBar({ live, me, score }: { live: [string, number][]; me: string; score: number }) {
  const rows = live.map(([n, s]) => n.includes('(you)') ? [me + ' (you)', score] as [string, number] : [n, s] as [string, number]);
  if (!rows.filter(([n]) => !n.includes('(you)')).length && rows.length <= 1) return null;
  const sorted = [...rows].sort((a,b)=>b[1]-a[1]);
  const top = sorted[0]?.[1] ?? 0;
  return (<div className="score-strip">{sorted.map(([n,s],i)=>(<span key={i} className={`score-chip ${n.includes('(you)')?'score-chip-me':''} ${s===top&&s>0?'score-chip-lead':''}`}>{i===0?'👑 ':i+1+'. '}{n}: {s}</span>))}</div>);
}

// ============ 15-PUZZLE ============
export function FifteenGame(props: GameProps){
  const {solo,playerName}=props;const{report,finalize,liveList}=useRace(props);
  const[t,setT]=useState<number[]>([]);const[moves,setMoves]=useState(0);const[sec,setSec]=useState(0);const[started,setStarted]=useState(false);const[over,setOver]=useState(false);
  const score=Math.max(0,2000-moves*8-sec*3);
  const start=()=>{
    const a=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,0];
    for(let i=0;i<160;i++){const z=a.indexOf(0);const r=Math.floor(z/4),c=z%4;const opts=[];if(r>0)opts.push(z-4);if(r<3)opts.push(z+4);if(c>0)opts.push(z-1);if(c<3)opts.push(z+1);const s=opts[Math.floor(Math.random()*opts.length)];[a[z],a[s]]=[a[s],a[z]];}
    setT(a);setMoves(0);setSec(0);setOver(false);setStarted(true);report(0);
  };
  useEffect(()=>{if(!started||over)return;const iv=setInterval(()=>setSec(s=>s+1),1000);return ()=>clearInterval(iv);},[started,over]);
  const solved=t.length>0&&t.every((v,i)=>v===(i+1)%16);
  useEffect(()=>{if(started&&solved&&!over){setOver(true);report(score);}},[solved]);
  const click=(i:number)=>{
    if(!started||over)return;
    const z=t.indexOf(0);const r1=Math.floor(z/4),c1=z%4,r2=Math.floor(i/4),c2=i%4;
    if(Math.abs(r1-r2)+Math.abs(c1-c2)!==1)return;
    const n=[...t];[n[z],n[i]]=[n[i],n[z]];setT(n);const m=moves+1;setMoves(m);report(Math.max(0,2000-m*8-sec*3));
  };
  return (<div className="max-w-xs mx-auto text-center">
    <TurnBanner text={over?`SOLVED · ${score}`:`${moves} MOVES · ${sec}s`} color="#38bdf8" />
    {!solo&&<RaceBar live={liveList} me={playerName} score={started?score:0} />}
    <div className="text-xs text-slate-400 mb-2">Slide tiles into order 1-15 · fastest score wins</div>
    <div className="grid grid-cols-4 gap-1.5 p-2 rounded-xl" style={{background:'#12233d',border:'3px solid #1e3a5f'}}>
      {(t.length?t:[...Array(16).keys()].map(i=>(i+1)%16)).map((v,i)=><button key={i} onClick={()=>click(i)} className="aspect-square rounded-lg font-pixel flex items-center justify-center" style={{background:v===0?'transparent':(v===(i+1)%16&&started?'rgba(77,255,136,.25)':'#2b4a73'),border:v===0?'none':'2px solid #3d6a9e',color:'#fff',fontSize:14}}>{v||''}</button>)}
    </div>
    <div className="flex gap-2 justify-center mt-3">
      {!started?<button className="pixel-btn" onClick={start}>▶ Shuffle</button>
      :over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:playerName,winnerIndex:0,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>
      :<button className="pixel-btn pixel-btn-ghost" onClick={start}>Reshuffle</button>}
    </div></div>);
}

// ============ SOKOBAN LITE (3 levels, timed) ============
const LEVELS=[
  ['#####','#...#','#.$ #'.replace(' ','#'),'#.@ #','#...#','#####'],
  ['######','#....#','#.##.#','#.#$.#','#.#@.#','#....#','######'],
  ['#######','#.....#','#.###.#','#.#$#.#','#.#.@.#','#.....#','#######'],
];
function parseLevel(rows:string[]){
  const walls=new Set<string>(),targets=new Set<string>();let boxes:string[]=[];let px=0,py=0;
  rows.forEach((row,y)=>{[...row].forEach((ch,x)=>{
    if(ch==='#')walls.add(x+','+y);
    if(ch==='.')targets.add(x+','+y);
    if(ch==='$')boxes.push(x+','+y);
    if(ch==='@'){px=x;py=y;targets.add(x+','+y);}
    if(ch==='*'){boxes.push(x+','+y);targets.add(x+','+y);}
  });});
  return {walls,targets,boxes,px,py,W:Math.max(...rows.map(r=>r.length)),H:rows.length};
}
export function SokobanGame(props: GameProps){
  const {solo,playerName}=props;const{report,finalize,liveList}=useRace(props);
  const[lv,setLv]=useState(0);const[pos,setPos]=useState({x:1,y:1});const[boxes,setBoxes]=useState<string[]>([]);
  const[meta,setMeta]=useState({walls:new Set<string>(),targets:new Set<string>(),W:5,H:6});
  const[moves,setMoves]=useState(0);const[sec,setSec]=useState(0);const[started,setStarted]=useState(false);const[over,setOver]=useState(false);
  const totalScore=useRef(0);
  const load=(i:number)=>{
    const p=parseLevel(LEVELS[i]);
    setMeta({walls:p.walls,targets:p.targets,W:p.W,H:p.H});
    setPos({x:p.px,y:p.py});setBoxes(p.boxes);
  };
  const start=()=>{totalScore.current=0;setLv(0);load(0);setMoves(0);setSec(0);setOver(false);setStarted(true);};
  useEffect(()=>{if(!started||over)return;const iv=setInterval(()=>setSec(s=>s+1),1000);return ()=>clearInterval(iv);},[started,over]);
  const done=boxes.length>0&&boxes.every(b=>meta.targets.has(b));
  useEffect(()=>{
    if(started&&!over&&done){
      const bonus=Math.max(100,1000-moves*5-sec*4);
      totalScore.current+=bonus;report(totalScore.current);
      if(lv>=LEVELS.length-1){setOver(true);}
      else setTimeout(()=>{setLv(l=>l+1);load(lv+1);setMoves(0);},700);
    }
  },[done]);
  const step=(dx:number,dy:number)=>{
    if(!started||over)return;
    const nx=pos.x+dx,ny=pos.y+dy;
    if(meta.walls.has(nx+','+ny))return;
    const bi=boxes.indexOf(nx+','+ny);
    if(bi>=0){
      const bx=nx+dx,by=ny+dy;
      if(meta.walls.has(bx+','+by)||boxes.includes(bx+','+by))return;
      const nb=[...boxes];nb[bi]=bx+','+by;setBoxes(nb);
    }
    setPos({x:nx,y:ny});setMoves(m=>m+1);
  };
  useEffect(()=>{const h=(e:KeyboardEvent)=>{if(e.key==='ArrowUp'||e.key==='w')step(0,-1);if(e.key==='ArrowDown'||e.key==='s')step(0,1);if(e.key==='ArrowLeft'||e.key==='a')step(-1,0);if(e.key==='ArrowRight'||e.key==='d')step(1,0);};window.addEventListener('keydown',h);return ()=>window.removeEventListener('keydown',h);});
  const score=totalScore.current;
  return (<div className="max-w-xs mx-auto text-center">
    <TurnBanner text={over?`DONE · ${score}`:`LEVEL ${lv+1}/3 · ${moves} PUSH`} color="#a06bff" />
    {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
    <div className="text-xs text-slate-400 mb-2">Push all 📦 onto green pads · Arrows/WASD</div>
    <div className="inline-block p-2 rounded-xl" style={{background:'#0d0d24',border:'3px solid #4a3a7a'}}>
      {Array.from({length:meta.H}).map((_,y)=>(<div key={y} className="flex">{Array.from({length:meta.W}).map((_,x)=>{
        const k=x+','+y;const wall=meta.walls.has(k);const tgt=meta.targets.has(k);const box=boxes.includes(k);const me=pos.x===x&&pos.y===y;
        return <div key={x} className="flex items-center justify-center text-lg" style={{width:34,height:34,background:wall?'#3d3d7a':tgt?'rgba(77,255,136,.25)':'#14142b',borderRadius:4}}>{wall?'':me?'😀':box?(tgt?'✅':'📦'):tgt?'·':''}</div>;})}</div>))}
    </div>
    <div className="grid grid-cols-3 gap-1 max-w-[200px] mx-auto mt-2 sm-hidden-dpad">
      {['▲','◀','▼','▶'].map(a=><button key={a} className="pixel-btn pixel-btn-ghost !px-3" onClick={()=>{if(a==='▲')step(0,-1);if(a==='▼')step(0,1);if(a==='◀')step(-1,0);if(a==='▶')step(1,0);}}>{a}</button>)}
    </div>
    <div className="flex gap-2 justify-center mt-3">
      {!started?<button className="pixel-btn" onClick={start}>▶ Start pushing</button>
      :over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:playerName,winnerIndex:0,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>
      :<span className="text-xs text-slate-500">Level {lv+1} of 3 · {sec}s</span>}
    </div></div>);
}

// ============ LIGHTS OUT ============
export function LightsGame(props: GameProps){
  const {solo,playerName}=props;const{report,finalize,liveList}=useRace(props);
  const N=5;
  const[g,setG]=useState<boolean[]>([]);const[moves,setMoves]=useState(0);const[sec,setSec]=useState(0);const[started,setStarted]=useState(false);const[over,setOver]=useState(false);
  const score=over?Math.max(100,3000-moves*25-sec*5):Math.max(0,1500-moves*10);
  const start=()=>{
    let a=Array(N*N).fill(false);
    for(let i=0;i<12;i++){const x=Math.floor(Math.random()*N*N);flipAt(a,x);}
    if(a.every(v=>!v))a[12]=true;
    setG(a);setMoves(0);setSec(0);setOver(false);setStarted(true);
  };
  function flipAt(a:boolean[],i:number){const r=Math.floor(i/N),c=i%N;[[0,0],[1,0],[-1,0],[0,1],[0,-1]].forEach(([dr,dc])=>{const nr=r+dr,nc=c+dc;if(nr>=0&&nr<N&&nc>=0&&nc<N)a[nr*N+nc]=!a[nr*N+nc];});}
  useEffect(()=>{if(!started||over)return;const iv=setInterval(()=>setSec(s=>s+1),1000);return ()=>clearInterval(iv);},[started,over]);
  const click=(i:number)=>{
    if(!started||over)return;
    const a=[...g];flipAt(a,i);setG(a);const m=moves+1;setMoves(m);report(Math.max(0,1500-m*10));
    if(a.every(v=>!v)){setOver(true);report(Math.max(100,3000-m*25-sec*5));}
  };
  return (<div className="max-w-xs mx-auto text-center">
    <TurnBanner text={over?`DARK! · ${score}`:`${moves} TAPS · ${sec}s`} color="#ffe74c" />
    {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
    <div className="text-xs text-slate-400 mb-2">Tap a light to flip it + neighbours · turn them all off</div>
    <div className="grid gap-1.5 p-2 rounded-xl" style={{gridTemplateColumns:`repeat(${N},1fr)`,background:'#2b2410',border:'3px solid #6b5f20'}}>
      {(g.length?g:Array(N*N).fill(false)).map((v,i)=><button key={i} onClick={()=>click(i)} className="aspect-square rounded-lg" style={{background:v?'#ffe74c':'#1c1c3d',boxShadow:v?'0 0 16px rgba(255,231,76,.7)':'none',border:'2px solid #000'}}/>)}
    </div>
    <div className="flex gap-2 justify-center mt-3">
      {!started?<button className="pixel-btn" onClick={start}>▶ Light it up</button>
      :over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:playerName,winnerIndex:0,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>
      :<button className="pixel-btn pixel-btn-ghost" onClick={start}>Reshuffle</button>}
    </div></div>);
}

// ============ SERPENT PATH (fill grid Hamiltonian-ish, 6x6) ============
export function SnakePuzGame(props: GameProps){
  const {solo,playerName}=props;const{report,finalize,liveList}=useRace(props);
  const N=6;
  const[path,setPath]=useState<[number,number][]>([[0,0]]);const[started,setStarted]=useState(false);const[over,setOver]=useState(false);const[sec,setSec]=useState(0);
  const score=path.length*10+(over&&path.length===N*N?Math.max(0,1000-sec*5):0);
  useEffect(()=>{if(!started||over)return;const iv=setInterval(()=>setSec(s=>s+1),1000);return ()=>clearInterval(iv);},[started,over]);
  const start=()=>{setPath([[0,0]]);setSec(0);setOver(false);setStarted(true);};
  const click=(r:number,c:number)=>{
    if(!started||over)return;
    const last=path[path.length-1];
    // backtrack
    const idx=path.findIndex(([a,b])=>a===r&&b===c);
    if(idx>=0){setPath(path.slice(0,idx+1));return;}
    if(Math.abs(last[0]-r)+Math.abs(last[1]-c)!==1)return;
    const np:[number,number][]=[...path,[r,c]];
    setPath(np);report(np.length*10);
    if(np.length===N*N){setOver(true);report(np.length*10+Math.max(0,1000-sec*5));}
  };
  const inPath=(r:number,c:number)=>path.findIndex(([a,b])=>a===r&&b===c);
  return (<div className="max-w-xs mx-auto text-center">
    <TurnBanner text={over?`FILLED! · ${score}`:`${path.length}/${N*N} · ${sec}s`} color="#4dff88" />
    {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
    <div className="text-xs text-slate-400 mb-2">Grow one unbroken trail covering every tile · tap to extend or backtrack</div>
    <div className="grid gap-1 p-2 rounded-xl" style={{gridTemplateColumns:`repeat(${N},1fr)`,background:'#0d2b1a',border:'3px solid #1f9d55'}}>
      {Array.from({length:N}).map((_,r)=>Array.from({length:N}).map((_,c)=>{
        const i=inPath(r,c);const last=path[path.length-1];const near=started&&!over&&i<0&&Math.abs(last[0]-r)+Math.abs(last[1]-c)===1;
        return <button key={r+'-'+c} onClick={()=>click(r,c)} className="aspect-square rounded font-pixel flex items-center justify-center" style={{background:i>=0?'#4dff88':near?'rgba(77,255,136,.25)':'#14142b',color:'#063',fontSize:11,border:'1px solid #1f9d55'}}>{i>=0?i+1:''}</button>; }))}
    </div>
    <div className="flex gap-2 justify-center mt-3">
      {!started?<button className="pixel-btn" onClick={start}>▶ Start trail</button>
      :over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:playerName,winnerIndex:0,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>
      :<button className="pixel-btn pixel-btn-ghost" onClick={start}>Restart</button>}
    </div></div>);
}
