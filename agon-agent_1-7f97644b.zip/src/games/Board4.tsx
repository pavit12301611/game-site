import {useMemo, useRef, useState, useEffect } from 'react';
import {useSync, TurnBanner, WinnerOverlay } from './shared';
import type {GameProps } from './types';
import {slotName } from './types';

// ---------- BATTLESHIP (fog: 5 ships of len 3,2,2 on 7x7) ----------
const BS = 7;
const SHIPS = [3,2,2];
function placeFleet(rng: () => number): number[][] {
 const g = Array.from({length:BS},()=>Array(BS).fill(0));
 for(const len of SHIPS){
  for(let t=0;t<200;t++){
   const horiz = rng()<0.5;
   const r = Math.floor(rng()*BS), c = Math.floor(rng()*BS);
   const cells:[number,number][]=[];
   for(let i=0;i<len;i++){const nr=r+(horiz?0:i),nc=c+(horiz?i:0);if(nr>=BS||nc>=BS)break;cells.push([nr,nc]);}
   if(cells.length!==len) continue;
   if(cells.some(([a,b])=>g[a][b])) continue;
   // no-touch rule
   let ok=true;
   for(const [a,b] of cells)for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++){const nr=a+dr,nc=b+dc;if(nr>=0&&nr<BS&&nc>=0&&nc<BS&&g[nr][nc]&&!cells.some(([x,y])=>x===nr&&y===nc))ok=false;}
   if(!ok) continue;
   cells.forEach(([a,b])=>g[a][b]=1); break;
  }
 }
 return g;
}
export function Battleship(props: GameProps) {
 const {mySlot, players, solo } = props;
 const names=[slotName(players,0,solo),slotName(players,1,solo)];
 const seedRef = useRef(props.room?.code || 'solo-bs');
 type S={fleets: number[][][]; shots: number[][][]; turn: number; win: any; phase: string };
 const init = (): S => {
  // deterministic per room so both clients agree
  let h=2166136261; const str=seedRef.current; for(let i=0;i<str.length;i++){h^=str.charCodeAt(i);h=Math.imul(h,16777619);} 
  let a=h>>>0; const rng=()=>{a|=0;a=(a+0x6D2B79F5)|0;let t=Math.imul(a^(a>>>15),1|a);t=(t+Math.imul(t^(t>>>7),61|t))^t;return((t^(t>>>14))>>>0)/4294967296;};
  return {fleets:[placeFleet(rng),placeFleet(rng)], shots:[Array.from({length:BS},()=>Array(BS).fill(0)),Array.from({length:BS},()=>Array(BS).fill(0))], turn:0, win:null, phase:'battle' };
 };
 const [s,setS]=useSync(props,'bs',init);
 const done=useRef(false);
 const totalCells = SHIPS.reduce((a,b)=>a+b,0);
 const hitsOn=(pi:number)=> (s.shots[pi]||[]).flat().filter(v=>v===2).length;
 const myView = solo?0:mySlot; // which fleet do I shoot at? shoot at enemy
 const enemy = solo?1:(mySlot===0?1:0);
 const finish=(w:number)=>{if(done.current)return; done.current=true; props.onFinish({winnerName:names[w],winnerIndex:solo?(w===0?0:null):w,scores:{[names[0]]:hitsOn(1),[names[1]]:hitsOn(0)}}); };
 const fire=(r:number,c:number)=>{
  if(s.win!==null&&s.win!==undefined) return;
  if(!solo&&s.turn!==mySlot) return;
  if(solo&&s.turn!==0) return;
  if(s.shots[enemy][r][c]) return;
  const shots=s.shots.map(g=>g.map(row=>[...row]));
  const hit = s.fleets[enemy][r][c]===1;
  shots[enemy][r][c]=hit?2:1;
  const sunk = shots[enemy].flat().filter(v=>v===2).length>=totalCells;
  if(sunk){setS({...s,shots,win:enemy===1?0:1}); finish(enemy===1?0:1); return; }
  let nt=(s.turn+1)%2;
  // solo cpu retaliates
  if(solo){
   // cpu fires at player's fleet (0)
   const opts:[number,number][]=[];
   for(let a=0;a<BS;a++)for(let b=0;b<BS;b++)if(!shots[0][a][b])opts.push([a,b]);
   // hunt adjacent to hits
   const hits:[number,number][]=[];
   for(let a=0;a<BS;a++)for(let b=0;b<BS;b++)if(shots[0][a][b]===2)hits.push([a,b]);
   let pick:[number,number]=opts[Math.floor(Math.random()*opts.length)];
   for(const [hr,hc] of hits){const nb=[[hr+1,hc],[hr-1,hc],[hr,hc+1],[hr,hc-1]].filter(([a,b])=>a>=0&&a<BS&&b>=0&&b<BS&&!shots[0][a][b]);if(nb.length){pick=nb[0] as [number,number];break;}}
   const [ar,ac]=pick;
   shots[0][ar][ac]=s.fleets[0][ar][ac]===1?2:1;
   const sunkMe=shots[0].flat().filter(v=>v===2).length>=totalCells;
   if(sunkMe){setS({...s,shots,win:1});finish(1);return;}
   nt=0;
  }
  setS({...s,shots,turn:nt,win:null});
 };
 const myTurnNow=solo||s.turn===mySlot;
 const rematch=()=>{done.current=false;setS(init());};
 const myHits = hitsOn(enemy);
 const enemyHits = hitsOn(solo?0:(mySlot===0?1:0)===enemy? (mySlot===0?0:1):0);
 return (
  <div className="max-w-lg mx-auto">
   <TurnBanner text={(s.win!==null&&s.win!==undefined)?`${names[s.win]} SANK THE FLEET!`:(myTurnNow?'YOUR SHOT — FIRE!':`${names[s.turn]} IS AIMING…`)} color={myTurnNow?'#4dff88':'#ffe74c'} />
   <div className="text-center text-xs mb-3 text-slate-300">Enemy waters · {totalCells - myHits} ship cells remain · your hull: {totalCells - (s.shots[solo?0:mySlot]||[]).flat().filter(v=>v===2).length} left</div>
   <div className="grid gap-1 p-2 rounded-xl mx-auto" style={{gridTemplateColumns:`repeat(${BS},1fr)`,background:'#06283d',border:'3px solid #0e4a6e',maxWidth:380}}>
    {Array.from({length:BS}).map((_,r)=>Array.from({length:BS}).map((_,c)=>{
     const v=s.shots[enemy][r][c];
     return <button key={r+'-'+c} onClick={()=>fire(r,c)} className="game-grid-cell clickable aspect-square rounded text-lg" style={{background:v===2?'#ff2e63':v===1?'#134e6a':'#0a3a56',border:'1px solid #0e4a6e'}}>{v===2?'💥':v===1?'•':''}</button>;
    }))}
   </div>
   <div className="text-center text-xs mt-3 text-slate-400">Your fleet (hidden from enemy):</div>
   <div className="grid gap-[3px] p-2 rounded-xl mx-auto mt-1" style={{gridTemplateColumns:`repeat(${BS},1fr)`,background:'#0d0d24',border:'2px solid #3d3d7a',maxWidth:280}}>
    {Array.from({length:BS}).map((_,r)=>Array.from({length:BS}).map((_,c)=>{
     const ship=s.fleets[solo?0:mySlot][r][c]===1;
     const shot=s.shots[solo?0:mySlot][r][c];
     return <div key={r+'-'+c} className="aspect-square rounded-[3px]" style={{background:shot===2?'#ff2e63':shot===1?'#334155':ship?'#38bdf8':'#1c1c3d'}}/>;
    }))}
   </div>
   {(s.win!==null&&s.win!==undefined)&&<WinnerOverlay winnerName={names[s.win]} isMe={names[s.win]===(solo?names[0]:players[mySlot]?.name)} scores={[[names[0],hitsOn(1)],[names[1],hitsOn(0)]]} gameTitle="Battleship Fog" onRematch={rematch} showRematch />}
  </div>
 );
}

// ---------- PAWN SKIRMISH (pawns only) ----------
export function PawnBattle(props: GameProps) {
 const {mySlot, players, solo } = props;
 const names=[slotName(players,0,solo),slotName(players,1,solo)];
 const N=6;
 const start=()=>{const g:(number)[][]=Array.from({length:N},()=>Array(N).fill(0));for(let c=0;c<N;c++){g[1][c]=2;g[N-2][c]=1;}return g;};
 type S={g:number[][];turn:number;sel:[number,number]|null;win:any};
 const init=():S=>({g:start(),turn:0,sel:null,win:null});
 const [s,setS]=useSync(props,'pawn',init);
 const done=useRef(false);
 const finish=(w:number,why:string)=>{if(done.current)return;done.current=true;props.onFinish({winnerName:names[w],winnerIndex:solo?(w===0?0:null):w,scores:{[names[0]]:w===0?1:0,[names[1]]:w===1?1:0}});};
 const movesFor=(g:number[][],r:number,c:number,p:number)=>{
  const out:[number,number][]=[];
  const d=p===1?-1:1;
  if(r+d>=0&&r+d<N){
   if(!g[r+d][c])out.push([r+d,c]);
   const startRow=p===1?N-2:1;
   if(r===startRow&&!g[r+d][c]&&!g[r+2*d][c])out.push([r+2*d,c]);
   for(const dc of [-1,1]){const nc=c+dc;if(nc>=0&&nc<N&&g[r+d][nc]&&g[r+d][nc]!==p)out.push([r+d,nc]);}
  }
  return out;
 };
 const click=(r:number,c:number)=>{
  if(s.win!==null&&s.win!==undefined)return;
  const me=solo?0:mySlot; if(s.turn!==me)return;
  const p=me+1;
  const g=s.g.map(row=>[...row]);
  if(s.sel){
   const [sr,sc2]=s.sel;
   if(movesFor(g,sr,sc2,p).some(([a,b])=>a===r&&b===c)){
    g[r][c]=p;g[sr][sc2]=0;
    if((p===1&&r===0)||(p===2&&r===N-1)){setS({g,turn:s.turn,sel:null,win:me});finish(me,'promo');return;}
    if(!g.flat().includes(3-p)){setS({g,turn:s.turn,sel:null,win:me});finish(me,'capture');return;}
    // stalemate check: opponent has no moves
    let opp=false;
    outer: for(let a=0;a<N;a++)for(let b=0;b<N;b++)if(g[a][b]===3-p&&movesFor(g,a,b,3-p).length){opp=true;break outer;}
    if(!opp){setS({g,turn:s.turn,sel:null,win:me});finish(me,'stale');return;}
    const nt=(s.turn+1)%2;
    setS({g,turn:nt,sel:null,win:null});
    if(solo&&nt===1)setTimeout(()=>cpu(g),450);
    return;
   }
  }
  if(g[r][c]===p)setS({...s,sel:[r,c]});
  else setS({...s,sel:null});
 };
 const cpu=(g0:number[][])=>{
  const g=g0.map(row=>[...row]);
  const all:[number,number,number,number][]=[];
  for(let r=0;r<N;r++)for(let c=0;c<N;c++)if(g[r][c]===2)movesFor(g,r,c,2).forEach(([a,b])=>all.push([r,c,a,b]));
  if(!all.length){setS({...s,g,turn:0,sel:null});return;}
  // prefer captures & promotion
  all.sort((x,y)=>((g[y[2]][y[3]]?2:0)+(y[2]===N-1?2:0))-((g[x[2]][x[3]]?2:0)+(x[2]===N-1?2:0)));
  const [sr,sc2,dr,dc]=all[0];
  g[dr][dc]=2;g[sr][sc2]=0;
  if(dr===N-1){setS({g,turn:1,sel:null,win:1});finish(1,'promo');return;}
  if(!g.flat().includes(1)){setS({g,turn:1,sel:null,win:1});finish(1,'cap');return;}
  setS({g,turn:0,sel:null,win:null});
 };
 const opts=useMemo(()=>{if(!s.sel)return new Set<string>();const p=(solo?0:mySlot)+1;return new Set(movesFor(s.g,s.sel[0],s.sel[1],p).map(([a,b])=>a+'-'+b));},[s.sel,s.g]);
 const myTurnNow=solo||s.turn===mySlot;
 const rematch=()=>{done.current=false;setS(init());};
 return (
  <div className="max-w-sm mx-auto">
   <TurnBanner text={(s.win!==null&&s.win!==undefined)?`${names[s.win]} WINS!`:(myTurnNow?'YOUR MOVE':'WAITING…')} color={s.turn===0?'#ff2e63':'#08d9d6'} />
   <div className="text-xs text-center text-slate-400 mb-2">Promote a pawn to the far rank — or capture them all</div>
   <div className="grid rounded-xl overflow-hidden" style={{gridTemplateColumns:`repeat(${N},1fr)`,border:'3px solid #6b5320'}}>
    {s.g.map((row,r)=>row.map((v,c)=>{
     const dark=(r+c)%2===1;const sel=s.sel&&s.sel[0]===r&&s.sel[1]===c;const hl=opts.has(r+'-'+c);
     return <div key={r+'-'+c} onClick={()=>click(r,c)} className="game-grid-cell clickable aspect-square flex items-center justify-center text-2xl" style={{background:sel?'#ffe74c':hl?'rgba(77,255,136,.55)':dark?'#7c5a2e':'#e8c87a'}}>{v===1?'♟️':v===2?'♙':''}</div>;
    }))}
   </div>
   <div className="flex justify-center gap-4 mt-3 text-xs font-bold"><span style={{color:'#ff2e63'}}>♟️ {names[0]}</span><span style={{color:'#08d9d6'}}>♙ {names[1]}</span></div>
   {(s.win!==null&&s.win!==undefined)&&<WinnerOverlay winnerName={names[s.win]} isMe={names[s.win]===(solo?names[0]:players[mySlot]?.name)} scores={[]} gameTitle="Pawn Skirmish" onRematch={rematch} showRematch />}
  </div>
 );
}

export function useBattleshipSeed(){const [x]=useState(0); return x; }
export const __bs = {BS, useBattleshipSeed };
