import {useMemo, useRef, useEffect } from 'react';
import {useSync, TurnBanner, WinnerOverlay } from './shared';
import type {GameProps } from './types';
import {slotName } from './types';

// ---------- REVERSI ----------
export function Reversi(props: GameProps) {
 const {mySlot, players, solo } = props;
 const names = [slotName(players,0,solo), slotName(players,1,solo)];
 const N = 8;
 const start = () => {const g = Array.from({length:N},()=>Array(N).fill(0)); g[3][3]=2;g[3][4]=1;g[4][3]=1;g[4][4]=2; return g; };
 type S = {g: number[][]; turn: number; win: any };
 const init = (): S => ({g: start(), turn: 0, win: null });
 const [s, setS] = useSync(props, 'rev', init);
 const done = useRef(false);
  useEffect(()=>{ try { const _w:any=(s as any)?.win; if(_w===null||_w===undefined) done.current=false; } catch{} }, [s]);
 const dirs = [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]];
 const flips = (g:number[][],r:number,c:number,p:number) => {
  if(g[r][c]) return [];
  const out: [number,number][] = [];
  for(const [dr,dc] of dirs){const line:[number,number][]=[]; let rr=r+dr,cc=c+dc;
   while(rr>=0&&rr<N&&cc>=0&&cc<N&&g[rr][cc]===3-p){line.push([rr,cc]);rr+=dr;cc+=dc;}
   if(line.length&&rr>=0&&rr<N&&cc>=0&&cc<N&&g[rr][cc]===p) out.push(...line);
  }
  return out;
 };
 const moves = (g:number[][],p:number) => {const m:[number,number][]=[]; for(let r=0;r<N;r++)for(let c=0;c<N;c++) if(flips(g,r,c,p).length) m.push([r,c]); return m; };
 const count = (g:number[][]) => [0, g.flat().filter(v=>v===1).length, g.flat().filter(v=>v===2).length];
 const finish = (g:number[][]) => {
  if(done.current) return; done.current=true;
  const [,a,b]=count(g);
  if(a===b) props.onFinish({winnerName:null,winnerIndex:null,scores:{[names[0]]:a,[names[1]]:b}});
  else {const wi=a>b?0:1; props.onFinish({winnerName:names[wi],winnerIndex:solo?(wi===0?0:null):wi,scores:{[names[0]]:a,[names[1]]:b}});}
 };
 if(s.win) setTimeout(()=>finish(s.g),80);
 const move = (r:number,c:number) => {
  if(s.win) return;
  if(!solo && s.turn!==mySlot) return;
  if(solo && s.turn!==0) return;
  const p = s.turn+1;
  const fl = flips(s.g,r,c,p);
  if(!fl.length) return;
  const ng = s.g.map(row=>[...row]); ng[r][c]=p; fl.forEach(([a,b])=>ng[a][b]=p);
  let nt = (s.turn+1)%2;
  let nm = moves(ng,nt+1);
  if(!nm.length){nt=s.turn; nm=moves(ng,nt+1); }
  if(!nm.length){
   const [,a,b]=count(ng); const w = a===b?'draw':(a>b?1:2);
   setS({g:ng,turn:nt,win:w}); finish(ng); return;
  }
  if(solo && nt===1){
   const ms = moves(ng,2);
   if(ms.length){const [ar,ac]=ms[Math.floor(Math.random()*ms.length)]; const f2=flips(ng,ar,ac,2); ng[ar][ac]=2; f2.forEach(([a,b])=>ng[a][b]=2);
    const back = moves(ng,1); let t2=1;
    if(!back.length){const again=moves(ng,2); if(again.length) t2=1; else {const [,x,y]=count(ng); const w=x===y?'draw':(x>y?1:2); setS({g:ng,turn:0,win:w}); finish(ng); return; } }
    else t2=0;
    setS({g:ng,turn:t2,win:null}); return;
   }
  }
  setS({g:ng,turn:nt,win:null});
 };
 const myTurnNow = solo || s.turn===mySlot;
 const valid = useMemo(()=> moves(s.g, (solo?0:s.turn)+1), [s.g, s.turn]);
 const vset = new Set(valid.map(([r,c])=>r*8+c));
 const [,ca,cb] = count(s.g);
 const rematch = () => {done.current=false; setS(init()); };
 return (
  <div className="max-w-md mx-auto">
   <TurnBanner text={s.win ? 'GAME OVER' : (myTurnNow?'YOUR TURN':'OPPONENT\'S TURN')} color={s.turn===0?'#ff2e63':'#08d9d6'} />
   <div className="text-center text-sm mb-2 font-bold"><span style={{color:'#ff2e63'}}>{names[0]}: {ca}</span><span className="mx-3 text-slate-500">·</span><span style={{color:'#08d9d6'}}>{names[1]}: {cb}</span></div>
   <div className="grid gap-1 p-2 rounded-xl" style={{gridTemplateColumns:'repeat(8,1fr)',background:'#0a3d2e',border:'3px solid #14532d'}}>
    {s.g.map((row,r)=>row.map((v,c)=>(
     <div key={r+'-'+c} onClick={()=>move(r,c)} className="game-grid-cell clickable aspect-square rounded flex items-center justify-center" style={{background:'#0f5b40',cursor:myTurnNow?'pointer':'default'}}>
      {v ? <div className="w-4/5 h-4/5 rounded-full" style={{background:v===1?'#1a1a1a':'#f5f5f5',border:'2px solid #000'}}/> : (vset.has(r*8+c)&&myTurnNow ? <div className="w-2 h-2 rounded-full blink" style={{background:'#ffe74c'}}/> : null)}
     </div>
    )))}
   </div>
   {s.win && <WinnerOverlay winnerName={s.win==='draw'?null:names[(s.win as number)-1]} isMe={s.win!=='draw'&&names[(s.win as number)-1]===(solo?names[0]:players[mySlot]?.name)} scores={[[names[0],ca],[names[1],cb]]} gameTitle="Reversi Flip" onRematch={rematch} showRematch />}
  </div>
 );
}

// ---------- GOMOKU (2-3P, 12x12) ----------
export function Gomoku(props: GameProps) {
 const {mySlot, players, solo } = props;
 const n = players.length || 2;
 const names = [0,1,2].slice(0, solo?2:n).map(i=>slotName(players,i,solo));
 const N = 12;
 type S = {g: number[][]; turn: number; win: any };
 const init = (): S => ({g: Array.from({length:N},()=>Array(N).fill(0)), turn: 0, win: null });
 const [s, setS] = useSync(props, 'gom', init);
 const done = useRef(false);
  useEffect(()=>{ try { const _w:any=(s as any)?.win; if(_w===null||_w===undefined) done.current=false; } catch{} }, [s]);
 const colors = ['#ff2e63','#08d9d6','#ffe74c'];
 const check = (g:number[][],r:number,c:number,p:number) => {
  const dd=[[0,1],[1,0],[1,1],[1,-1]];
  for(const [dr,dc] of dd){let k=1;let rr=r+dr,cc=c+dc;while(rr>=0&&rr<N&&cc>=0&&cc<N&&g[rr][cc]===p){k++;rr+=dr;cc+=dc;}rr=r-dr;cc=c-dc;while(rr>=0&&rr<N&&cc>=0&&cc<N&&g[rr][cc]===p){k++;rr-=dr;cc-=dc;}if(k>=5)return true;}
  return false;
 };
 const finish=(w:number)=>{if(done.current)return; done.current=true; const sc:any={}; names.forEach((nm,i)=>sc[nm]=i===w?1:0); props.onFinish({winnerName:names[w],winnerIndex:solo?(w===0?0:null):w,scores:sc}); };
 if(s.win!==null&&s.win!==undefined) setTimeout(()=>finish(s.win),80);
 const move=(r:number,c:number)=>{
  if(s.win!==null&&s.win!==undefined) return;
  if(s.g[r][c]) return;
  const count = solo?2:n;
  if(!solo && s.turn!==mySlot) return;
  if(solo && s.turn!==0) return;
  const ng=s.g.map(row=>[...row]); ng[r][c]=s.turn+1;
  if(check(ng,r,c,s.turn+1)){setS({g:ng,turn:s.turn,win:s.turn}); finish(s.turn); return; }
  if(ng.flat().every(Boolean)){setS({g:ng,turn:s.turn,win:'draw'}); props.onFinish({winnerName:null,winnerIndex:null,scores:{}}); return; }
  let nt=(s.turn+1)%count;
  if(solo&&nt===1){
   const empt:[number,number][]=[]; for(let a=0;a<N;a++)for(let b=0;b<N;b++) if(!ng[a][b]&&(Math.abs(a-r)<3&&Math.abs(b-c)<3)) empt.push([a,b]);
   const pool = empt.length?empt:[[r,c]];
   const [ar,ac]=pool[Math.floor(Math.random()*pool.length)];
   // find first empty near
   let placed=false;
   for(let dr=-2;dr<=2&&!placed;dr++)for(let dc=-2;dc<=2&&!placed;dc++){const nr=r+dr,nc=c+dc;if(nr>=0&&nr<N&&nc>=0&&nc<N&&!ng[nr][nc]){ng[nr][nc]=2;placed=true;if(check(ng,nr,nc,2)){setS({g:ng,turn:1,win:1});finish(1);return;}}}
   nt=0;
  }
  setS({g:ng,turn:nt,win:s.win});
 };
 const myTurnNow = solo || s.turn===mySlot;
 const rematch=()=>{done.current=false;setS(init());};
 return (
  <div className="max-w-lg mx-auto">
   <TurnBanner text={(s.win!==null&&s.win!==undefined&&s.win!=='draw')?`${names[s.win]} WINS!`:(myTurnNow?'YOUR TURN':'WAITING…')} color={colors[s.turn]||'#ffe74c'} />
   <div className="grid gap-[2px] p-2 rounded-xl overflow-auto" style={{gridTemplateColumns:`repeat(${N},minmax(0,1fr))`,background:'#3b2f1e',border:'3px solid #6b5320'}}>
    {s.g.map((row,r)=>row.map((v,c)=>(
     <div key={r+'-'+c} onClick={()=>move(r,c)} className="game-grid-cell clickable aspect-square rounded-[3px] flex items-center justify-center" style={{background:'#d9b06a',cursor:myTurnNow?'pointer':'default',minWidth:18}}>
      {v?<div className="rounded-full" style={{width:'80%',height:'80%',background:colors[v-1],border:'2px solid #000'}}/>:null}
     </div>
    )))}
   </div>
   {((s.win!==null&&s.win!==undefined)||s.win==='draw') && s.win!=='draw' && <WinnerOverlay winnerName={names[s.win]} isMe={names[s.win]===(solo?names[0]:players[mySlot]?.name)} scores={[]} gameTitle="Gomoku Rush" onRematch={rematch} showRematch />}
  </div>
 );
}
