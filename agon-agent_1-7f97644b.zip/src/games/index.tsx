import type { GameProps } from './types';
import type { JSX } from 'react';
import { TicTacToe, Connect4 } from './Board1';
import { Reversi, Gomoku } from './Board2';
import { DotsBoxes, Checkers } from './Board3';
import { Battleship, PawnBattle } from './Board4';
import { SnakeGame, PongGame, BreakoutGame, StackerGame } from './Arcade1';
import { InvadersGame, AsteroidsGame, FroggerGame, FlappyGame } from './Arcade2';
import { RacerGame, TanksGame, BomberGame } from './Arcade3';
import { LunarGame, PacMazeGame, ShooterGame } from './Arcade4';
import { G2048, MinesGame, MemoryGame, SimonGame } from './Puzzle1';
import { FifteenGame, SokobanGame, LightsGame, SnakePuzGame } from './Puzzle2';
import { Hangman, Scramble, TypingGame, Trivia } from './Party1';
import { MathDuel, RPS, DiceDuel, CardWar } from './Party2';
import { Blackjack, Reaction, GuessNum, Bingo } from './Party3';
import { OddEven, TripleTic } from './Party2';
import { Chess, Ludo, SnakesLadders, CoinRush } from './Board5';

export const GAME_COMPONENTS: Record<string, (p: GameProps) => JSX.Element> = {
  tictactoe: TicTacToe, connect4: Connect4, reversi: Reversi, gomoku: Gomoku,
  dots: DotsBoxes, checkers: Checkers, battleship: Battleship, pawnbattle: PawnBattle,
  snake: SnakeGame, pong: PongGame, breakout: BreakoutGame, stacker: StackerGame,
  invaders: InvadersGame, asteroids: AsteroidsGame, frogger: FroggerGame, flappy: FlappyGame,
  racer: RacerGame, tanks: TanksGame, bomber: BomberGame,
  lunar: LunarGame, pacmaze: PacMazeGame, shooter: ShooterGame,
  g2048: G2048, mines: MinesGame, memory: MemoryGame, simon: SimonGame,
  fifteen: FifteenGame, sokoban: SokobanGame, lights: LightsGame, snakepuz: SnakePuzGame,
  hangman: Hangman, scramble: Scramble, typing: TypingGame, trivia: Trivia,
  mathduel: MathDuel, rps: RPS, dice: DiceDuel, war: CardWar,
  blackjack: Blackjack, reaction: Reaction, guessnum: GuessNum, bingo: Bingo,
  odom: OddEven, tictac3: TripleTic,
  chess: Chess, ludo: Ludo, snakesladders: SnakesLadders, coinrush: CoinRush,
};
