import { useEffect, useRef, useState } from 'react';
import { useRace, TurnBanner } from './shared';
import type { GameProps } from './types';

function RaceBar({ live, me, score }: { live: [string, number][]; me: string; score: number }) {
  const rows = live.map(([n, s]) => n.includes('(you)') ? [me + ' (you)', score] as [string, number] : [n, s] as [string, number]);
  if (!rows.filter(([n]) => !n.includes('(you)')).length && rows.length <= 1) return null;
  const sorted = [...rows].sort((a,b)=>b[1]-a[1]);
  const top = sorted[0]?.[1] ?? 0;
  return (<div className="score-strip">{sorted.map(([n,s],i)=>(<span key={i} className={`score-chip ${n.includes('(you)')?'score-chip-me':''} ${s===top&&s>0?'score-chip-lead':''}`}>{i===0?'👑 ':i+1+'. '}{n}: {s}</span>))}</div>);
}
function useCanvas(draw: (ctx:any,t:number)=>void){
  const ref=useRef<HTMLCanvasElement>(null);
  useEffect(()=>{let raf=0;const t0=performance.now();const loop=(t:number)=>{const c=ref.current;if(c){const ctx=c.getContext('2d');if(ctx)draw(ctx,(t-t0)/1000);}raf=requestAnimationFrame(loop);};raf=requestAnimationFrame(loop);return ()=>cancelAnimationFrame(raf);},[]);
  return ref;
}

// -------- LUNAR LANDER --------
export function LunarGame(props: GameProps){
  const {solo,playerName}=props;const{report,finalize,liveList}=useRace(props);
  const[score,setScore]=useState(0);const[started,setStarted]=useState(false);const[over,setOver]=useState(false);const[msg,setMsg]=useState('');const[att,setAtt]=useState(1);
  const S=useRef({x:200,y:30,vx:1.2,vy:0,fuel:100,landed:false,pad:140,keys:{} as any,att:1,best:0});
  useEffect(()=>{
    const d=(e:KeyboardEvent)=>{S.current.keys[e.key.toLowerCase()]=true;if(['arrowup','arrowleft','arrowright',' '].includes(e.key))e.preventDefault();};
    const u=(e:KeyboardEvent)=>{S.current.keys[e.key.toLowerCase()]=false;};
    window.addEventListener('keydown',d);window.addEventListener('keyup',u);
    return ()=>{window.removeEventListener('keydown',d);window.removeEventListener('keyup',u);};
  },[]);
  useEffect(()=>{
    if(!started||over)return;
    const iv=setInterval(()=>{
      const s=S.current;const k=s.keys;
      s.vy+=0.045;
      if((k['arrowup']||k['w']||k[' '])&&s.fuel>0){s.vy-=0.11;s.fuel-=0.5;}
      if((k['arrowleft']||k['a'])&&s.fuel>0){s.vx-=0.06;s.fuel-=0.3;}
      if((k['arrowright']||k['d'])&&s.fuel>0){s.vx+=0.06;s.fuel-=0.3;}
      s.x+=s.vx;s.y+=s.vy;
      if(s.x<10){s.x=10;s.vx=0;}if(s.x>390){s.x=390;s.vx=0;}
      if(s.y>=262){
        s.y=262;
        const onPad=s.x>s.pad&&s.x<s.pad+90;
        const soft=Math.abs(s.vy)<1.15&&Math.abs(s.vx)<0.9;
        if(onPad&&soft){
          const pts=Math.round(200-s.vy*40-Math.abs(s.vx)*30+s.fuel);
          s.best=Math.max(s.best,pts);setScore(s.best);report(s.best);setMsg(`TOUCHDOWN +${pts}!`);
          s.x=200;s.y=30;s.vx=(Math.random()-.5)*2;s.vy=0;s.fuel=100;s.att++;setAtt(s.att);
          if(s.att>3){setOver(true);clearInterval(iv);}
        } else { setMsg(!onPad?'MISSED THE PAD!':'TOO FAST — CRASH!'); setOver(true); clearInterval(iv); }
      }
      if(s.fuel<=0&&s.y<200){/* falling */}
    },20);
    return ()=>clearInterval(iv);
  },[started,over]);
  const ref=useCanvas((ctx)=>{
    ctx.fillStyle='#070714';ctx.fillRect(0,0,400,300);
    ctx.fillStyle='#fff';for(let i=0;i<60;i++){const x=(i*67)%400,y=(i*41)%220;ctx.fillRect(x,y,1.5,1.5);}
    const s=S.current;
    ctx.fillStyle='#3b3b5e';ctx.fillRect(0,270,400,30);
    ctx.fillStyle='#4dff88';ctx.fillRect(s.pad,264,90,6);
    ctx.save();ctx.translate(s.x,s.y);ctx.fillStyle='#c9c9e3';ctx.fillRect(-10,-8,20,14);ctx.fillStyle='#ff2e63';ctx.fillRect(-4,6,8,6);
    const k=s.keys;if(k['arrowup']||k['w']||k[' ']){ctx.fillStyle='#ff9f1c';ctx.beginPath();ctx.moveTo(-6,12);ctx.lineTo(6,12);ctx.lineTo(0,24);ctx.fill();}
    ctx.restore();
  });
  return (<div className="max-w-md mx-auto text-center">
    <TurnBanner text={over?`${msg} · BEST ${score}`:`TRY ${att}/3 · FUEL ${Math.max(0,Math.round(S.current.fuel))}`} color="#38bdf8" />
    {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
    <div className="text-xs text-slate-400 mb-2">↑ thrust · ← → tilt · land soft on green pad, 3 tries</div>
    <div className="cabinet"><canvas ref={ref} width={400} height={300} className="cabinet-canvas" /></div>
    <div className="flex gap-2 justify-center mt-3">
      {!started?<button className="pixel-btn" onClick={()=>{S.current={x:200,y:30,vx:1.2,vy:0,fuel:100,landed:false,pad:60+Math.random()*250,keys:{},att:1,best:0};setScore(0);setAtt(1);setMsg('');setOver(false);setStarted(true);}}>▶ Descend</button>
      :over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:score>0?playerName:null,winnerIndex:score>0?0:null,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>
      :<span className="text-xs text-slate-500">Ease her down…</span>}
    </div></div>);
}

// -------- PELLET MAZE --------
export function PacMazeGame(props: GameProps){
  const {solo,playerName}=props;const{report,finalize,liveList}=useRace(props);
  const[score,setScore]=useState(0);const[started,setStarted]=useState(false);const[over,setOver]=useState(false);
  const MW=15,MH=11;
  const maze=[
    '###############','#.............#','#.###.#####.#.','#.#...#...#.#.','#.#.###.#.#.#.','#.....#.....#.','#.###.#.###.#.','#.#...#...#.#.','#.#####.###.#.','#.............#','###############',
  ];
  const S=useRef({px:1,py:1,dir:{x:1,y:0},nd:{x:1,y:0},ghosts:[{x:13,y:9,c:'#ff2e63',t:0},{x:1,y:9,c:'#08d9d6',t:0}],dots:new Set<string>(),pts:0,lv:3,t:0});
  useEffect(()=>{
    const h=(e:KeyboardEvent)=>{const s=S.current;if(e.key==='ArrowUp'||e.key==='w')s.nd={x:0,y:-1};if(e.key==='ArrowDown'||e.key==='s')s.nd={x:0,y:1};if(e.key==='ArrowLeft'||e.key==='a')s.nd={x:-1,y:0};if(e.key==='ArrowRight'||e.key==='d')s.nd={x:1,y:0};};
    window.addEventListener('keydown',h);return ()=>window.removeEventListener('keydown',h);
  },[]);
  const open=(x:number,y:number)=>maze[y]&&maze[y][x]==='.';
  useEffect(()=>{
    if(!started||over)return;
    const s=S.current;
    if(!s.dots.size)for(let y=0;y<MH;y++)for(let x=0;x<MW;x++)if(maze[y][x]==='.')s.dots.add(x+','+y);
    const iv=setInterval(()=>{
      s.t++;
      if(open(s.px+s.nd.x,s.py+s.nd.y))s.dir={...s.nd};
      if(open(s.px+s.dir.x,s.py+s.dir.y)){s.px+=s.dir.x;s.py+=s.dir.y;}
      const k=s.px+','+s.py;
      if(s.dots.has(k)){s.dots.delete(k);s.pts+=10;setScore(s.pts);report(s.pts);}
      if(!s.dots.size){setOver(true);clearInterval(iv);return;}
      s.ghosts.forEach((g,gi)=>{
        if(s.t%2===0){
          const opts=[{x:1,y:0},{x:-1,y:0},{x:0,y:1},{x:0,y:-1}].filter(o=>open(g.x+o.x,g.y+o.y));
          if(opts.length){
            // chase with randomness
            opts.sort((a,b)=>{const da=Math.abs(g.x+a.x-s.px)+Math.abs(g.y+a.y-s.py);const db=Math.abs(g.x+b.x-s.px)+Math.abs(g.y+b.y-s.py);return da-db;});
            const c=Math.random()<0.7?opts[0]:opts[Math.floor(Math.random()*opts.length)];
            g.x+=c.x;g.y+=c.y;
          }
        }
        if(g.x===s.px&&g.y===s.py){s.lv--;if(s.lv<=0){setOver(true);clearInterval(iv);}else{s.px=1;s.py=1;}}
      });
    },150);
    const to=setTimeout(()=>setOver(true),120000);
    return ()=>{clearInterval(iv);clearTimeout(to);};
  },[started,over]);
  const ref=useCanvas((ctx)=>{
    const s=S.current;const cw=400/MW,ch=286/MH;
    ctx.fillStyle='#070714';ctx.fillRect(0,0,400,286);
    for(let y=0;y<MH;y++)for(let x=0;x<MW;x++){if(maze[y][x]==='#'){ctx.fillStyle='#1e2a8a';ctx.fillRect(x*cw,y*ch,cw,ch);}else if(s.dots.has(x+','+y)){ctx.fillStyle='#ffe74c';ctx.fillRect(x*cw+cw/2-2,y*ch+ch/2-2,4,4);}}
    ctx.fillStyle='#ffe74c';ctx.beginPath();ctx.arc(s.px*cw+cw/2,s.py*ch+ch/2,Math.min(cw,ch)/2.4,0.3,Math.PI*2-0.3);ctx.lineTo(s.px*cw+cw/2,s.py*ch+ch/2);ctx.fill();
    s.ghosts.forEach(g=>{ctx.fillStyle=g.c;ctx.beginPath();ctx.arc(g.x*cw+cw/2,g.y*ch+ch/2-2,Math.min(cw,ch)/2.5,Math.PI,0);ctx.fill();ctx.fillRect(g.x*cw+2,g.y*ch+ch/2-2,cw-4,ch/2);});
  });
  return (<div className="max-w-md mx-auto text-center">
    <TurnBanner text={over?`MAZE DONE · ${score}`:`${score} PTS · ❤ ${S.current.lv}`} color="#ffe74c" />
    {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
    <div className="text-xs text-slate-400 mb-2">Arrows/WASD · eat every pellet, dodge 2 ghosts</div>
    <div className="cabinet"><canvas ref={ref} width={400} height={286} className="cabinet-canvas" /></div>
    <div className="flex gap-2 justify-center mt-3">
      {!started?<button className="pixel-btn" onClick={()=>{S.current={px:1,py:1,dir:{x:1,y:0},nd:{x:1,y:0},ghosts:[{x:13,y:9,c:'#ff2e63',t:0},{x:1,y:9,c:'#08d9d6',t:0}],dots:new Set(),pts:0,lv:3,t:0};setScore(0);setOver(false);setStarted(true);}}>▶ Gobble!</button>
      :over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:playerName,winnerIndex:0,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>
      :<button className="pixel-btn pixel-btn-ghost" onClick={()=>setOver(true)}>End run</button>}
    </div></div>);
}

// -------- STAR SHOOTER --------
export function ShooterGame(props: GameProps){
  const {solo,playerName}=props;const{report,finalize,liveList}=useRace(props);
  const[score,setScore]=useState(0);const[lives,setLives]=useState(3);const[started,setStarted]=useState(false);const[over,setOver]=useState(false);
  const S=useRef({px:200,b:[] as any[],foes:[] as any[],eb:[] as any[],pts:0,lv:3,t:0,cd:0,keys:{} as any,stars:[] as any[]});
  useEffect(()=>{
    const d=(e:KeyboardEvent)=>{S.current.keys[e.key.toLowerCase()]=true;if(e.key===' ')e.preventDefault();};
    const u=(e:KeyboardEvent)=>{S.current.keys[e.key.toLowerCase()]=false;};
    window.addEventListener('keydown',d);window.addEventListener('keyup',u);
    return ()=>{window.removeEventListener('keydown',d);window.removeEventListener('keyup',u);};
  },[]);
  useEffect(()=>{
    if(!started||over)return;
    for(let i=0;i<50;i++)S.current.stars.push({x:Math.random()*400,y:Math.random()*300,sp:1+Math.random()*3});
    const iv=setInterval(()=>{
      const s=S.current;s.t++;s.cd=Math.max(0,s.cd-1);
      const k=s.keys;
      if(k['arrowleft']||k['a'])s.px=Math.max(16,s.px-6);
      if(k['arrowright']||k['d'])s.px=Math.min(384,s.px+6);
      if((k[' ']||k['arrowup']||k['w'])&&s.cd<=0){s.b.push({x:s.px,y:246});s.cd=9;}
      s.stars.forEach(st=>{st.y=(st.y+st.sp)%300;});
      if(s.t%26===0)s.foes.push({x:30+Math.random()*340,y:-20,vy:1.2+Math.random()*1.4,hp:1+Math.floor(s.t/600)});
      s.foes.forEach(f=>{f.y+=f.vy;if(Math.random()<0.008)f.eb={};});
      if(Math.random()<0.03&&s.foes.length)s.eb.push({x:s.foes[Math.floor(Math.random()*s.foes.length)].x,y:20});
      s.foes=s.foes.filter(f=>f.y<320);
      s.b.forEach(b=>b.y-=8);s.b=s.b.filter(b=>b.y>-10);
      s.eb.forEach(b=>b.y+=3.6);s.eb=s.eb.filter(b=>b.y<310);
      for(const b of s.b)for(const f of s.foes){if(f.hp>0&&Math.abs(b.x-f.x)<16&&Math.abs(b.y-f.y)<14){f.hp--;b.y=-99;if(f.hp<=0){s.pts+=25;setScore(s.pts);report(s.pts);}break;}}
      s.foes=s.foes.filter(f=>f.hp>0);
      if(s.eb.some(b=>Math.abs(b.x-s.px)<13&&Math.abs(b.y-258)<13)||s.foes.some(f=>Math.abs(f.x-s.px)<16&&Math.abs(f.y-258)<16)){
        s.lv--;setLives(s.lv);s.eb=[];s.foes=s.foes.filter(f=>f.y<200);
        if(s.lv<=0){setOver(true);clearInterval(iv);return;}
      }
    },20);
    const to=setTimeout(()=>setOver(true),90000);
    return ()=>{clearInterval(iv);clearTimeout(to);};
  },[started,over]);
  const ref=useCanvas((ctx)=>{
    ctx.fillStyle='#070714';ctx.fillRect(0,0,400,300);
    const s=S.current;
    ctx.fillStyle='#fff';s.stars.forEach(st=>ctx.fillRect(st.x,st.y,1.6,1.6));
    s.foes.forEach(f=>{ctx.fillStyle='#a06bff';ctx.fillRect(f.x-13,f.y-10,26,20);ctx.fillStyle='#ff2e63';ctx.fillRect(f.x-4,f.y+8,8,6);});
    ctx.fillStyle='#08d9d6';ctx.fillRect(s.px-12,250,24,14);ctx.fillStyle='#08d9d6';ctx.fillRect(s.px-3,240,6,12);
    ctx.fillStyle='#ffe74c';s.b.forEach(b=>ctx.fillRect(b.x-1.5,b.y,3,10));
    ctx.fillStyle='#ff2e63';s.eb.forEach(b=>{ctx.beginPath();ctx.arc(b.x,b.y,3,0,7);ctx.fill();});
  });
  return (<div className="max-w-md mx-auto text-center">
    <TurnBanner text={over?`MISSION END · ${score}`:`${score} PTS · ❤ ${lives}`} color="#a06bff" />
    {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
    <div className="text-xs text-slate-400 mb-2">← → move · SPACE fire · survive the swarm</div>
    <div className="cabinet"><canvas ref={ref} width={400} height={300} className="cabinet-canvas" onMouseMove={(e)=>{const r=(e.target as any).getBoundingClientRect();S.current.px=Math.max(16,Math.min(384,(e.clientX-r.left)/r.width*400));}} onClick={()=>{const s=S.current;if(s.cd<=0){s.b.push({x:s.px,y:246});s.cd=9;}}} /></div>
    <div className="flex gap-2 justify-center mt-3">
      {!started?<button className="pixel-btn" onClick={()=>{S.current={px:200,b:[],foes:[],eb:[],pts:0,lv:3,t:0,cd:0,keys:{},stars:[]};setScore(0);setLives(3);setOver(false);setStarted(true);}}>▶ Scramble!</button>
      :over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:playerName,winnerIndex:0,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>
      :<button className="pixel-btn pixel-btn-ghost" onClick={()=>setOver(true)}>End run</button>}
    </div></div>);
}
