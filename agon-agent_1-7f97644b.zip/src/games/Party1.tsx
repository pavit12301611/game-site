import { useEffect, useMemo, useRef, useState } from 'react';
import { useSync, useRace, TurnBanner, WinnerOverlay } from './shared';
import type { GameProps } from './types';
import { slotName } from './types';
import { hashStr, mulberry32 } from '../lib/rand';

function RaceBar({ live, me, score }: { live: [string, number][]; me: string; score: number }) {
  const rows = live.map(([n, s]) => n.includes('(you)') ? [me + ' (you)', score] as [string, number] : [n, s] as [string, number]);
  if (!rows.filter(([n]) => !n.includes('(you)')).length && rows.length <= 1) return null;
  const sorted = [...rows].sort((a,b)=>b[1]-a[1]);
  const top = sorted[0]?.[1] ?? 0;
  return (<div className="score-strip">{sorted.map(([n,s],i)=>(<span key={i} className={`score-chip ${n.includes('(you)')?'score-chip-me':''} ${s===top&&s>0?'score-chip-lead':''}`}>{i===0?'👑 ':i+1+'. '}{n}: {s}</span>))}</div>);
}
function rngFor(seed: string) { return mulberry32(hashStr(seed)); }

const WORDS = ['PIXEL','ARCADE','JOYSTICK','RETRO','PACMAN','TETRIS','CONSOLE','SPRITE','BOSS','LEVELUP','GAMEPAD','NEON','VECTOR','DUNGEON','QUEST','MARIO','ZELDA','SONIC','KIRBY','METROID','CASTLE','DRAGON','WIZARD','ROBOT','ALIEN','NINJA','PIRATE','SAMURAI','TURBO','COMBO','BONUS','PLAYER','SCORE','WINNER','GALAXY','COSMOS','LASER','PLASMA','CYBER','PIXELART','BUTTON','SCREEN','CABINET','TOKENS','HIGHSCORE','MULTIPLAYER','SPEEDRUN','GLITCH','POWERUP','CHECKPOINT'];

// ============ HANGMAN (shared word race) ============
export function Hangman(props: GameProps){
  const {solo,playerName,players,mySlot}=props;const{report,finalize,liveList}=useRace(props);
  const seed=props.room?.code||'solo-hang';
  const word=useMemo(()=>{const r=rngFor('hm'+seed);return WORDS[Math.floor(r()*WORDS.length)];},[seed]);
  const[guessed,setGuessed]=useState<string[]>([]);const[wrong,setWrong]=useState(0);const[over,setOver]=useState(false);const[won,setWon]=useState(false);
  const MAXW=6;
  const solved=word.split('').every(ch=>guessed.includes(ch));
  const score=won?Math.max(100,1000-wrong*80-guessed.length*10):guessed.filter(g=>word.includes(g)).length*20;
  useEffect(()=>{if(solved&&!over){setOver(true);setWon(true);report(Math.max(100,1000-wrong*80-guessed.length*10));}},[solved]);
  useEffect(()=>{if(wrong>=MAXW&&!over){setOver(true);setWon(false);report(guessed.filter(g=>word.includes(g)).length*20);}},[wrong]);
  const guess=(ch:string)=>{
    if(over||guessed.includes(ch))return;
    const ng=[...guessed,ch];setGuessed(ng);
    if(!word.includes(ch)){const w=wrong+1;setWrong(w);report(ng.filter(g=>word.includes(g)).length*15);}
    else report(ng.filter(g=>word.includes(g)).length*25);
  };
  const names=players.length?players.map(p=>p.name):[playerName];
  return (<div className="max-w-md mx-auto text-center">
    <TurnBanner text={over?(won?`SOLVED · ${score}`:`HANGED · ${word}`):`${MAXW-wrong} TRIES LEFT`} color="#ff2e63" />
    {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
    <div className="text-xs text-slate-400 mb-2">Same secret word for the whole room · fewest misses wins</div>
    <div className="pixel-panel p-4 mb-3">
      <div className="font-mono text-4xl mb-1">{['＿','🙂','😐','😟','😫','💀','☠️'][wrong]}</div>
      <div className="font-pixel text-xl tracking-[0.3em] my-3" style={{color:'#ffe74c'}}>{word.split('').map(ch=>guessed.includes(ch)?ch:'_').join(' ')}</div>
      <div className="text-xs text-slate-400">wrong: {guessed.filter(g=>!word.includes(g)).join(', ')||'—'}</div>
    </div>
    <div className="grid grid-cols-7 gap-1.5">
      {'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map(ch=>{
        const used=guessed.includes(ch);
        return <button key={ch} disabled={used||over} onClick={()=>guess(ch)} className="aspect-square rounded-lg font-pixel text-xs"
          style={{background:used?(word.includes(ch)?'#1f9d55':'#3a1030'):'#2b2b5e',color:used?'#fff':'#ffe74c',border:'2px solid #000',opacity:used?0.7:1}}>{ch}</button>;})}
    </div>
    {over&&<div className="mt-4"><button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:won?playerName:null,winnerIndex:won?0:null,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button></div>}
  </div>);
}

// ============ WORD SCRAMBLE (5 words race) ============
export function Scramble(props: GameProps){
  const {solo,playerName}=props;const{report,finalize,liveList}=useRace(props);
  const seed=props.room?.code||'solo-scr';
  const words=useMemo(()=>{const r=rngFor('sc'+seed);const pool=[...WORDS];const out:string[]=[];for(let i=0;i<5;i++)out.push(pool.splice(Math.floor(r()*pool.length),1)[0]);return out;},[seed]);
  const[wi,setWi]=useState(0);const[input,setInput]=useState('');const[score,setScore]=useState(0);const[sec,setSec]=useState(0);const[over,setOver]=useState(false);const[started,setStarted]=useState(false);const[hint,setHint]=useState(false);
  const scrambled=useMemo(()=>words.map(w=>{const a=w.split('');for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a.join('');}),[words]);
  useEffect(()=>{if(!started||over)return;const iv=setInterval(()=>setSec(s=>s+1),1000);return ()=>clearInterval(iv);},[started,over]);
  const submit=()=>{
    if(!started||over)return;
    if(input.trim().toUpperCase()===words[wi]){
      const pts=100+(hint?0:25)+Math.max(0,40-sec);
      const ns=score+pts;setScore(ns);report(ns);
      if(wi>=4){setOver(true);}else{setWi(wi+1);setInput('');setHint(false);}
    } else { setScore(s=>{report(Math.max(0,s-5));return Math.max(0,s-5);}); }
  };
  return (<div className="max-w-sm mx-auto text-center">
    <TurnBanner text={over?`DONE · ${score}`:`WORD ${wi+1}/5 · ${score} PTS`} color="#08d9d6" />
    {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
    <div className="text-xs text-slate-400 mb-2">Same 5 words for everyone · fastest + most accurate wins</div>
    {!started?<button className="pixel-btn" onClick={()=>setStarted(true)}>▶ Start unscrambling</button>:(
    <>
      <div className="pixel-panel p-6 mb-3">
        <div className="font-pixel text-2xl tracking-widest" style={{color:'#08d9d6'}}>{scrambled[wi]}</div>
        <div className="text-xs text-slate-500 mt-2">{words[wi].length} letters {hint&&`· starts with ${words[wi][0]}`}</div>
      </div>
      <div className="flex gap-2">
        <input className="pixel-input font-pixel text-sm uppercase" value={input} onChange={e=>setInput(e.target.value.toUpperCase())} onKeyDown={e=>{if(e.key==='Enter')submit();}} placeholder="YOUR GUESS" maxLength={12} />
        <button className="pixel-btn" onClick={submit}>Go</button>
      </div>
      <div className="flex gap-2 justify-center mt-3">
        {!hint?<button className="text-xs text-slate-400 underline" onClick={()=>setHint(true)}>reveal first letter (−25)</button>:null}
        {over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:playerName,winnerIndex:0,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save':'🏁 Submit & reveal'}</button>:<span className="text-xs text-slate-500">{sec}s</span>}
      </div>
    </>)}
  </div>);
}

// ============ TYPING THUNDER ============
const PASSAGES=['THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG WHILE PIXELS DANCE ON THE SCREEN','RETRO ARCADE NIGHTS NEVER END WHEN FRIENDS COMPETE FOR THE HIGH SCORE','PRESS START TO JOIN THE ULTIMATE PIXEL PARTY WITH FRIENDS ONLINE','GHOSTS CHASE PAC DOTS THROUGH NEON MAZES AT MIDNIGHT','EVERY BOSS FIGHT TEACHES PATIENCE TIMING AND COURAGE'];
export function TypingGame(props: GameProps){
  const {solo,playerName}=props;const{report,finalize,liveList}=useRace(props);
  const seed=props.room?.code||'solo-type';
  const text=useMemo(()=>{const r=rngFor('ty'+seed);return PASSAGES[Math.floor(r()*PASSAGES.length)];},[seed]);
  const[input,setInput]=useState('');const[started,setStarted]=useState(false);const[over,setOver]=useState(false);const[t0,setT0]=useState(0);const[wpm,setWpm]=useState(0);
  const done=input.length>=text.length;
  useEffect(()=>{if(started&&!over&&input.length>0){const el=(Date.now()-t0)/60000;const w=(input.length/5)/Math.max(0.01,el);setWpm(Math.round(w));report(Math.round(w));}},[input]);
  useEffect(()=>{if(done&&!over){setOver(true);report(Math.round(wpm));}},[done]);
  const score=Math.round(wpm);
  const acc=input.split('').filter((ch,i)=>ch===text[i]).length;
  return (<div className="max-w-lg mx-auto text-center">
    <TurnBanner text={over?`${score} WPM!`:`${score} WPM · ${Math.round(input.length/Math.max(1,text.length)*100)}%`} color="#ffe74c" />
    {!solo&&<RaceBar live={liveList} me={playerName} score={score} />}
    <div className="text-xs text-slate-400 mb-2">Same passage for the room · highest WPM wins</div>
    <div className="pixel-panel p-5 mb-3 text-left font-mono text-lg leading-8">
      {text.split('').map((ch,i)=>{
        const typed=input[i];
        return <span key={i} style={{background:typed?(typed===ch?'rgba(77,255,136,.35)':'rgba(255,46,99,.45)'):(i===input.length?'rgba(255,231,76,.35)':'transparent'),color:typed?(typed===ch?'#4dff88':'#ff2e63'):'#c9c9e3'}}>{ch}</span>;})}
    </div>
    {!started?<button className="pixel-btn" onClick={()=>{setStarted(true);setT0(Date.now());}}>▶ Start typing</button>:(
      over?<button className="pixel-btn pixel-btn-cyan" onClick={()=>{solo?props.onFinish({winnerName:playerName,winnerIndex:0,scores:{[playerName]:score}}):finalize(score);}}>{solo?'🏁 Save score':'🏁 Submit & reveal winner'}</button>:
      <textarea className="pixel-input font-mono" rows={2} value={input} autoFocus onChange={e=>setInput(e.target.value.toUpperCase().slice(0,text.length))} placeholder="TYPE HERE…" />
    )}
    {started&&!over&&<div className="text-xs text-slate-500 mt-2">accuracy {input.length?Math.round(acc/input.length*100):100}%</div>}
  </div>);
}

// ============ TRIVIA CLASH (turn-based, shared questions) ============
const TRIVIA:[string,string[],number][]=[
  ['Which game features a yellow dot-muncher?', ['Pac-Man','Frogger','Q*bert','Dig Dug'],0],
  ['How many ghosts chase you in Pac-Man?', ['3','4','5','6'],1],
  ['Which console launched with Super Mario 64?', ['SNES','N64','GameCube','Wii'],1],
  ['What does the Konami Code start with?', ['Up Up','Left Right','A B','Start Select'],0],
  ['Tetris blocks are also called?', ['Tetrominoes','Bloxels','Quads','Bricks'],0],
  ['Which company made Sonic?', ['Nintendo','Sega','Atari','Capcom'],1],
  ['Pong was released in which year?', ['1969','1972','1978','1981'],1],
  ['What color is the threatened ghost in Pac-Man?', ['Red','Pink','Blue','Orange'],2],
  ['Minecraft was created by?', ['Notch','Mojang AB itself','Steam','Epic'],0],
  ['Which game has the Triforce?', ['Final Fantasy','Zelda','Metroid','Kirby'],1],
  ['Space Invaders came from which country?', ['USA','Japan','UK','Germany'],1],
  ['How many buttons on an NES controller?', ['2 action + start/select','4 action','6 action','1 action'],0],
];
export function Trivia(props: GameProps){
  const {mySlot,players,solo}=props;
  const n=solo?2:(players.length||2);
  const names=[0,1,2].slice(0,n).map(i=>slotName(players,i,solo));
  const seed=props.room?.code||'solo-triv';
  const qs=useMemo(()=>{const r=rngFor('tv'+seed);const pool=[...TRIVIA];const out:typeof TRIVIA=[];for(let i=0;i<8;i++)out.push(pool.splice(Math.floor(r()*pool.length),1)[0]);return out;},[seed]);
  type S={qi:number;turn:number;scores:number[];picked:number|null;win:any};
  const init=():S=>({qi:0,turn:0,scores:names.map(()=>0),picked:null,win:null});
  const[s,setS]=useSync(props,'triv',init);
  const done=useRef(false);
  const cols=['#ff2e63','#08d9d6','#ffe74c'];
  const finish=()=>{if(done.current)return;done.current=true;const sc:any={};names.forEach((nm,i)=>sc[nm]=s.scores[i]);let wi=0;s.scores.forEach((p,i)=>{if(p>s.scores[wi])wi=i;});const tie=s.scores.filter(p=>p===s.scores[wi]).length>1;props.onFinish({winnerName:tie?null:names[wi],winnerIndex:tie?null:(solo?(wi===0?0:null):wi),scores:sc});};
  if(s.qi>=8)setTimeout(()=>{if(!done.current)finish();},150);
  const answer=(ai:number)=>{
    if(s.qi>=8||s.picked!==null)return;
    const me=solo?0:mySlot;
    if(s.turn!==me)return;
    const correct=ai===qs[s.qi][2];
    const scores=[...s.scores];if(correct)scores[s.turn]+=100;
    setS({...s,picked:ai,scores});
    setTimeout(()=>{
      if(solo){
        // cpu answers next question worth half the time
        const nqi=s.qi+1;
        if(nqi>=8){setS({qi:nqi,turn:0,scores,picked:null,win:true});finish();}
        else{
          const cpuScores=[...scores];
          // cpu 55% correct
          const [,,ci]=qs[nqi];
          if(Math.random()<0.55)cpuScores[1]+=100;
          setS({qi:nqi+1,turn:0,scores:cpuScores,picked:null,win:null});
          if(nqi+1>=8)finish();
        }
      } else {
        const nqi=s.qi+1;
        const nt=(s.turn+1)%n;
        if(nqi>=8){setS({qi:nqi,turn:nt,scores,picked:null,win:true});finish();}
        else setS({qi:nqi,turn:nt,scores,picked:null,win:null});
      }
    },1100);
  };
  const myTurn=solo||s.turn===mySlot;
  const q=qs[Math.min(s.qi,7)];
  const isDone=s.qi>=8;
  const rematch=()=>{done.current=false;setS(init());};
  return (<div className="max-w-md mx-auto">
    <TurnBanner text={isDone?'FINAL SCORES':(myTurn?`YOUR TURN · Q${s.qi+1}/8`:`${names[s.turn]} THINKS… · Q${s.qi+1}/8`)} color={cols[s.turn]} />
    <div className="flex gap-3 justify-center text-xs font-bold mb-3">{names.map((nm,i)=><span key={i} style={{color:cols[i]}}>{nm}: {s.scores[i]}</span>)}</div>
    {!isDone&&<div className="pixel-panel p-5">
      <div className="text-base font-bold mb-4">{q[0]}</div>
      <div className="grid gap-2">
        {q[1].map((opt,i)=>{
          const showAns=s.picked!==null;
          const isRight=i===q[2];const isPick=i===s.picked;
          return <button key={i} disabled={!myTurn||showAns} onClick={()=>answer(i)} className="text-left px-4 py-3 rounded-xl font-bold text-sm"
            style={{background:showAns?(isRight?'rgba(77,255,136,.25)':isPick?'rgba(255,46,99,.25)':'#0a0a20'):'#0a0a20',border:`2px solid ${showAns?(isRight?'#4dff88':isPick?'#ff2e63':'#3d3d7a'):'#3d3d7a'}`,opacity:!myTurn&&!showAns?0.7:1}}>{'ABCD'[i]}. {opt}</button>;})}
      </div>
    </div>}
    {isDone&&(()=>{let wi=0;s.scores.forEach((p,i)=>{if(p>s.scores[wi])wi=i;});const tie=s.scores.filter(p=>p===s.scores[wi]).length>1;const sc:any={};names.forEach((nm,i)=>sc[nm]=s.scores[i]);
      return <WinnerOverlay winnerName={tie?null:names[wi]} isMe={!tie&&names[wi]===(solo?names[0]:players[mySlot]?.name)} scores={names.map(nm=>[nm,sc[nm]] as [string,number])} gameTitle="Trivia Clash" onRematch={rematch} showRematch />;})()}
  </div>);
}
