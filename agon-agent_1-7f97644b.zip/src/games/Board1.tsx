import {useMemo, useRef, useState, useEffect } from 'react';
import {useSync, TurnBanner, WinnerOverlay } from './shared';
import type {GameProps } from './types';
import {slotName } from './types';

// ---------- TIC TAC TOE ----------
export function TicTacToe(props: GameProps) {
 const {mySlot, players, solo } = props;
 const names = useMemo(() => [slotName(players, 0, solo), slotName(players, 1, solo)], [players, solo]);
 type S = {b: (string | null)[]; turn: number; win: string | null | 'draw' };
 const init = (): S => ({b: Array(9).fill(null), turn: 0, win: null });
 const [s, setS] = useSync(props, 't3', init);
 const done = useRef(false);
  useEffect(()=>{ try { const _w:any=(s as any)?.win; if(_w===null||_w===undefined) done.current=false; } catch{} }, [s]);
 const [marks] = useState(['X', 'O']);
 const check = (b: (string | null)[]) => {
  const L = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  for (const [a,c,d] of L) if (b[a] && b[a]===b[c] && b[a]===b[d]) return b[a];
  return b.every(Boolean) ? 'draw' : null;
 };
 const finish = (w: string | null | 'draw', board: (string|null)[]) => {
  if (done.current || !w) return; done.current = true;
  const xs = board.filter(x=>x==='X').length;
  if (w === 'draw') props.onFinish({winnerName: null, winnerIndex: null, scores: {[names[0]]: xs, [names[1]]: board.filter(x=>x==='O').length } });
  else {const wi = marks.indexOf(w); props.onFinish({winnerName: names[wi], winnerIndex: solo ? (wi===0?0:null) : wi, scores: {[names[0]]: wi===0?1:0, [names[1]]: wi===1?1:0 } }); }
 };
 if (s.win) setTimeout(()=>finish(s.win, s.b), 50);
 const cpuMove = (b: (string|null)[]) => {
  const empt = b.map((v,i)=>v?null:i).filter(v=>v!==null) as number[];
  // try win/block
  for (const i of empt) {const t=[...b]; t[i]='O'; if(check(t)==='O') return i; }
  for (const i of empt) {const t=[...b]; t[i]='X'; if(check(t)==='X') return i; }
  if (b[4]===null) return 4;
  return empt[Math.floor(Math.random()*empt.length)];
 };
 const click = (i: number) => {
  if (s.win || s.b[i]) return;
  if (!solo && s.turn !== mySlot) return;
  if (solo && s.turn !== 0) return;
  const nb = [...s.b]; nb[i] = marks[s.turn];
  let w = check(nb);
  let nt = (s.turn + 1) % 2;
  if (solo && !w && nt === 1) {
   const ci = cpuMove(nb); nb[ci] = 'O'; w = check(nb); nt = 0;
  }
  setS({b: nb, turn: nt, win: w });
  if (w) finish(w, nb);
 };
 const rematch = () => {done.current = false; setS(init()); };
 const myTurnNow = solo || s.turn === mySlot;
 return (
  <div className="max-w-xs mx-auto">
   <TurnBanner text={s.win ? (s.win==='draw' ? 'DRAW!' : `WINNER: ${s.win==='X'?names[0]:names[1]}`) : (myTurnNow ? `YOUR TURN (${marks[solo?0:s.turn]})` : `${names[s.turn]}'S TURN`)} color={myTurnNow ? '#4dff88' : '#ffe74c'} />
   <div className="grid grid-cols-3 gap-2">
    {s.b.map((v, i) => (
     <button key={i} onClick={()=>click(i)} className="game-grid-cell clickable aspect-square rounded-xl font-pixel text-3xl flex items-center justify-center"
      style={{background: v ? (v==='X' ? 'rgba(255,46,99,.18)' : 'rgba(8,217,214,.18)') : '#0d0d24', border: '2px solid #3d3d7a', color: v==='X' ? '#ff2e63' : '#08d9d6', cursor: myTurnNow && !v ? 'pointer' : 'default' }}>
      {v}
     </button>
    ))}
   </div>
   <div className="flex justify-center gap-3 mt-4 text-xs">
    <span style={{color:'#ff2e63'}}>✕ {names[0]}</span><span className="text-slate-500">vs</span><span style={{color:'#08d9d6'}}>◯ {names[1]}</span>
   </div>
   {s.win && <WinnerOverlay winnerName={s.win==='draw'?null:(s.win==='X'?names[0]:names[1])} isMe={s.win!=='draw' && ((s.win==='X'?names[0]:names[1])=== (solo? names[0] : players[mySlot]?.name))} scores={[]} gameTitle="Tic-Tac-Toe Clash" onRematch={rematch} showRematch />}
  </div>
 );
}

// ---------- CONNECT FOUR ----------
export function Connect4(props: GameProps) {
 const {mySlot, players, solo } = props;
 const names = useMemo(() => [slotName(players, 0, solo), slotName(players, 1, solo)], [players, solo]);
 const R = 6, C = 7;
 type S = {g: number[][]; turn: number; win: number | null | 'draw' };
 const init = (): S => ({g: Array.from({length:R},()=>Array(C).fill(0)), turn: 0, win: null });
 const [s, setS] = useSync(props, 'c4', init);
 const done = useRef(false);
  useEffect(()=>{ try { const _w:any=(s as any)?.win; if(_w===null||_w===undefined) done.current=false; } catch{} }, [s]);
 const check = (g: number[][]): number | 'draw' | null => {
  for (let r=0;r<R;r++) for(let c=0;c<C;c++){const v=g[r][c]; if(!v) continue;
   if(c+3<C&&g[r][c+1]===v&&g[r][c+2]===v&&g[r][c+3]===v) return v;
   if(r+3<R&&g[r+1][c]===v&&g[r+2][c]===v&&g[r+3][c]===v) return v;
   if(r+3<R&&c+3<C&&g[r+1][c+1]===v&&g[r+2][c+2]===v&&g[r+3][c+3]===v) return v;
   if(r+3<R&&c-3>=0&&g[r+1][c-1]===v&&g[r+2][c-2]===v&&g[r+3][c-3]===v) return v;
  }
  return g[0].every(v=>v!==0) ? 'draw' : null;
 };
 const finish = (w: any) => {
  if (done.current) return; done.current = true;
  if (w==='draw') props.onFinish({winnerName: null, winnerIndex: null, scores: {[names[0]]: 1, [names[1]]: 1 } });
  else {const wi = (w as number)-1; props.onFinish({winnerName: names[wi], winnerIndex: solo?(wi===0?0:null):wi, scores: {[names[0]]: wi===0?1:0, [names[1]]: wi===1?1:0 } }); }
 };
 if (s.win!==null) setTimeout(()=>finish(s.win), 60);
 const drop = (g: number[][], c: number, p: number) => {
  const ng = g.map(r=>[...r]);
  for (let r=R-1;r>=0;r--) if(!ng[r][c]){ng[r][c]=p; return ng; }
  return null;
 };
 const click = (c: number) => {
  if (s.win!==null) return;
  if (!solo && s.turn!==mySlot) return;
  if (solo && s.turn!==0) return;
  let ng = drop(s.g, c, s.turn+1);
  if (!ng) return;
  let w = check(ng); let nt = (s.turn+1)%2;
  if (solo && w===null && nt===1) {
   const opts = Array.from({length:C},(_,i)=>i).filter(i=>ng![0][i]===0);
   const cc = opts[Math.floor(Math.random()*opts.length)];
   ng = drop(ng, cc, 2)!; w = check(ng); nt = 0;
  }
  setS({g: ng, turn: nt, win: w });
  if (w!==null) finish(w);
 };
 const rematch = () => {done.current=false; setS(init()); };
 const myTurnNow = solo || s.turn===mySlot;
 return (
  <div className="max-w-md mx-auto">
   <TurnBanner text={s.win!==null ? (s.win==='draw'?'DRAW!':`${names[(s.win as number)-1]} WINS!`) : (myTurnNow?'YOUR TURN — DROP!':`${names[s.turn]}'S TURN`)} color={s.turn===0?'#ff2e63':'#08d9d6'} />
   <div className="p-3 rounded-2xl" style={{background: '#0d0d5e', border: '3px solid #2b2b8e' }}>
    <div className="grid gap-1.5" style={{gridTemplateColumns: `repeat(${C},1fr)` }}>
     {Array.from({length:C}).map((_,c)=>(
      <button key={'h'+c} onClick={()=>click(c)} className="text-center font-pixel text-[10px] pb-1" style={{color:'#8b8bd3'}}>▼</button>
     ))}
     {s.g.map((row,r)=>row.map((v,c)=>(
      <div key={r+'-'+c} onClick={()=>click(c)} className="game-grid-cell clickable aspect-square rounded-full flex items-center justify-center"
       style={{background: v===0?'#070718':(v===1?'#ff2e63':'#08d9d6'), border:'2px solid #000', boxShadow: v?`0 0 12px ${v===1?'#ff2e63':'#08d9d6'}`:'inset 0 2px 6px #000' }} />
     )))}
    </div>
   </div>
   {s.win!==null && <WinnerOverlay winnerName={s.win==='draw'?null:names[(s.win as number)-1]} isMe={s.win!=='draw' && names[(s.win as number)-1]===(solo?names[0]:players[mySlot]?.name)} scores={[]} gameTitle="Connect Four" onRematch={rematch} showRematch />}
  </div>
 );
}
