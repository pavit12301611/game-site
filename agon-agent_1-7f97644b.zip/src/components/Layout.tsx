import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Gamepad2, Users, Trophy, Clock, LogOut, Copy, Check, ShieldCheck, Home as HomeIcon } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useState } from 'react';

const TABS = [
  { to: '/', label: 'Arcade', icon: HomeIcon },
  { to: '/friends', label: 'Friends', icon: Users },
  { to: '/ranks', label: 'Ranks', icon: Trophy },
  { to: '/history', label: 'Matches', icon: Clock },
  { to: '/qa', label: 'QA', icon: ShieldCheck },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const { user, playerName, playerId, profile, signOut, nickname, setNickname } = useAuth();
  const [copied, setCopied] = useState(false);
  const [editingNick, setEditingNick] = useState(false);
  const [tmp, setTmp] = useState(nickname);
  const nav = useNavigate();
  const loc = useLocation();
  const invite = `${window.location.origin}/?invite=${playerId}`;
  const copyInvite = async () => {
    try { await navigator.clipboard.writeText(invite); setCopied(true); setTimeout(()=>setCopied(false),1500); } catch {}
  };
  return (
    <div className="min-h-screen crt" style={{ background: 'radial-gradient(1200px 600px at 20% -10%, #2b1b4d 0%, transparent 60%), radial-gradient(1000px 500px at 90% 0%, #0b3d4d 0%, transparent 55%), #070714' }}>
      <header className="sticky top-0 z-40" style={{ background: 'rgba(7,7,20,.85)', backdropFilter: 'blur(10px)', borderBottom: '2px solid #2b2b5e' }}>
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-2 sm:gap-3">
          <Link to="/" className="flex items-center gap-2 no-underline shrink-0" aria-label="Pixel Party home">
            <span className="w-9 h-9 rounded-xl flex items-center justify-center floaty" style={{ background: 'linear-gradient(135deg,#ff2e63,#a06bff)', border: '2px solid #000' }}>
              <Gamepad2 size={20} color="#fff" />
            </span>
            <span className="hidden min-[420px]:block">
              <span className="font-pixel text-[13px] neon-text-pink block leading-none">PIXEL PARTY</span>
              <span className="font-pixel text-[9px] neon-text-cyan block leading-none mt-1">RETRO ARCADE · 48 GAMES</span>
            </span>
          </Link>
          <nav className="hidden md:flex items-center gap-1 ml-6 text-sm" aria-label="Primary">
            {TABS.map((t) => {
              const active = t.to === '/' ? loc.pathname === '/' : loc.pathname.startsWith(t.to);
              const Icon = t.icon;
              return (
                <Link key={t.to} to={t.to} aria-current={active ? 'page' : undefined}
                  className="px-3 py-1.5 rounded-lg text-slate-200 no-underline flex items-center gap-1"
                  style={active ? { background: 'rgba(255,46,99,.16)', border: '1px solid rgba(255,46,99,.5)', color: '#fff' } : undefined}>
                  <Icon size={14}/> {t.label}
                </Link>
              );
            })}
          </nav>
          <div className="flex-1" />
          <div className="hidden sm:flex items-center gap-2 text-xs">
            {editingNick ? (
              <span className="flex items-center gap-1">
                <input className="pixel-input !w-32 !py-1.5 text-xs" value={tmp} maxLength={16} onChange={e=>setTmp(e.target.value)} placeholder="nickname" />
                <button className="pixel-btn !px-2 !py-1.5 !text-[9px]" onClick={()=>{setNickname(tmp.trim()||'Guest');setEditingNick(false);}}>OK</button>
              </span>
            ) : (
              <button onClick={()=>{setTmp(nickname);setEditingNick(true);}} className="px-3 py-1.5 rounded-full font-bold" title="Set guest nickname" style={{ background: '#0a0a20', border: '2px solid #3d3d7a', color: profile?.display_name || playerName }}>
                {profile ? `★ ${profile.display_name||profile.username}` : `👤 ${playerName || 'Guest'}`} <span className="text-slate-500 font-normal">✎</span>
              </button>
            )}
            <button onClick={copyInvite} className="px-3 py-1.5 rounded-full font-bold flex items-center gap-1" style={{ background: '#0a0a20', border: '2px solid #4dff88', color: '#4dff88' }} title="Copy friend-invite link">
              {copied ? <Check size={13}/> : <Copy size={13}/>} {copied ? 'Copied!' : 'Invite'}
            </button>
            {user ? (
              <button onClick={async()=>{await signOut();nav('/');}} className="px-3 py-1.5 rounded-full flex items-center gap-1 text-slate-300" style={{ background: '#1c1c3d', border: '2px solid #3d3d7a' }}><LogOut size={13}/> Out</button>
            ) : (
              <Link to="/login" className="pixel-btn !py-2 !px-3 !text-[10px] no-underline">Sign in</Link>
            )}
          </div>
          <Link to="/login" className="sm:hidden pixel-btn !py-2 !px-3 !text-[10px] no-underline shrink-0">{user ? '★' : 'Join'}</Link>
        </div>
      </header>
      <main className="max-w-6xl mx-auto px-4 pb-28 md:pb-16">{children}</main>
      {/* bottom tab bar — thumb-reachable primary nav on phones */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bottom-tabs" aria-label="Mobile" style={{ background: 'rgba(7,7,20,.92)', backdropFilter: 'blur(12px)', borderTop: '2px solid #2b2b5e', paddingBottom: 'env(safe-area-inset-bottom)' }}>
        <div className="grid grid-cols-5 px-1">
          {TABS.map((t) => {
            const active = t.to === '/' ? loc.pathname === '/' : loc.pathname.startsWith(t.to);
            const Icon = t.icon;
            return (
              <Link key={t.to} to={t.to} aria-current={active ? 'page' : undefined}
                className="flex flex-col items-center gap-0.5 py-2 no-underline"
                style={{ color: active ? '#ff2e63' : '#8b8ba7' }}>
                <Icon size={19} />
                <span className="font-pixel" style={{ fontSize: 7 }}>{t.label.toUpperCase()}</span>
                {active && <span className="w-6 h-0.5 rounded-full" style={{ background: '#ff2e63', boxShadow: '0 0 8px #ff2e63' }} />}
              </Link>
            );
          })}
        </div>
      </nav>
      <footer className="text-center text-xs text-slate-500 pb-8">
        <span className="font-pixel text-[9px]">INSERT COIN · PLAY WITH FRIENDS ANYWHERE · 2026</span>
      </footer>
    </div>
  );
}
