import { useEffect, useRef, useState } from 'react';
import { ChevronUp, ChevronDown, ChevronLeft, ChevronRight, Zap, CornerDownLeft, Gamepad2 } from 'lucide-react';

/** Translates single-finger drags on game canvases into mousemove events,
 *  so mouse-steered games (pong, breakout, racer, shooter, coin rush…) work with touch. */
export function TouchCanvasBridge() {
  useEffect(() => {
    const start = (e: TouchEvent) => {
      const el = e.target as HTMLElement | null;
      if (!el || !(el instanceof HTMLCanvasElement)) return;
      const t = e.touches[0];
      if (!t) return;
      el.dispatchEvent(new MouseEvent('mousemove', { clientX: t.clientX, clientY: t.clientY, bubbles: true, cancelable: true }));
    };
    const move = (e: TouchEvent) => {
      const el = e.target as HTMLElement | null;
      if (!el || !(el instanceof HTMLCanvasElement)) return;
      const t = e.touches[0];
      if (!t) return;
      e.preventDefault();
      el.dispatchEvent(new MouseEvent('mousemove', { clientX: t.clientX, clientY: t.clientY, bubbles: true, cancelable: true }));
    };
    document.addEventListener('touchstart', start, { passive: true });
    document.addEventListener('touchmove', move, { passive: false });
    return () => {
      document.removeEventListener('touchstart', start);
      document.removeEventListener('touchmove', move);
    };
  }, []);
  return null;
}

function Key({ k, children, label }: { k: string; children: React.ReactNode; label: string }) {
  const timer = useRef<any>(null);
  const stop = (e: React.PointerEvent) => {
    e.preventDefault();
    if (timer.current) { clearInterval(timer.current); timer.current = null; }
    window.dispatchEvent(new KeyboardEvent('keyup', { key: k, bubbles: true, cancelable: true }));
  };
  const start = (e: React.PointerEvent) => {
    e.preventDefault();
    try { (e.target as HTMLElement).setPointerCapture(e.pointerId); } catch {}
    window.dispatchEvent(new KeyboardEvent('keydown', { key: k, bubbles: true, cancelable: true }));
    // auto-repeat for hold-to-steer games (racer, tanks, asteroids…)
    if (timer.current) clearInterval(timer.current);
    timer.current = setInterval(() => {
      window.dispatchEvent(new KeyboardEvent('keydown', { key: k, bubbles: true, cancelable: true }));
    }, 70);
  };
  useEffect(() => () => { if (timer.current) clearInterval(timer.current); }, []);
  return (
    <button
      type="button" aria-label={label} title={label}
      className="touch-key"
      onPointerDown={start} onPointerUp={stop} onPointerCancel={stop} onPointerLeave={stop}
      onContextMenu={(e) => e.preventDefault()}
    >
      {children}
    </button>
  );
}

/** On-screen d-pad + action buttons for keyboard-driven games.
 *  Only renders on coarse-pointer (touch) devices via CSS. */
export function MobileKeyPad() {
  const [open, setOpen] = useState(true);
  return (
    <div className="touch-pad">
      <button type="button" className="touch-pad-toggle" onClick={() => setOpen((o) => !o)} aria-expanded={open}>
        <Gamepad2 size={13} /> {open ? 'Hide controls' : 'Show controls'}
      </button>
      {open && (
        <div className="touch-pad-row">
          <div className="touch-dpad">
            <span />
            <Key k="ArrowUp" label="Up"><ChevronUp size={22} /></Key>
            <span />
            <Key k="ArrowLeft" label="Left"><ChevronLeft size={22} /></Key>
            <Key k="ArrowDown" label="Down"><ChevronDown size={22} /></Key>
            <Key k="ArrowRight" label="Right"><ChevronRight size={22} /></Key>
          </div>
          <div className="touch-actions">
            <Key k=" " label="Action (space)"><Zap size={22} /></Key>
            <Key k="Enter" label="Confirm (enter)"><CornerDownLeft size={20} /></Key>
          </div>
        </div>
      )}
      <div className="touch-pad-hint">Tip: drag a finger across paddle games to steer · buttons hold-to-repeat</div>
    </div>
  );
}
