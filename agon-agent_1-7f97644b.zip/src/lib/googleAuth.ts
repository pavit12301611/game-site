import supabase from './supabase';
const isMobile = () => /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
function buildGoogleUrl(appName: string) {
  const clientId = (import.meta as any).env.VITE_GOOGLE_CLIENT_ID as string;
  const redirectUri = (import.meta as any).env.VITE_GOOGLE_AUTH_PROXY as string;
  const supabaseUrl = (import.meta as any).env.VITE_SUPABASE_URL as string;
  const supabaseAnonKey = (import.meta as any).env.VITE_SUPABASE_ANON_KEY as string;
  if (!clientId || !redirectUri) return null;
  const state = btoa(JSON.stringify({ origin: window.location.origin, appName, supabaseUrl, supabaseAnonKey }));
  return `https://accounts.google.com/o/oauth2/v2/auth?client_id=${clientId}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=code&scope=openid%20email%20profile&prompt=select_account&state=${encodeURIComponent(state)}`;
}
export function signInWithGoogle(appName = 'Pixel Party Arcade') {
  const url = buildGoogleUrl(appName);
  if (!url) return;
  window.open(url, 'google-auth', isMobile() ? '' : 'width=500,height=600');
  const handler = async (event: MessageEvent) => {
    if (event.data?.type === 'google-auth-denied') { window.removeEventListener('message', handler); return; }
    if (event.data?.type !== 'google-auth-success') return;
    window.removeEventListener('message', handler);
    if (event.data.access_token && event.data.refresh_token) {
      await supabase.auth.setSession({ access_token: event.data.access_token, refresh_token: event.data.refresh_token });
    } else if (event.data.id_token) {
      await supabase.auth.signInWithIdToken({ provider: 'google', token: event.data.id_token });
    }
  };
  window.addEventListener('message', handler);
}
export async function handleGoogleRedirect() {
  const params = new URLSearchParams(window.location.search);
  const token = params.get('google_id_token');
  if (!token) return;
  window.history.replaceState({}, '', window.location.pathname);
  await supabase.auth.signInWithIdToken({ provider: 'google', token });
  try { (window as any).close(); } catch {}
}
