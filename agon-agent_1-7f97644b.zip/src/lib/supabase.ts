import { createClient } from '@supabase/supabase-js';
const supabase = createClient(
  (import.meta as any).env.VITE_SUPABASE_URL as string,
  (import.meta as any).env.VITE_SUPABASE_ANON_KEY as string
);
export default supabase;
