import {
  Grid3x3, Circle, Layers, Crown, Boxes, Castle, Ship, Swords,
  Worm, Volleyball, Blocks, Rocket, Ghost, Sparkles, Turtle, Bird, Car, Crosshair,
  Bomb, Moon, Footprints, Zap, Puzzle, Bomb as MineIcon, Brain, Bell, Hash,
  Package, Lightbulb, Cable, Type, Dices, Trophy, Calculator, Hand, Coins, Spade, Target, Timer, ClipboardList, LayoutGrid,
  ChessKnight, Route, Gem, CircleDot, Grid2x2
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

export type Category = 'board' | 'arcade' | 'puzzle' | 'party';
export type GameDef = {
  id: string; title: string; desc: string; icon: LucideIcon;
  category: Category; players: string; maxPlayers: 2 | 3;
  hot?: boolean; isNew?: boolean; color: string; turnBased: boolean;
};

export const CATEGORIES: { id: Category; label: string; blurb: string }[] = [
  { id: 'board', label: 'Board Classics', blurb: 'Chess-board duels, reborn online' },
  { id: 'arcade', label: 'Arcade Action', blurb: 'Reflexes, pixels & high scores' },
  { id: 'puzzle', label: 'Puzzle Lab', blurb: 'Out-think your friends' },
  { id: 'party', label: 'Party & Words', blurb: 'Quick rounds, big laughs' },
];

export const GAMES: GameDef[] = [
  // BOARD (8)
  { id: 'tictactoe', title: 'Tic-Tac-Toe Clash', desc: 'Classic 3-in-a-row. First to blink loses.', icon: Grid3x3, category: 'board', players: '2', maxPlayers: 2, hot: true, color: '#ff2e63', turnBased: true },
  { id: 'connect4', title: 'Connect Four', desc: 'Drop discs, link 4 before your rival.', icon: Circle, category: 'board', players: '2', maxPlayers: 2, hot: true, color: '#08d9d6', turnBased: true },
  { id: 'reversi', title: 'Reversi Flip', desc: 'Outflank and flip the whole board.', icon: Layers, category: 'board', players: '2', maxPlayers: 2, color: '#4dff88', turnBased: true },
  { id: 'gomoku', title: 'Gomoku Rush', desc: 'Five in a row on a 12x12 battlefield.', icon: Crown, category: 'board', players: '2-3', maxPlayers: 3, color: '#ffe74c', turnBased: true },
  { id: 'dots', title: 'Dots & Boxes', desc: 'Claim squares, steal the grid.', icon: Boxes, category: 'board', players: '2-3', maxPlayers: 3, color: '#a06bff', turnBased: true },
  { id: 'checkers', title: 'Turbo Checkers', desc: 'Jump, king, and conquer the board.', icon: Castle, category: 'board', players: '2', maxPlayers: 2, color: '#ff9f1c', turnBased: true },
  { id: 'battleship', title: 'Battleship Fog', desc: 'Hidden fleets. Call the shots.', icon: Ship, category: 'board', players: '2', maxPlayers: 2, hot: true, color: '#38bdf8', turnBased: true },
  { id: 'pawnbattle', title: 'Pawn Skirmish', desc: 'Tiny chess: 8 pawns, one winner.', icon: Swords, category: 'board', players: '2', maxPlayers: 2, color: '#f472b6', turnBased: true },
  { id: 'chess', title: 'Grandmaster Chess', desc: 'Full 8×8 chess — every piece, full rules, CPU coach.', icon: ChessKnight, category: 'board', players: '2', maxPlayers: 2, hot: true, isNew: true, color: '#f5f5f5', turnBased: true },
  { id: 'ludo', title: 'Ludo Royale', desc: 'Roll sixes, knock rivals home. 2–3 player classic.', icon: Dices, category: 'board', players: '2-3', maxPlayers: 3, hot: true, isNew: true, color: '#ff2e63', turnBased: true },
  { id: 'snakesladders', title: 'Snakes & Ladders', desc: 'Race to 100 across snakes and ladders.', icon: Route, category: 'board', players: '2-3', maxPlayers: 3, isNew: true, color: '#4dff88', turnBased: true },
  // ARCADE (14)
  { id: 'snake', title: 'Snake Duel', desc: 'Eat orbs, outlive your rival serpent.', icon: Worm, category: 'arcade', players: '1-3', maxPlayers: 3, hot: true, color: '#4dff88', turnBased: false },
  { id: 'pong', title: 'Neon Pong', desc: 'The 1972 legend, now 3-player chaos.', icon: Volleyball, category: 'arcade', players: '1-3', maxPlayers: 3, hot: true, color: '#08d9d6', turnBased: false },
  { id: 'breakout', title: 'Block Breaker', desc: 'Smash every brick. Highest score wins.', icon: Blocks, category: 'arcade', players: '1-3', maxPlayers: 3, color: '#ff9f1c', turnBased: false },
  { id: 'stacker', title: 'Tower Stacker', desc: 'Stack falling blocks to the sky.', icon: Layers, category: 'arcade', players: '1-3', maxPlayers: 3, color: '#a06bff', turnBased: false },
  { id: 'invaders', title: 'Pixel Invaders', desc: 'Hold the line against the swarm.', icon: Rocket, category: 'arcade', players: '1-3', maxPlayers: 3, color: '#ff2e63', turnBased: false },
  { id: 'asteroids', title: 'Asteroid Storm', desc: 'Blast rocks, dodge debris.', icon: Sparkles, category: 'arcade', players: '1-3', maxPlayers: 3, color: '#94a3b8', turnBased: false },
  { id: 'frogger', title: 'Frogger Hop', desc: 'Cross traffic and rivers without a splash.', icon: Turtle, category: 'arcade', players: '1-3', maxPlayers: 3, color: '#4dff88', turnBased: false },
  { id: 'flappy', title: 'Flappy Pixel', desc: 'Thread the pipes. Patience wins.', icon: Bird, category: 'arcade', players: '1-3', maxPlayers: 3, color: '#ffe74c', turnBased: false },
  { id: 'racer', title: 'Midnight Racer', desc: 'Dodge traffic at 200mph.', icon: Car, category: 'arcade', players: '1-3', maxPlayers: 3, color: '#ff2e63', turnBased: false },
  { id: 'tanks', title: 'Tank Battle', desc: 'Maze warfare, last tank standing.', icon: Crosshair, category: 'arcade', players: '2-3', maxPlayers: 3, color: '#4dff88', turnBased: false },
  { id: 'bomber', title: 'Bomber Grid', desc: 'Trap rivals with timed bombs.', icon: Bomb, category: 'arcade', players: '2-3', maxPlayers: 3, hot: true, color: '#ff9f1c', turnBased: false },
  { id: 'lunar', title: 'Lunar Lander', desc: 'Land soft. Fuel is precious.', icon: Moon, category: 'arcade', players: '1-3', maxPlayers: 3, color: '#38bdf8', turnBased: false },
  { id: 'pacmaze', title: 'Pellet Maze', desc: 'Gobble pellets, dodge ghosts.', icon: Footprints, category: 'arcade', players: '1-3', maxPlayers: 3, color: '#ffe74c', turnBased: false },
  { id: 'shooter', title: 'Star Shooter', desc: 'Vertical space shooter. Survive.', icon: Zap, category: 'arcade', players: '1-3', maxPlayers: 3, color: '#a06bff', turnBased: false },
  { id: 'coinrush', title: 'Coin Rush', desc: 'Catch falling coins, dodge bombs. 45s frenzy.', icon: Gem, category: 'arcade', players: '1-3', maxPlayers: 3, isNew: true, color: '#ffe74c', turnBased: false },
  // PUZZLE (8)
  { id: 'g2048', title: '2048 Race', desc: 'Slide tiles, chase 2048 first.', icon: Puzzle, category: 'puzzle', players: '1-3', maxPlayers: 3, hot: true, color: '#ffe74c', turnBased: false },
  { id: 'mines', title: 'Minesweeper Sprint', desc: 'Flag mines, clear the field fastest.', icon: MineIcon, category: 'puzzle', players: '1-3', maxPlayers: 3, color: '#ff9f1c', turnBased: false },
  { id: 'memory', title: 'Memory Match', desc: 'Flip pairs. Best memory wins.', icon: Brain, category: 'puzzle', players: '2-3', maxPlayers: 3, color: '#f472b6', turnBased: true },
  { id: 'simon', title: 'Simon Signals', desc: 'Repeat the glowing sequence.', icon: Bell, category: 'puzzle', players: '1-3', maxPlayers: 3, color: '#08d9d6', turnBased: false },
  { id: 'fifteen', title: '15-Puzzle Slide', desc: 'Unscramble the sliding tiles.', icon: Hash, category: 'puzzle', players: '1-3', maxPlayers: 3, color: '#38bdf8', turnBased: false },
  { id: 'sokoban', title: 'Crate Pusher', desc: 'Push every crate onto its pad.', icon: Package, category: 'puzzle', players: '1-3', maxPlayers: 3, color: '#a06bff', turnBased: false },
  { id: 'lights', title: 'Lights Out', desc: 'Flip the grid until all dark.', icon: Lightbulb, category: 'puzzle', players: '1-3', maxPlayers: 3, color: '#ffe74c', turnBased: false },
  { id: 'snakepuz', title: 'Serpent Path', desc: 'Fill the grid with one snake trail.', icon: Cable, category: 'puzzle', players: '1-3', maxPlayers: 3, color: '#4dff88', turnBased: false },
  // PARTY (12) -> total 42
  { id: 'hangman', title: 'Hangman Words', desc: 'Guess letters before the pixel man falls.', icon: Type, category: 'party', players: '2-3', maxPlayers: 3, color: '#ff2e63', turnBased: true },
  { id: 'scramble', title: 'Word Scramble', desc: 'Unscramble against the clock.', icon: ClipboardList, category: 'party', players: '1-3', maxPlayers: 3, color: '#08d9d6', turnBased: false },
  { id: 'typing', title: 'Typing Thunder', desc: 'Type the passage fastest.', icon: Type, category: 'party', players: '1-3', maxPlayers: 3, hot: true, color: '#ffe74c', turnBased: false },
  { id: 'trivia', title: 'Trivia Clash', desc: '8 retro questions, buzzer brains.', icon: Trophy, category: 'party', players: '2-3', maxPlayers: 3, hot: true, color: '#a06bff', turnBased: true },
  { id: 'mathduel', title: 'Math Duel', desc: 'Solve sums faster than friends.', icon: Calculator, category: 'party', players: '2-3', maxPlayers: 3, color: '#4dff88', turnBased: false },
  { id: 'rps', title: 'Rock Paper Zap', desc: 'Best-of-5 lightning rounds.', icon: Hand, category: 'party', players: '2-3', maxPlayers: 3, color: '#ff9f1c', turnBased: true },
  { id: 'dice', title: 'Dice Duel', desc: 'Highest roll takes the pot.', icon: Dices, category: 'party', players: '2-3', maxPlayers: 3, color: '#38bdf8', turnBased: true },
  { id: 'war', title: 'Card War', desc: 'Flip cards, highest takes all.', icon: Spade, category: 'party', players: '2-3', maxPlayers: 3, color: '#f472b6', turnBased: true },
  { id: 'blackjack', title: 'Pixel Blackjack', desc: 'Beat the dealer to 21.', icon: Coins, category: 'party', players: '1-3', maxPlayers: 3, color: '#4dff88', turnBased: true },
  { id: 'reaction', title: 'Reaction Zap', desc: 'Tap green first. No false starts.', icon: Timer, category: 'party', players: '2-3', maxPlayers: 3, hot: true, color: '#ff2e63', turnBased: true },
  { id: 'guessnum', title: 'Number Heist', desc: 'Crack the 1-100 code in fewest tries.', icon: Target, category: 'party', players: '1-3', maxPlayers: 3, color: '#08d9d6', turnBased: false },
  { id: 'bingo', title: 'Bingo Blitz', desc: 'Mark numbers, shout BINGO first.', icon: LayoutGrid, category: 'party', players: '2-3', maxPlayers: 3, color: '#ffe74c', turnBased: true },
  { id: 'odom', title: 'Odd or Even', desc: 'Call it, roll it — 10 lightning rounds.', icon: CircleDot, category: 'party', players: '2-3', maxPlayers: 3, isNew: true, color: '#38bdf8', turnBased: true },
  { id: 'tictac3', title: 'Triple Tic-Tac', desc: 'Tic-tac-toe on a 4×4 board — 4 in a row wins.', icon: Grid2x2, category: 'party', players: '2', maxPlayers: 2, isNew: true, color: '#a06bff', turnBased: true },
];

export const gameById = (id: string) => GAMES.find(g => g.id === id);
export const boardWins = {
  tictactoe: (b: (string|null)[]) => {
    const L = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
    for (const [a,c,d] of L) if (b[a] && b[a]===b[c] && b[a]===b[d]) return b[a];
    return b.every(Boolean) ? 'draw' : null;
  }
};
