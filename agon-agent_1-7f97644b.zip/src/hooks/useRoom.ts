import { useEffect, useState, useCallback, useRef } from 'react';
import supabase from '../lib/supabase';
import type { Room } from '../games/types';

// ---- tiny shared fetch layer: dedupe + cache + retry (handles 40-50 concurrent players) ----
const cache = new Map<string, { at: number; data: any }>();
const inflight = new Map<string, Promise<any>>();
const CACHE_TTL = 4000;

async function cachedGet(url: string, ttl = CACHE_TTL): Promise<any> {
  const now = Date.now();
  const hit = cache.get(url);
  if (hit && now - hit.at < ttl) return hit.data;
  const ongoing = inflight.get(url);
  if (ongoing) return ongoing;
  const p = (async () => {
    let lastErr: any = null;
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const ctrl = new AbortController();
        const to = setTimeout(() => ctrl.abort(), 9000);
        const r = await fetch(url, { signal: ctrl.signal });
        clearTimeout(to);
        if (!r.ok) {
          if (r.status === 404) throw new Error('Room not found');
          throw new Error(`Request failed (${r.status})`);
        }
        const d = await r.json();
        cache.set(url, { at: Date.now(), data: d });
        return d;
      } catch (e) {
        lastErr = e;
        await new Promise((res) => setTimeout(res, 350 * (attempt + 1)));
      }
    }
    throw lastErr;
  })().finally(() => { inflight.delete(url); });
  inflight.set(url, p);
  return p;
}

export function bustCache(prefix: string) {
  for (const k of [...cache.keys()]) if (k.startsWith(prefix)) cache.delete(k);
}

export function useRoom(code: string | null) {
  const [room, setRoom] = useState<Room | null>(null);
  const [loading, setLoading] = useState(!!code);
  const [error, setError] = useState('');
  const [live, setLive] = useState(false);
  const codeRef = useRef(code);
  codeRef.current = code;

  const fetchRoom = useCallback(async (force = false) => {
    if (!codeRef.current) { setRoom(null); setLoading(false); return null; }
    try {
      if (force) bustCache(`/api/rooms?code=${codeRef.current}`);
      const d = await cachedGet(`/api/rooms?code=${codeRef.current}`, 2500);
      setRoom((prev) => {
        // skip re-render churn when nothing changed
        try {
          if (prev && JSON.stringify(prev) === JSON.stringify(d)) return prev;
        } catch {}
        return d;
      });
      setError(''); setLoading(false);
      return d as Room;
    } catch {
      setLoading(false); return null;
    }
  }, []);

  useEffect(() => {
    if (!code) { setRoom(null); setLoading(false); return; }
    setLoading(true);
    fetchRoom(true);
    // adaptive polling: slow when idle, faster right after a move (live channel usually covers it)
    let delay = 2200;
    let timer: any = null;
    let lastState = '';
    const tick = async () => {
      const r = (await fetchRoom(false)) as Room | null;
      try {
        const sig = JSON.stringify(r?.state || {});
        delay = sig !== lastState ? 1200 : Math.min(5000, delay + 400);
        lastState = sig;
      } catch {}
      timer = setTimeout(tick, delay);
    };
    timer = setTimeout(tick, delay);
    let chan: any = null;
    try {
      chan = supabase.channel(`room-${code}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'rooms', filter: `code=eq.${code}` }, (p: any) => {
          if (p.new) {
            setLive(true);
            setRoom(p.new as Room);
            try { cache.set(`/api/rooms?code=${code}`, { at: Date.now(), data: p.new }); } catch {}
          }
        }).subscribe();
    } catch {}
    return () => { clearTimeout(timer); try { chan && supabase.removeChannel(chan); } catch {} };
  }, [code, fetchRoom]);

  const queueRef = useRef<Promise<any>>(Promise.resolve());
  const pendingRef = useRef<any>({});
  const timerRef = useRef<any>(null);
  const pushState = useCallback(async (patch: any, status?: string) => {
    if (!codeRef.current) return;
    const code = codeRef.current;
    // optimistic local update (deep-merge scores so concurrent reports don't clobber each other)
    setRoom((prev) => {
      if (!prev) return prev;
      const merged: any = { ...(prev.state || {}), ...patch };
      if ((prev.state as any)?.scores || (patch as any)?.scores) {
        merged.scores = { ...((prev.state as any)?.scores || {}), ...((patch as any)?.scores || {}) };
      }
      return { ...prev, state: merged };
    });
    // coalesce rapid bursts into one write per 800ms window
    pendingRef.current = { ...pendingRef.current, ...patch };
    if ((patch as any)?.scores) {
      pendingRef.current.scores = { ...(pendingRef.current.scores || {}), ...(patch as any).scores };
    }
    const wantStatus = status;
    if (timerRef.current) return;
    timerRef.current = setTimeout(() => {
      timerRef.current = null;
      const body = pendingRef.current;
      pendingRef.current = {};
      queueRef.current = queueRef.current.then(async () => {
        let merged: any = null;
        setRoom((prev) => {
          merged = { ...((prev?.state as any) || {}), ...body };
          if (((prev?.state as any)?.scores) || (body as any)?.scores) {
            merged.scores = { ...(((prev?.state as any)?.scores) || {}), ...((body as any)?.scores || {}) };
          }
          return prev;
        });
        try {
          await fetch('/api/rooms', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'state', code, state: merged, ...(wantStatus ? { status: wantStatus } : {}) }),
          });
          bustCache(`/api/rooms?code=${code}`);
        } catch {}
      });
    }, 800);
  }, []);

  return { room, loading, error, live, fetchRoom, pushState, setRoom };
}

export async function createRoom(game_id: string, game_title: string, host_id: string, host_name: string, max_players: number) {
  const r = await fetch('/api/rooms', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'create', game_id, game_title, host_id, host_name, max_players }) });
  if (!r.ok) throw new Error((await r.json()).error || 'Could not create room');
  return await r.json();
}
export async function joinRoom(code: string, player_id: string, player_name: string) {
  const r = await fetch('/api/rooms', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'join', code, player_id, player_name }) });
  if (!r.ok) throw new Error((await r.json()).error || 'Could not join');
  return await r.json();
}
export async function leaveRoom(code: string, player_id: string) {
  try { await fetch('/api/rooms', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'leave', code, player_id }) }); } catch {}
}
export async function recordResult(game_id: string, game_title: string, room_code: string, players: string[], winner_name: string | null, winner_index: number | null, scores: Record<string, number>, myId: string, myName: string, won: boolean, score: number) {
  const payload = { game_id, game_title, room_code, players, winner_name, winner_index, scores };
  try {
    // fire-and-forget with keepalive so results survive tab closes during traffic spikes; never blocks UI
    const body = JSON.stringify(payload);
    if (navigator.sendBeacon) {
      try { navigator.sendBeacon('/api/matches', new Blob([body], { type: 'application/json' })); } catch {}
    } else {
      fetch('/api/matches', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body, keepalive: true } as any).catch(() => {});
    }
  } catch {}
  try {
    const uname = myId && !myId.startsWith('guest_') ? myName : myName + ' (guest)';
    const sbody = JSON.stringify({ user_id: myId, username: uname, game_id, won, score });
    if (navigator.sendBeacon) {
      try { navigator.sendBeacon('/api/stats', new Blob([sbody], { type: 'application/json' })); } catch {}
    } else {
      fetch('/api/stats', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: sbody, keepalive: true } as any).catch(() => {});
    }
  } catch {}
}
