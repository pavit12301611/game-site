import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import supabase from '../lib/supabase';
import { signInWithGoogle } from '../lib/googleAuth';
import { useAuth } from '../contexts/AuthContext';

export default function Login() {
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [mode, setMode] = useState<'in'|'up'>('in');
  const [err, setErr] = useState('');
  const [nick, setNick] = useState(() => localStorage.getItem('ppa_nick') || '');
  const nav = useNavigate();
  const { setNickname } = useAuth();

  const submit = async (e: any) => {
    e.preventDefault(); setErr('');
    if (!email.includes('@')) { setErr('Enter a valid email'); return; }
    if (pw.length < 6) { setErr('Password needs 6+ characters'); return; }
    try {
      if (mode === 'up') {
        const { error } = await supabase.auth.signUp({ email, password: pw });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password: pw });
        if (error) throw error;
      }
      nav('/');
    } catch (e: any) { setErr(e.message || 'Auth failed'); }
  };

  return (
    <div className="max-w-md mx-auto mt-8">
      <div className="pixel-panel p-6">
        <div className="font-pixel text-sm neon-text-pink mb-1">JOIN THE ARCADE</div>
        <p className="text-xs text-slate-400 mb-4">Sign in to get a permanent username, friends & ranks. Or just pick a nickname and play instantly.</p>
        <form onSubmit={submit} className="space-y-2">
          <input className="pixel-input" type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
          <input className="pixel-input" type="password" placeholder="Password" value={pw} onChange={e=>setPw(e.target.value)} />
          {err && <div className="text-xs p-2 rounded" style={{background:'rgba(255,46,99,.15)',color:'#ff8098'}}>{err}</div>}
          <button className="pixel-btn w-full" type="submit">{mode==='up'?'Sign Up':'Sign In'}</button>
        </form>
        <div className="flex gap-2 mt-2 text-xs">
          <button className="flex-1 py-2 rounded-lg" style={{background:mode==='in'?'#2b2b5e':'transparent',color:'#fff'}} onClick={()=>setMode('in')}>Sign in</button>
          <button className="flex-1 py-2 rounded-lg" style={{background:mode==='up'?'#2b2b5e':'transparent',color:'#fff'}} onClick={()=>setMode('up')}>New account</button>
        </div>
        <div className="text-center text-xs text-slate-500 my-3">or</div>
        <button className="pixel-btn pixel-btn-cyan w-full" onClick={()=>signInWithGoogle('Pixel Party Arcade')}>G · Sign in with Google</button>
        <div className="mt-5 pt-4" style={{borderTop:'1px solid #2b2b5e'}}>
          <div className="font-pixel text-[10px] mb-2" style={{color:'#4dff88'}}>GUEST MODE — NO ACCOUNT NEEDED</div>
          <div className="flex gap-2">
            <input className="pixel-input" placeholder="Pick a nickname…" value={nick} maxLength={16} onChange={e=>setNick(e.target.value)} />
            <button className="pixel-btn pixel-btn-ghost whitespace-nowrap" onClick={()=>{setNickname(nick.trim()||'Guest');nav('/');}}>Play!</button>
          </div>
        </div>
        <Link to="/" className="block text-center text-xs text-slate-500 mt-4 no-underline">← back to arcade</Link>
      </div>
    </div>
  );
}
