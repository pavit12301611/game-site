import { useEffect, useState } from 'react';
import { Trophy, Medal } from 'lucide-react';
import { GAMES } from '../lib/games';

export default function Ranks() {
  const [rows, setRows] = useState<any[]>([]);
  const [game, setGame] = useState('__all');
  const [loading, setLoading] = useState(true);
  const load = async (g?: string) => {
    setLoading(true);
    try {
      const r = await fetch(`/api/stats${g&&g!=='__all'?`?game_id=${g}`:''}`);
      setRows(await r.json());
    } catch {}
    setLoading(false);
  };
  useEffect(()=>{ load(game); }, [game]);
  const agg = (()=>{
    const m = new Map<string, any>();
    rows.forEach(r=>{
      const k = r.user_id;
      if (!m.has(k)) m.set(k, { user_id: k, username: r.username, plays: 0, wins: 0, best: 0, games: new Set() });
      const a = m.get(k);
      a.plays += r.plays||0; a.wins += r.wins||0; a.best = Math.max(a.best, r.best_score||0); a.games.add(r.game_id);
    });
    return [...m.values()].map(a=>({...a, games:[...a.games].length})).sort((x,y)=>y.wins-x.wins||y.plays-x.plays);
  })();
  const medal = (i:number)=> i===0?'🥇':i===1?'🥈':i===2?'🥉':`${i+1}.`;
  return (
    <div className="mt-6 max-w-3xl mx-auto">
      <h1 className="font-pixel text-lg neon-text-yellow flex items-center gap-2"><Trophy size={20}/> LEADERBOARD</h1>
      <p className="text-xs text-slate-400 mt-1 mb-4">Every finished match writes wins, plays & best scores here — solo and online.</p>
      <div className="flex gap-2 mb-3 overflow-auto pb-1">
        <button onClick={()=>setGame('__all')} className="whitespace-nowrap font-pixel text-[10px] px-4 py-2 rounded-xl" style={{background:game==='__all'?'linear-gradient(180deg,#ff2e63,#c21445)':'#1c1c3d',border:'2px solid #000',color:'#fff'}}>OVERALL</button>
        {GAMES.map(g=><button key={g.id} onClick={()=>setGame(g.id)} className="whitespace-nowrap font-pixel text-[10px] px-3 py-2 rounded-xl" style={{background:game===g.id?`linear-gradient(180deg, ${g.color}, ${g.color}88)`:'#1c1c3d',border:'2px solid #000',color:'#fff'}}>{g.title.split(' ')[0].toUpperCase()}</button>)}
      </div>
      <div className="pixel-panel p-4">
        {loading?<div className="text-center text-slate-400 py-8 blink font-pixel text-xs">LOADING RANKS…</div>:
        game==='__all'?(
          agg.length===0?<div className="text-center text-slate-500 py-8 text-sm">No matches yet — go play something!</div>:
          <div className="space-y-2">{agg.slice(0,30).map((a,i)=>(
            <div key={a.user_id} className="flex items-center gap-3 p-2.5 rounded-xl" style={{background:i<3?'rgba(255,231,76,.07)':'#0a0a20',border:i===0?'2px solid #ffe74c':'1px solid #2b2b5e'}}>
              <span className="w-10 text-center font-pixel text-xs">{medal(i)}</span>
              <span className="w-9 h-9 rounded-full flex items-center justify-center font-bold shrink-0" style={{background:'#a06bff',color:'#000'}}>{(a.username||'?')[0].toUpperCase()}</span>
              <span className="flex-1 min-w-0"><b className="block truncate text-sm">{a.username}</b><span className="text-[11px] text-slate-500">{a.games} games</span></span>
              <span className="text-center"><b className="font-pixel text-xs block" style={{color:'#4dff88'}}>{a.wins}</b><span className="text-[10px] text-slate-500">wins</span></span>
              <span className="text-center"><b className="font-pixel text-xs block text-slate-200">{a.plays}</b><span className="text-[10px] text-slate-500">plays</span></span>
              <span className="text-center hidden sm:block"><b className="font-pixel text-xs block" style={{color:'#ffe74c'}}>{a.best}</b><span className="text-[10px] text-slate-500">best</span></span>
            </div>))}
          </div>
        ):(
          rows.length===0?<div className="text-center text-slate-500 py-8 text-sm">No scores for this game yet.</div>:
          <div className="space-y-2">{[...rows].sort((a,b)=>(b.wins-a.wins)||(b.best_score-a.best_score)).slice(0,30).map((r,i)=>(
            <div key={r.id} className="flex items-center gap-3 p-2.5 rounded-xl" style={{background:'#0a0a20',border:'1px solid #2b2b5e'}}>
              <span className="w-10 text-center font-pixel text-xs">{medal(i)}</span>
              <span className="flex-1 min-w-0"><b className="block truncate text-sm">{r.username}</b><span className="text-[11px] text-slate-500">{r.plays} plays</span></span>
              <span className="text-center"><b className="font-pixel text-xs block" style={{color:'#4dff88'}}>{r.wins}</b><span className="text-[10px] text-slate-500">wins</span></span>
              <span className="text-center"><b className="font-pixel text-xs block" style={{color:'#ffe74c'}}>{r.best_score}</b><span className="text-[10px] text-slate-500">best</span></span>
            </div>))}
          </div>
        )}
      </div>
      <div className="text-[11px] text-slate-600 mt-3 flex items-center gap-1"><Medal size={12}/> Guest scores count too — sign in to keep one permanent name.</div>
    </div>
  );
}
