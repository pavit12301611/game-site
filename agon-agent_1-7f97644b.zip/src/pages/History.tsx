import { useEffect, useState } from 'react';
import { Clock } from 'lucide-react';
import { GAMES, gameById } from '../lib/games';

export default function History() {
  const [rows, setRows] = useState<any[]>([]);
  const [game, setGame] = useState('__all');
  useEffect(()=>{
    fetch(`/api/matches?limit=60${game!=='__all'?`&game_id=${game}`:''}`).then(r=>r.json()).then(d=>setRows(Array.isArray(d)?d:[])).catch(()=>{});
  },[game]);
  return (
    <div className="mt-6 max-w-3xl mx-auto">
      <h1 className="font-pixel text-lg neon-text-cyan flex items-center gap-2"><Clock size={20}/> RECENT MATCHES</h1>
      <p className="text-xs text-slate-400 mt-1 mb-4">Fresh from the arcade floor — who beat whom, and where.</p>
      <div className="flex gap-2 mb-3 overflow-auto pb-1">
        <button onClick={()=>setGame('__all')} className="whitespace-nowrap font-pixel text-[10px] px-4 py-2 rounded-xl" style={{background:game==='__all'?'linear-gradient(180deg,#08d9d6,#058b89)':'#1c1c3d',border:'2px solid #000',color:game==='__all'?'#042':'#fff'}}>ALL</button>
        {GAMES.map(g=><button key={g.id} onClick={()=>setGame(g.id)} className="whitespace-nowrap font-pixel text-[10px] px-3 py-2 rounded-xl" style={{background:game===g.id?'#2b2b5e':'#1c1c3d',border:'2px solid #000',color:'#fff'}}>{g.title.split(' ')[0].toUpperCase()}</button>)}
      </div>
      <div className="space-y-2">
        {rows.length===0&&<div className="pixel-panel p-8 text-center text-slate-500 text-sm">No matches logged yet — finish a game to write history.</div>}
        {rows.map((m:any)=>{
          const g = gameById(m.game_id);
          return <div key={m.id} className="pixel-panel p-3.5 flex items-center gap-3">
            <span className="w-10 h-10 rounded-xl flex items-center justify-center font-pixel text-xs shrink-0" style={{background:(g?.color||'#888')+'22',border:`2px solid ${g?.color||'#888'}`}}>🎮</span>
            <span className="flex-1 min-w-0">
              <b className="text-sm block truncate">{m.game_title} {m.room_code&&m.room_code!=='solo'&&<span className="font-mono text-[10px] px-1.5 py-0.5 rounded ml-1" style={{background:'#0a0a20',color:'#08d9d6'}}>room {m.room_code}</span>}</b>
              <span className="text-[11px] text-slate-400 block truncate">{(m.players||[]).join(' vs ')||'—'} {m.winner_name?<>· 👑 <b style={{color:'#ffe74c'}}>{m.winner_name}</b></>:<>· draw</>}</span>
            </span>
            <span className="text-[10px] text-slate-500 whitespace-nowrap">{m.created_at?new Date(m.created_at).toLocaleString():''}</span>
          </div>;
        })}
      </div>
    </div>
  );
}
