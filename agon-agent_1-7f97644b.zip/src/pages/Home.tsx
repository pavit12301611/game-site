import { useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Search, Users, Zap, Crown, Play, Gamepad2, Wifi, Link2, UserPlus, Sparkles, Swords, Puzzle as PuzzleIcon, PartyPopper, ChevronRight, Flame } from 'lucide-react';
import { GAMES, CATEGORIES, gameById, type Category } from '../lib/games';
import { useAuth } from '../contexts/AuthContext';

const CAT_STYLE: Record<string, { grad: string; glow: string; icon: any }> = {
  board: { grad: 'linear-gradient(135deg,#ff2e63,#ff9f1c)', glow: 'rgba(255,46,99,.35)', icon: Swords },
  arcade: { grad: 'linear-gradient(135deg,#08d9d6,#4dff88)', glow: 'rgba(8,217,214,.35)', icon: Zap },
  puzzle: { grad: 'linear-gradient(135deg,#a06bff,#38bdf8)', glow: 'rgba(160,107,255,.35)', icon: PuzzleIcon },
  party: { grad: 'linear-gradient(135deg,#ffe74c,#ff2e63)', glow: 'rgba(255,231,76,.3)', icon: PartyPopper },
};

export default function Home() {
  const [q, setQ] = useState('');
  const [cat, setCat] = useState<Category | 'all' | 'online' | 'new'>('all');
  const [only2p, setOnly2p] = useState(false);
  const [only3p, setOnly3p] = useState(false);
  const [params] = useSearchParams();
  const [stats, setStats] = useState<any[]>([]);
  const { playerId, playerName } = useAuth();
  const [openRooms, setOpenRooms] = useState<any[]>([]);
  const [joinCode, setJoinCode] = useState('');

  useEffect(() => {
    let alive = true;
    const get = (url: string) => fetch(url).then((r) => (r.ok ? r.json() : null)).catch(() => null);
    get('/api/stats').then((d) => { if (alive) setStats(Array.isArray(d) ? d : []); });
    const loadRooms = () => get('/api/rooms?open=1').then((d) => { if (alive) setOpenRooms(Array.isArray(d) ? d : []); });
    loadRooms();
    const t = setInterval(loadRooms, 15000);
    // deep link ?room=CODE or ?game=ID
    const rc = params.get('room');
    if (rc) window.location.hash = '';
    return () => { alive = false; clearInterval(t); };
  }, []);

  const roomParam = params.get('room');
  const inviteParam = params.get('invite');
  const gameParam = params.get('game');

  useEffect(() => {
    if (gameParam && gameById(gameParam)) {
      setQ(''); setCat(gameById(gameParam)!.category);
      setTimeout(()=>{document.getElementById('game-'+gameParam)?.scrollIntoView({behavior:'smooth',block:'center'});},400);
    }
  }, [gameParam]);

  const playsFor = (id: string) => stats.filter(s=>s.game_id===id).reduce((a,b)=>a+(b.plays||0),0);

  const filtered = useMemo(() => {
    let list = [...GAMES];
    if (cat === 'online') list = list.filter(g=>g.maxPlayers>=2);
    else if (cat === 'new') list = list.filter(g=>g.isNew);
    else if (cat !== 'all') list = list.filter(g=>g.category===cat);
    if (only2p) list = list.filter(g=>g.maxPlayers>=2);
    if (only3p) list = list.filter(g=>g.maxPlayers>=3);
    if (q.trim()) {
      const s = q.toLowerCase();
      list = list.filter(g=>g.title.toLowerCase().includes(s)||g.desc.toLowerCase().includes(s));
    }
    return list.sort((a,b)=>((b.isNew?1:0)-(a.isNew?1:0)) || (playsFor(b.id)-playsFor(a.id)) || ((b.hot?1:0)-(a.hot?1:0)));
  }, [q, cat, only2p, only3p, stats]);

  const totalPlays = stats.reduce((a,b)=>a+(b.plays||0),0);

  return (
    <div>
      {/* invite banner */}
      {inviteParam && (
        <div className="pixel-panel mt-4 p-4 flex flex-wrap items-center gap-3" style={{borderColor:'#4dff88'}}>
          <UserPlus color="#4dff88" />
          <div className="text-sm"><b>Friend invite!</b> <span className="text-slate-300 font-mono">{inviteParam.slice(0,18)}…</span> wants to play. Add them from the Friends tab, then share a room code.</div>
          <Link to={`/friends?add=${encodeURIComponent(inviteParam)}`} className="pixel-btn pixel-btn-cyan no-underline !text-[10px]">Add friend</Link>
        </div>
      )}
      {roomParam && (
        <div className="pixel-panel mt-4 p-4 flex flex-wrap items-center gap-3" style={{borderColor:'#08d9d6'}}>
          <Link2 color="#08d9d6" />
          <div className="text-sm">You opened a <b>room invite {roomParam.toUpperCase()}</b> — pick the game below or jump straight in.</div>
          <Link to={`/play/shared?room=${roomParam.toUpperCase()}`} className="pixel-btn no-underline !text-[10px]">Join room</Link>
        </div>
      )}

      {/* HERO */}
      <section className="mt-6 pixel-panel panel-glow-pink p-6 md:p-10 relative overflow-hidden rise">
        <div className="absolute inset-0 pointer-events-none hero-grid" />
        <div className="orb" style={{ width: 280, height: 280, left: -80, top: -80, background: '#ff2e63' }} />
        <div className="orb" style={{ width: 240, height: 240, right: -60, top: -40, background: '#08d9d6', animationDelay: '2s' }} />
        <div className="orb" style={{ width: 200, height: 200, left: '45%', bottom: -100, background: '#a06bff', animationDelay: '4s' }} />
        <div className="grid md:grid-cols-[1.2fr_.8fr] gap-6 items-center relative">
          <div>
            <div className="font-pixel text-[10px] mb-3 flex items-center gap-2 flex-wrap" style={{color:'#4dff88'}}>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-full pulse-glow" style={{background:'rgba(77,255,136,.1)',border:'1px solid rgba(77,255,136,.5)'}}><span className="w-2 h-2 rounded-full blink" style={{background:'#4dff88'}}/> {openRooms.length} LIVE LOBBIES</span>
              <span className="hidden sm:inline">ONLINE MULTIPLAYER · 2–3 PLAYERS · SHARE A LINK</span>
            </div>
            <h1 className="font-pixel text-2xl md:text-[2.6rem] md:leading-[1.25]">
              <span className="neon-text-pink">PIXEL PARTY</span><br/>
              <span className="grad-text">RETRO ARCADE</span>
            </h1>
            <p className="text-slate-300 mt-4 max-w-lg text-sm md:text-base">
              <b className="font-pixel text-[11px]" style={{color:'#ffe74c'}}>{GAMES.length} CLASSICS</b>, rebuilt for the browser — including <b>Chess</b>, <b>Ludo</b> and <b>Snakes &amp; Ladders</b>. Host a room, share the <b>6-letter code or link</b>,
              friends join from their own laptops — no downloads. Built to stay smooth with <b>40–50 players</b> online at once.
            </p>
            <div className="flex flex-wrap gap-2 mt-5">
              <a href="#games" className="pixel-btn no-underline inline-flex items-center gap-2"><Play size={14}/> Play now</a>
              <Link to="/friends" className="pixel-btn pixel-btn-cyan no-underline inline-flex items-center gap-2"><Users size={14}/> Find friends</Link>
              <Link to="/ranks" className="pixel-btn pixel-btn-yellow no-underline inline-flex items-center gap-2"><Crown size={14}/> Ranks</Link>
            </div>
            <div className="grid grid-cols-3 gap-2 mt-6 max-w-md">
              {[
                { v: String(GAMES.length), l: 'games', c: '#ffe74c' },
                { v: totalPlays ? String(totalPlays) : '—', l: 'plays logged', c: '#4dff88' },
                { v: String(openRooms.length), l: 'open rooms', c: '#08d9d6' },
              ].map((s, i) => (
                <div key={i} className="rounded-xl px-3 py-2.5 text-center" style={{ background: 'rgba(10,10,32,.8)', border: '1px solid #2b2b5e' }}>
                  <b className="font-pixel text-base block" style={{ color: s.c }}>{s.v}</b>
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider">{s.l}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="pixel-panel panel-glow-cyan p-4 relative overflow-hidden" style={{background:'rgba(10,10,32,.9)'}}>
            <div className="absolute inset-0 pointer-events-none hero-grid opacity-60" />
            <div className="font-pixel text-[10px] mb-3 neon-text-yellow">⚡ JOIN A ROOM</div>
            <div className="flex gap-2">
              <input className="pixel-input font-pixel text-sm uppercase text-center tracking-[0.3em]" placeholder="CODE" maxLength={6} value={joinCode} onChange={e=>setJoinCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g,''))} />
              <Link to={joinCode.length>=4?`/play/shared?room=${joinCode}`:'#games'} className="pixel-btn no-underline">Go</Link>
            </div>
            <div className="text-[11px] text-slate-500 mt-2">…or pick any game card below and host your own.</div>
            <div className="mt-3 pt-3" style={{borderTop:'1px solid #2b2b5e'}}>
              <div className="font-pixel text-[10px] mb-2" style={{color:'#4dff88'}}>🟢 OPEN LOBBIES ({openRooms.length})</div>
              <div className="space-y-1.5 max-h-40 overflow-auto">
                {openRooms.length===0&&<div className="text-xs text-slate-500">No open rooms — be the first to host!</div>}
                {openRooms.slice(0,6).map((r:any)=>(
                  <Link key={r.code} to={`/play/${r.game_id}?room=${r.code}`} className="flex items-center gap-2 text-xs px-2.5 py-1.5 rounded-lg no-underline hover:bg-white/5" style={{background:'#14142b'}}>
                    <span className="font-mono font-bold" style={{color:'#08d9d6'}}>{r.code}</span>
                    <span className="text-slate-200 truncate flex-1">{r.game_title}</span>
                    <span className="text-slate-500">{(r.players||[]).length}/{r.max_players}</span>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* NEW DROPS */}
      <section className="mt-4 pixel-panel panel-glow-green p-4 md:p-5 relative overflow-hidden">
        <div className="flex items-center gap-2 mb-3">
          <Sparkles size={16} color="#4dff88" />
          <span className="font-pixel text-[11px] neon-text-green">FRESH CABINETS — NEW!</span>
          <span className="text-[11px] text-slate-400 hidden sm:inline">Chess · Ludo · Snakes &amp; Ladders · Coin Rush · Odd or Even · Triple Tic-Tac</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          {['chess','ludo','snakesladders','coinrush','odom','tictac3'].map((id) => {
            const g = gameById(id);
            if (!g) return null;
            const Icon = g.icon;
            return (
              <Link key={id} to={`/play/${id}`} className="rounded-xl p-3 no-underline group relative overflow-hidden" style={{ background: '#0a0a20', border: `2px solid ${g.color}` }}>
                <span className="absolute top-1.5 right-1.5 font-pixel text-[7px] px-1.5 py-0.5 rounded" style={{ background: '#4dff88', color: '#063' }}>NEW</span>
                <Icon size={20} color={g.color} />
                <b className="block text-xs mt-1.5 text-slate-100 group-hover:underline">{g.title}</b>
                <span className="text-[10px] text-slate-500">{g.players}P · online ⚡</span>
              </Link>
            );
          })}
        </div>
      </section>

      {/* marquee */}
      <div className="mt-4 overflow-hidden rounded-xl" style={{border:'2px solid #2b2b5e',background:'#0a0a20'}}>
        <div className="flex whitespace-nowrap marquee-track py-2 font-pixel text-[10px]" style={{width:'max-content'}}>
          {[0,1].map(k=><span key={k} className="pr-8" style={{color:'#8b8bd3'}}>
            {GAMES.map(g=>g.title.toUpperCase()).join('  ★  ')}  ★&nbsp;
          </span>)}
        </div>
      </div>

      {/* how it works */}
      <section className="grid sm:grid-cols-4 gap-3 mt-4">
        {[
          {icon:<Gamepad2 size={18}/>,t:'1 · Pick a game',d:`${GAMES.length} retro hits — board, arcade, puzzles & party.`,c:'#ff2e63'},
          {icon:<Link2 size={18}/>,t:'2 · Share link or code',d:'Room links look like ?room=X7K2PQ — send anywhere.',c:'#08d9d6'},
          {icon:<Users size={18}/>,t:'3 · 2–3 play live',d:'Turn games sync instantly; races stream live scores.',c:'#4dff88'},
          {icon:<Flame size={18}/>,t:'4 · Built for crowds',d:'40–50 players at once — throttled sync, cached reads.',c:'#ffe74c'},
        ].map((s,i)=><div key={i} className="pixel-panel p-4 flex gap-3 items-start rise" style={{animationDelay:`${i*0.06}s`}}>
          <span className="w-9 h-9 shrink-0 rounded-lg flex items-center justify-center" style={{background:'#0a0a20',border:`2px solid ${s.c}`,color:s.c}}>{s.icon}</span>
          <span><b className="font-pixel text-[10px] block mb-1" style={{color:s.c}}>{s.t}</b><span className="text-xs text-slate-300">{s.d}</span></span>
        </div>)}
      </section>

      {/* filters */}
      <section id="games" className="mt-8">
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input className="pixel-input !pl-9" placeholder={`Search ${GAMES.length} games… (try 'chess', 'ludo', 'typing')`} value={q} onChange={e=>setQ(e.target.value)} />
          </div>
          <button onClick={()=>setOnly2p(!only2p)} className="text-xs px-3 py-2 rounded-full font-bold" style={{background:only2p?'#ff2e63':'#1c1c3d',border:'2px solid #000',color:'#fff'}}>2P</button>
          <button onClick={()=>setOnly3p(!only3p)} className="text-xs px-3 py-2 rounded-full font-bold" style={{background:only3p?'#08d9d6':'#1c1c3d',border:'2px solid #000',color:'#fff'}}>3P</button>
        </div>
        <div className="flex gap-2 overflow-auto pb-2">
          {[{id:'all',label:`All ${GAMES.length}`},{id:'online',label:'⚡ Online rooms'},{id:'new',label:'✨ New'},...CATEGORIES.map(c=>({id:c.id,label:c.label}))].map((c:any)=>(
            <button key={c.id} onClick={()=>setCat(c.id as any)} className="whitespace-nowrap font-pixel text-[10px] px-4 py-2.5 rounded-xl"
              style={{background:cat===c.id?'linear-gradient(180deg,#ff2e63,#c21445)':(c.id==='new'?'linear-gradient(180deg,#1f9d55,#0d5c30)':'#1c1c3d'),border:'2px solid #000',color:'#fff',boxShadow:cat===c.id?'0 0 16px rgba(255,46,99,.5)':'none'}}>{c.label}</button>
          ))}
        </div>
        <div className="text-xs text-slate-500 mt-2 mb-3 flex items-center gap-1"><Zap size={12}/> Showing {filtered.length} games · <Users size={12}/> every game supports solo + online 2–3P</div>

        {CATEGORIES.filter(c=>cat==='all'||cat==='online'||cat==='new'?true:c.id===cat).map(c=>{
          const list=filtered.filter(g=>g.category===c.id);
          if(!list.length)return null;
          const st = CAT_STYLE[c.id];
          const CIcon = st.icon;
          return (
            <div key={c.id} className="mb-7">
              <div className="flex items-center gap-3 mb-1">
                <span className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: st.grad, boxShadow: `0 0 18px ${st.glow}`, border: '2px solid #000' }}>
                  <CIcon size={18} color="#fff" />
                </span>
                <div>
                  <h2 className="font-pixel text-sm" style={{color:'#ffe74c'}}>{c.label.toUpperCase()} <span className="text-slate-500">· {list.length}</span></h2>
                  <p className="text-xs text-slate-500">{c.blurb}</p>
                </div>
                <div className="flex-1 h-[2px] rounded ml-2 hidden sm:block" style={{ background: `linear-gradient(90deg, ${st.glow}, transparent)` }} />
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 mt-3">
                {list.map(g=>{
                  const Icon=g.icon;
                  return (
                    <div key={g.id} id={'game-'+g.id} className="pixel-panel game-card p-4 flex flex-col group" style={{ boxShadow: `0 0 0 2px #060612, 0 0 20px ${g.color}22, inset 0 0 40px rgba(0,0,0,.5)` }}>
                      <div className="flex items-start justify-between mb-2">
                        <span className="icon-tile w-11 h-11 rounded-xl flex items-center justify-center" style={{background:`${g.color}22`,border:`2px solid ${g.color}`,boxShadow:`0 0 14px ${g.color}44`}}>
                          <Icon size={22} color={g.color} />
                        </span>
                        <span className="flex gap-1 flex-wrap justify-end">
                          {g.isNew&&<span className="font-pixel text-[8px] px-1.5 py-1 rounded blink" style={{background:'#4dff88',color:'#063'}}>NEW</span>}
                          {g.hot&&<span className="font-pixel text-[8px] px-1.5 py-1 rounded" style={{background:'#ff2e63',color:'#fff'}}>HOT</span>}
                          <span className="font-pixel text-[8px] px-1.5 py-1 rounded" style={{background:'#0a0a20',color:g.color,border:`1px solid ${g.color}`}}>{g.players}P</span>
                        </span>
                      </div>
                      <b className="text-sm flex items-center gap-1">{g.title} <ChevronRight size={13} className="text-slate-600 group-hover:text-slate-300 group-hover:translate-x-0.5 transition-all" /></b>
                      <p className="text-[11px] text-slate-400 flex-1 mt-1 leading-snug">{g.desc}</p>
                      <div className="text-[10px] text-slate-500 mt-2">{playsFor(g.id)} plays · {g.turnBased?'turn-sync ⚡':'live race ⚡'}</div>
                      <Link to={`/play/${g.id}`} className="pixel-btn play-glow no-underline text-center mt-3 !text-[10px]" style={{background:`linear-gradient(180deg, ${g.color}, ${g.color}99)`,color:(g.color==='#ffe74c'||g.color==='#f5f5f5')?'#231a00':'#fff',boxShadow:`0 4px 0 #000, 0 0 16px ${g.color}55`}}>
                        <Play size={12} className="inline mr-1"/> Play
                      </Link>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
        {filtered.length===0&&<div className="pixel-panel p-10 text-center text-slate-400">No games match “{q}”. Try another search.</div>}
      </section>
    </div>
  );
}
