import { useEffect, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { UserPlus, Trash2, Copy, Check, Search } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { GAMES } from '../lib/games';

export default function Friends() {
  const { playerId, playerName } = useAuth();
  const [params] = useSearchParams();
  const [friends, setFriends] = useState<any[]>([]);
  const [q, setQ] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [msg, setMsg] = useState('');
  const [copied, setCopied] = useState(false);
  const [inviteGame, setInviteGame] = useState(GAMES[0].id);

  const load = async () => {
    try { const r = await fetch(`/api/friends?owner_id=${playerId}`); setFriends(await r.json()); } catch {}
  };
  useEffect(()=>{ load(); }, [playerId]);
  useEffect(()=>{
    const add = params.get('add');
    if (add) { setQ(add); search(add); }
  }, []);

  const search = async (term?: string) => {
    const s = (term ?? q).trim();
    if (!s) return;
    try {
      const r = await fetch(`/api/profiles?search=${encodeURIComponent(s)}`);
      const d = await r.json();
      setResults((Array.isArray(d)?d:[]).filter((p:any)=>p.user_id!==playerId));
      if (!d.length) setMsg('No player found with that name — they need to sign in once first.');
      else setMsg('');
    } catch { setMsg('Search failed'); }
  };
  const add = async (p: any) => {
    try {
      const r = await fetch('/api/friends', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ owner_id: playerId, friend_id: p.user_id, friend_name: p.display_name || p.username }) });
      if (!r.ok) throw new Error('failed');
      setMsg(`Added ${p.display_name||p.username} as a friend!`);
      load();
    } catch { setMsg('Could not add friend'); }
  };
  const remove = async (id: number) => {
    try {
      await fetch(`/api/friends?id=${id}`, { method: 'DELETE' });
    } catch {}
    load();
  };
  const inviteLink = `${window.location.origin}/?invite=${playerId}`;
  const copyInvite = async () => { try { await navigator.clipboard.writeText(inviteLink); setCopied(true); setTimeout(()=>setCopied(false),1500);} catch {} };
  const gameLink = `${window.location.origin}/play/${inviteGame}`;

  return (
    <div className="mt-6 max-w-3xl mx-auto">
      <h1 className="font-pixel text-lg neon-text-cyan">FRIENDS & INVITES</h1>
      <p className="text-xs text-slate-400 mt-1 mb-4">Add friends by username, share invite links, and drop game links anywhere — Discord, WhatsApp, SMS.</p>

      <div className="grid md:grid-cols-2 gap-3">
        <div className="pixel-panel p-5">
          <div className="font-pixel text-[10px] mb-3" style={{color:'#4dff88'}}>🔍 ADD BY USERNAME</div>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input className="pixel-input !pl-9" placeholder="username or name…" value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>{if(e.key==='Enter')search();}} />
            </div>
            <button className="pixel-btn" onClick={()=>search()}>Find</button>
          </div>
          {msg && <div className="text-xs mt-2" style={{color:'#ffe74c'}}>{msg}</div>}
          <div className="space-y-2 mt-3 max-h-64 overflow-auto">
            {results.map((p:any)=>(
              <div key={p.user_id} className="flex items-center gap-2 p-2 rounded-lg" style={{background:'#0a0a20'}}>
                <span className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm" style={{background:p.avatar_color||'#a06bff',color:'#000'}}>{(p.display_name||p.username||'?')[0].toUpperCase()}</span>
                <span className="flex-1 min-w-0"><b className="text-sm block truncate">{p.display_name||p.username}</b><span className="text-[11px] text-slate-500">@{p.username}</span></span>
                <button className="pixel-btn !text-[9px] !px-2 !py-2" onClick={()=>add(p)}><UserPlus size={12}/></button>
              </div>
            ))}
          </div>
          <div className="text-[11px] text-slate-500 mt-3">Playing as <b style={{color:'#4dff88'}}>{playerName}</b> · id <span className="font-mono">{playerId.slice(0,14)}…</span></div>
        </div>

        <div className="pixel-panel p-5">
          <div className="font-pixel text-[10px] mb-3 neon-text-yellow">🔗 SHARE LINKS</div>
          <div className="text-xs text-slate-300 mb-1">Friend-invite link (adds you as friend):</div>
          <div className="flex gap-2 mb-4">
            <input className="pixel-input !text-[11px] font-mono" readOnly value={inviteLink} />
            <button className="pixel-btn pixel-btn-cyan !px-3" onClick={copyInvite}>{copied?<Check size={14}/>:'Copy'}</button>
          </div>
          <div className="text-xs text-slate-300 mb-1">Direct game challenge link:</div>
          <div className="flex gap-2">
            <select className="pixel-input !text-xs" value={inviteGame} onChange={e=>setInviteGame(e.target.value)}>
              {GAMES.map(g=><option key={g.id} value={g.id}>{g.title}</option>)}
            </select>
            <button className="pixel-btn !px-3" onClick={async()=>{try{await navigator.clipboard.writeText(gameLink);setCopied(true);setTimeout(()=>setCopied(false),1500);}catch{}}}>Copy</button>
          </div>
          <div className="text-[11px] text-slate-500 mt-2 break-all font-mono">{gameLink}</div>
        </div>
      </div>

      <div className="pixel-panel p-5 mt-3">
        <div className="font-pixel text-[10px] mb-3" style={{color:'#08d9d6'}}>👥 MY FRIENDS ({friends.length})</div>
        {friends.length===0?<div className="text-sm text-slate-500">No friends yet — search above or share your invite link.</div>:
        <div className="grid sm:grid-cols-2 gap-2">
          {friends.map((f:any)=>(
            <div key={f.id} className="flex items-center gap-2 p-2.5 rounded-xl" style={{background:'#0a0a20',border:'1px solid #2b2b5e'}}>
              <span className="w-9 h-9 rounded-full flex items-center justify-center font-bold" style={{background:'#a06bff',color:'#000'}}>{(f.friend_name||'?')[0].toUpperCase()}</span>
              <span className="flex-1 min-w-0"><b className="text-sm block truncate">{f.friend_name}</b><span className="text-[10px] text-slate-500 font-mono">{String(f.friend_id).slice(0,18)}</span></span>
              <Link to={`/play/tictactoe`} className="pixel-btn !text-[9px] !px-2 !py-2 no-underline">Play</Link>
              <button className="p-2 rounded-lg text-slate-500 hover:text-red-400" onClick={()=>remove(f.id)}><Trash2 size={15}/></button>
            </div>
          ))}
        </div>}
      </div>
    </div>
  );
}
