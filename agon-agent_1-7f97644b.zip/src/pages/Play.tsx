import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useParams, useSearchParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Copy, Check, Users, Crown, RefreshCw, Play as PlayIcon, UserPlus, Wifi, Signal, SignalHigh } from 'lucide-react';
import { gameById } from '../lib/games';
import { GAME_COMPONENTS } from '../games';
import { useAuth } from '../contexts/AuthContext';
import { TouchCanvasBridge, MobileKeyPad } from '../components/MobileControls';
import { useRoom, createRoom, joinRoom, leaveRoom, recordResult } from '../hooks/useRoom';
import type { Room } from '../games/types';

export default function Play() {
  const { gameId = 'tictactoe' } = useParams();
  const [params] = useSearchParams();
  const nav = useNavigate();
  const game = gameById(gameId);
  const { playerId, playerName } = useAuth();
  const Comp = GAME_COMPONENTS[gameId];

  const roomCode = (params.get('room') || '').toUpperCase() || null;
  const { room, loading, live, pushState, fetchRoom } = useRoom(roomCode);
  const [mode, setMode] = useState<'choose'|'solo'|'room'>(roomCode ? 'room' : 'choose');
  const [creating, setCreating] = useState(false);
  const [joinErr, setJoinErr] = useState('');
  const [copied, setCopied] = useState(false);
  const [size, setSize] = useState<2|3>(2);
  const savedRef = useRef(false);

  useEffect(()=>{ if (roomCode) setMode('room'); }, [roomCode]);
  useEffect(()=>{ savedRef.current=false; }, [gameId, roomCode, mode]);

  // auto-join room on load (force fresh read so join-then-play never shows stale seats)
  useEffect(()=>{
    if (mode!=='room' || !roomCode || loading) return;
    if (room && (room.players||[]).some((p:any)=>p.id===playerId)) return;
    joinRoom(roomCode, playerId, playerName).then(()=>fetchRoom(true)).catch(e=>setJoinErr(e.message));
  }, [mode, roomCode, loading]);

  const players = useMemo(()=> room?.players || [], [room]);
  const mySlot = useMemo(()=>{
    if (mode==='solo') return 0;
    const i = players.findIndex(p=>p.id===playerId);
    return i>=0?i:0;
  }, [players, playerId, mode]);
  const isHost = room ? room.host_id===playerId : true;
  const solo = mode==='solo';

  const hostRoom = async () => {
    if (!game) return;
    setCreating(true); setJoinErr('');
    try {
      const r = await createRoom(game.id, game.title, playerId, playerName, size);
      nav(`/play/${game.id}?room=${r.code}`);
      setMode('room');
    } catch (e:any) { setJoinErr(e.message); }
    setCreating(false);
  };
  const leave = async () => {
    if (roomCode) await leaveRoom(roomCode, playerId);
    nav(`/play/${gameId}`);
    setMode('choose');
  };
  const copyLink = async () => {
    const link = `${window.location.origin}/play/${gameId}?room=${roomCode}`;
    try { await navigator.clipboard.writeText(link); setCopied(true); setTimeout(()=>setCopied(false),1600);} catch {}
  };

  const onFinish = async (info: { winnerName?: string|null; winnerIndex?: number|null; scores?: Record<string,number> }) => {
    if (savedRef.current) return; savedRef.current = true;
    const names = solo ? [playerName] : players.map(p=>p.name);
    const score = Math.max(0, ...Object.values(info.scores||{x:0}));
    const iWon = solo ? info.winnerIndex===0||!!info.winnerName : (info.winnerName ? (players[mySlot]?.name===info.winnerName) : false);
    recordResult(gameId, game?.title||gameId, roomCode||'solo', names, info.winnerName||null, info.winnerIndex??null, info.scores||{}, playerId, playerName, iWon, score);
    setTimeout(()=>fetchRoom(true), 800);
  };

  if (!game || !Comp) return (<div className="mt-10 text-center"><div className="font-pixel">GAME NOT FOUND</div><Link to="/" className="pixel-btn mt-4 inline-block no-underline">Back</Link></div>);

  const Icon = game.icon;
  const stageGlow = game.color === '#ff2e63' ? 'stage-pink' : game.color === '#08d9d6' ? 'stage-cyan' : game.color === '#4dff88' ? 'stage-green' : game.color === '#ffe74c' ? 'stage-gold' : 'stage-purple';

  return (
    <div className="mt-5">
      <div className="flex items-center gap-2 mb-4 flex-wrap">
        <Link to="/" className="flex items-center gap-1 text-xs text-slate-300 no-underline px-3 py-2 rounded-lg" style={{background:'#1c1c3d'}}><ArrowLeft size={14}/> Arcade</Link>
        <span className="w-9 h-9 rounded-xl flex items-center justify-center icon-tile" style={{background:`${game.color}22`,border:`2px solid ${game.color}`,boxShadow:`0 0 14px ${game.color}55`}}><Icon size={18} color={game.color}/></span>
        <div>
          <h1 className="font-pixel text-sm" style={{color:game.color,textShadow:`0 0 14px ${game.color}88`}}>{game.title.toUpperCase()}</h1>
          <div className="text-[11px] text-slate-400 flex items-center gap-1.5 flex-wrap">
            <span>{game.players} players · {game.turnBased?'turn-synced ⚡':'live score race ⚡'} · laptop + keyboard</span>
            {mode==='room' && room && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full font-bold" style={{background:live?'rgba(77,255,136,.12)':'rgba(255,231,76,.1)',border:`1px solid ${live?'#4dff88':'#ffe74c'}`,color:live?'#4dff88':'#ffe74c',fontSize:10}}>
                {live ? <SignalHigh size={11}/> : <Signal size={11}/>} {live?'LIVE':'SYNC…'}
              </span>
            )}
          </div>
        </div>
        <div className="flex-1"/>
        {mode==='room'&&roomCode&&<span className="font-mono font-bold px-3 py-1.5 rounded-lg text-sm tracking-[0.2em]" style={{background:'#0a0a20',border:'2px solid #08d9d6',color:'#08d9d6'}}>ROOM {roomCode}</span>}
      </div>

      {mode==='choose'&&(
        <div className="grid md:grid-cols-2 gap-3 max-w-3xl mx-auto">
          <button onClick={()=>setMode('solo')} className="pixel-panel game-card p-6 text-left">
            <span className="w-11 h-11 rounded-xl inline-flex items-center justify-center" style={{background:'rgba(77,255,136,.14)',border:'2px solid #4dff88',boxShadow:'0 0 16px rgba(77,255,136,.35)'}}>
              <PlayIcon color="#4dff88" size={22}/>
            </span>
            <div className="font-pixel text-xs mt-3 mb-1" style={{color:'#4dff88'}}>SOLO / VS CPU</div>
            <div className="text-xs text-slate-400">Practice instantly. Scores still hit the leaderboard.</div>
          </button>
          <div className="pixel-panel panel-glow-cyan p-6">
            <span className="w-11 h-11 rounded-xl inline-flex items-center justify-center" style={{background:'rgba(8,217,214,.14)',border:'2px solid #08d9d6',boxShadow:'0 0 16px rgba(8,217,214,.35)'}}>
              <Users color="#08d9d6" size={22}/>
            </span>
            <div className="font-pixel text-xs mt-3 mb-1" style={{color:'#08d9d6'}}>PLAY ONLINE 2–3P</div>
            <div className="text-xs text-slate-400 mb-3">Host a room, share the code/link, friends join live.</div>
            <div className="flex items-center gap-2 text-xs mb-3">
              <span className="text-slate-400">Room size:</span>
              {([2,3] as (2|3)[]).filter(n=>n<=game.maxPlayers).map(n=><button key={n} onClick={()=>setSize(n)} className="px-3 py-1.5 rounded-lg font-bold" style={{background:size===n?'#08d9d6':'#1c1c3d',color:size===n?'#042':'#fff'}}>{n}P</button>)}
              {game.maxPlayers<3&&<span className="text-slate-500">(this game: 2P max)</span>}
            </div>
            <button disabled={creating} onClick={hostRoom} className="pixel-btn pixel-btn-cyan w-full">{creating?'CREATING…':'＋ CREATE ROOM'}</button>
            {joinErr&&<div className="text-xs mt-2" style={{color:'#ff8098'}}>{joinErr}</div>}
          </div>
          <div className="md:col-span-2 pixel-panel p-4 flex flex-wrap items-center gap-2 text-xs">
            <Wifi size={14} color="#ffe74c"/>
            <span className="text-slate-300">How online works:</span>
            <span className="text-slate-400">turn games sync every move to all laptops · reflex/puzzle games race live scores · results auto-save to ranks.</span>
          </div>
        </div>
      )}

      {mode==='room'&&(
        <>
          <LobbyBar room={room} loading={loading} playerId={playerId} mySlot={mySlot} isHost={isHost} gameId={gameId} joinErr={joinErr} copied={copied} onCopy={copyLink} onLeave={leave} onRefresh={()=>fetchRoom(true)} live={live} />
          {room&&(
            <div className={`stage ${stageGlow} mt-3`}>
              <TouchCanvasBridge />
              <Comp room={room} mySlot={mySlot} isHost={isHost} playerId={playerId} playerName={playerName} players={players} solo={false} pushState={pushState} onFinish={onFinish} />
              <MobileKeyPad />
            </div>
          )}
        </>
      )}

      {mode==='solo'&&(
        <div className={`stage ${stageGlow}`}>
          <div className="text-center mb-3">
            <button onClick={()=>setMode('choose')} className="text-[11px] text-slate-500 underline">← switch to online room</button>
          </div>
          <TouchCanvasBridge />
          <Comp room={null} mySlot={0} isHost={true} playerId={playerId} playerName={playerName} players={[{id:playerId,name:playerName,slot:0}]} solo={true} pushState={()=>{}} onFinish={onFinish} />
          <MobileKeyPad />
        </div>
      )}
    </div>
  );
}

function LobbyBar({ room, loading, playerId, mySlot, isHost, gameId, joinErr, copied, onCopy, onLeave, onRefresh, live }: { room: Room|null; loading: boolean; playerId: string; mySlot: number; isHost: boolean; gameId: string; joinErr: string; copied: boolean; onCopy: ()=>void; onLeave: ()=>void; onRefresh: ()=>void; live: boolean }) {
  if (loading&&!room) return <div className="pixel-panel p-6 text-center font-pixel text-xs blink">JOINING ROOM…</div>;
  if (!room) return (<div className="pixel-panel p-6 text-center">
    <div className="font-pixel text-xs mb-2" style={{color:'#ff2e63'}}>ROOM NOT FOUND</div>
    <div className="text-xs text-slate-400 mb-3">{joinErr||'This code expired or never existed.'}</div>
    <Link to={`/play/${gameId}`} className="pixel-btn no-underline">Host instead</Link>
  </div>);
  const maxed = (room.players||[]).length>=(room.max_players||2);
  return (
    <div className="pixel-panel panel-glow-cyan p-4">
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-2 flex-wrap">
          {(room.players||[]).map((p:any,i:number)=>(
            <span key={p.id} className="player-chip flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-full font-bold" style={{background:'#0a0a20',border:`2px solid ${p.id===playerId?'#4dff88':['#ff2e63','#08d9d6','#ffe74c'][i]}`,color:'#fff',boxShadow:p.id===playerId?'0 0 12px rgba(77,255,136,.4)':'none'}}>
              <span className="presence-dot" />
              {isHost&&i===0&&<Crown size={12} color="#ffe74c"/>}{p.name}{p.id===playerId?' (you)':''}
            </span>
          ))}
          {!maxed&&<span className="text-[11px] text-slate-500 blink">waiting for {((room.max_players||2)-(room.players||[]).length)} more…</span>}
          {maxed&&<span className="text-[11px] font-bold" style={{color:'#4dff88'}}>● Room full — game on!</span>}
        </div>
        <div className="flex-1"/>
        <button onClick={onCopy} className="pixel-btn pixel-btn-cyan !text-[10px] !py-2 flex items-center gap-1">{copied?<Check size={13}/>:'Copy invite link'} {copied?'Copied!':''}</button>
        <button onClick={onRefresh} className="p-2 rounded-lg text-slate-300" style={{background:'#1c1c3d'}} title="Refresh"><RefreshCw size={14}/></button>
        <Link to="/friends" className="p-2 rounded-lg text-slate-300 no-underline" style={{background:'#1c1c3d'}} title="Invite a friend"><UserPlus size={14}/></Link>
        <button onClick={onLeave} className="text-[11px] text-slate-400 underline">leave</button>
      </div>
      {joinErr&&<div className="text-xs mt-2" style={{color:'#ff8098'}}>{joinErr}</div>}
      {!maxed&&<div className="text-[11px] text-slate-500 mt-2 flex items-center gap-1 flex-wrap"><Copy size={11}/> Send friends: <span className="font-mono" style={{color:'#08d9d6'}}>{window.location.origin}/play/{gameId}?room={room.code}</span> <span className="px-1.5 py-0.5 rounded-full font-bold" style={{background:live?'rgba(77,255,136,.14)':'rgba(255,231,76,.12)',color:live?'#4dff88':'#ffe74c',fontSize:10}}>{live?'● live sync':'… connecting live'}</span> — game starts now, late friends can still join mid-race.</div>}
    </div>
  );
}
