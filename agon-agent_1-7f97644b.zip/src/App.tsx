import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { handleGoogleRedirect } from './lib/googleAuth';
import Layout from './components/Layout';
import Home from './pages/Home';
import Login from './pages/Login';
import Friends from './pages/Friends';
import Ranks from './pages/Ranks';
import History from './pages/History';
import Play from './pages/Play';
import QA from './pages/QA';

import { useEffect, useState } from 'react';

handleGoogleRedirect();

function SharedRoomCatch() {
  const sp = new URLSearchParams(window.location.search);
  const code = (sp.get('room') || '').toUpperCase();
  const [dest, setDest] = useState<string | null>(null);
  useEffect(() => {
    if (!code) { setDest('/'); return; }
    fetch(`/api/rooms?code=${code}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((room) => setDest(room?.game_id ? `/play/${room.game_id}?room=${code}` : '/'))
      .catch(() => setDest('/'));
  }, [code]);
  if (!dest) return <div className="mt-10 text-center font-pixel text-xs blink">FINDING ROOM…</div>;
  return <Navigate to={dest} replace />;
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Layout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/friends" element={<Friends />} />
            <Route path="/ranks" element={<Ranks />} />
            <Route path="/history" element={<History />} />
            <Route path="/qa" element={<QA />} />
            <Route path="/play/shared" element={<SharedRoomCatch />} />
            <Route path="/play/:gameId" element={<Play />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Layout>
      </BrowserRouter>
    </AuthProvider>
  );
}
