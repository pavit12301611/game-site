import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import supabase from '../lib/supabase';
export type Profile = { user_id: string; username: string; display_name: string; avatar_color: string } | null;
type AuthCtx = { user: any; session: any; loading: boolean; profile: Profile; nickname: string; playerId: string; playerName: string; setNickname: (n: string) => void; refreshProfile: () => Promise<void>; signOut: () => Promise<void>; };
const Ctx = createContext<AuthCtx>({} as AuthCtx);
export function guestId(): string {
  let id = localStorage.getItem('ppa_guest_id');
  if (!id) { id = 'guest_' + Math.random().toString(36).slice(2, 10); localStorage.setItem('ppa_guest_id', id); }
  return id;
}
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<any>(null);
  const [session, setSession] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<Profile>(null);
  const [nickname, setNicknameState] = useState(() => localStorage.getItem('ppa_nick') || '');
  const setNickname = (n: string) => { setNicknameState(n); localStorage.setItem('ppa_nick', n); };
  const refreshProfile = async () => {
    const { data: { session: s } } = await supabase.auth.getSession();
    const u = s?.user || null;
    if (u) { try { const r = await fetch(`/api/profiles?user_id=${u.id}`); const p = await r.json(); if (p && p.username) setProfile(p); } catch {} }
  };
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => { setSession(session); setUser(session?.user ?? null); setLoading(false); if (session?.user) refreshProfile(); });
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_e, s) => {
      setSession(s); setUser(s?.user ?? null); setLoading(false);
      if (s?.user) {
        const emailName = (s.user.email || 'player').split('@')[0].replace(/[^a-z0-9_]/gi, '').slice(0, 16).toLowerCase() || 'player';
        const metaName = (s.user.user_metadata?.full_name || s.user.user_metadata?.name || emailName).toString().slice(0, 20);
        try { await fetch('/api/profiles', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ user_id: s.user.id, username: emailName, display_name: metaName }) }); } catch {}
        refreshProfile();
      } else setProfile(null);
    });
    return () => subscription.unsubscribe();
  }, []);
  const signOut = async () => { await supabase.auth.signOut(); setProfile(null); };
  const playerId = user?.id || guestId();
  const base = profile?.display_name || profile?.username || nickname || (user?.email ? user.email.split('@')[0] : '') || 'Guest';
  const playerName = String(base).slice(0, 20) || 'Guest';
  return <Ctx.Provider value={{ user, session, loading, profile, nickname, playerId, playerName, setNickname, refreshProfile, signOut }}>{children}</Ctx.Provider>;
}
export const useAuth = () => useContext(Ctx);
